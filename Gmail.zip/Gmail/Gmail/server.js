const express = require("express");
const Gmail = require("./gmail"); // Import the Gmail class
const cors = require("cors"); // Import the cors package
const app = express();
const port = 3000;

// Create one instance of Gmail to reuse
const gmail = new Gmail();

app.use(express.json()); // Middleware to parse JSON
app.use(cors()); // Use CORS middleware
// Route for Gmail login
app.post("/login", async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({
      success: false,
      message: "Email and password are required",
    });
  }

  try {
    const result = await gmail.login(email, password);

    if (result.includes("Check your Authenticator app")) {
      return res.json({
        success: false,
        message: result,
      });
    } else if (result.includes("Login successful")) {
      return res.json({
        success: true,
        message: result,
      });
    } else {
      return res.status(500).json({
        success: false,
        message: result,
      });
    }
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: `Error: ${error.message}`,
    });
  }
});

// Route for OTP verification
app.post("/otp", async (req, res) => {
  const { otp } = req.body;

  if (!otp) {
    return res.status(400).json({
      success: false,
      message: "OTP is required",
    });
  }

  try {
    const result = await gmail.verifyOTP(otp);
    return res.json({
      success: result.includes("successful"),
      message: result,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: `Error: ${error.message}`,
    });
  }
});

// Route to send an email to one person
app.post("/send-email", async (req, res) => {
  const { to, subject, body } = req.body;

  if (!to || !subject || !body) {
    return res.status(400).json({
      success: false,
      message: "Recipient email, subject, and body are required.",
    });
  }

  try {
    const result = await gmail.sendEmail(to, subject, body);
    return res.json({
      success: true,
      message: result,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: `Error: ${error.message}`,
    });
  }
});

// Route to send emails to multiple people
app.post("/send-emails", async (req, res) => {
  const { toList, subject, body } = req.body;

  if (!Array.isArray(toList) || !subject || !body) {
    return res.status(400).json({
      success: false,
      message: "Recipient list (array), subject, and body are required.",
    });
  }

  try {
    // Join the email addresses with commas
    const recipientList = toList.join(",");
    
    // Send a single email to all recipients
    const result = await gmail.sendEmail(recipientList, subject, body);
    return res.json({
      success: true,
      message: result,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: `Error: ${error.message}`,
    });
  }
});


// Route to generate an email with user-defined tone
app.post("/generate-email", async (req, res) => {
  const { description, tone } = req.body;

  if (!description || !tone) {
    return res.status(400).json({
      success: false,
      message: "Description and tone are required",
    });
  }

  try {
    const generatedEmail = await gmail.generateEmail(description, tone);
    return res.json({
      success: true,
      generatedEmail,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: `Error: ${error.message}`,
    });
  }
});

// Route for logout
app.post("/logout", async (req, res) => {
  try {
    const result = await gmail.logout();
    return res.json({
      success: true,
      message: result,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: `Error: ${error.message}`,
    });
  }
});

// Route for searching inbox
app.post("/search-inbox", async (req, res) => {
  const { query } = req.body;

  if (!query) {
    return res.status(400).json({
      success: false,
      message: "Search query is required.",
    });
  }

  try {
    const result = await gmail.searchInbox(query);
    return res.json({
      success: true,
      emails: result,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: `Error: ${error.message}`,
    });
  }
});

// Route for searching sent mail
app.post("/search-sent", async (req, res) => {
  const { query } = req.body;

  if (!query) {
    return res.status(400).json({
      success: false,
      message: "Search query is required.",
    });
  }

  try {
    const result = await gmail.searchSent(query);
    return res.json({
      success: true,
      emails: result,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: `Error: ${error.message}`,
    });
  }
});

// Route to check for duplicate email before sending
app.post("/check-duplicate-email", async (req, res) => {
  const { to, subject } = req.body;

  if (!to || !subject) {
    return res.status(400).json({
      success: false,
      message: "Recipient email and subject are required.",
      canSend: false,
    });
  }

  try {
    const duplicateEmails = await gmail.checkDuplicateEmail(to, subject);

    if (duplicateEmails && duplicateEmails.length > 0) {
      // Duplicate found, prevent sending the email
      return res.json({
        success: true,
        message: "Duplicate email found. Email not sent.",
        canSend: false,
        total: duplicateEmails.length,
      });
    } else {
      // No duplicate found, email can be sent
      return res.json({
        success: true,
        message: "No duplicate email found. Safe to send.",
        canSend: true,
        total: 0,
      });
    }
  } catch (error) {
    // Handle errors and prevent email from being sent
    console.error("Error checking for duplicate emails:", error);
    return res.status(500).json({
      success: false,
      message: `Error checking for duplicate emails: ${error.message}`,
      canSend: false,
    });
  }
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});

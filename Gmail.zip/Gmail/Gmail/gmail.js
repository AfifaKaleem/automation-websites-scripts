const puppeteer = require("puppeteer");
const OpenAI = require("openai");
require("dotenv").config();

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

class Gmail {
  constructor() {
    this.browser = null;
    this.page = null;
  }

  async initialize() {
    if (!this.browser) {
      this.browser = await puppeteer.launch({
        headless: false,

      });
      this.page = await this.browser.newPage();
      this.page.setDefaultNavigationTimeout(90000);
    }
  }

  async login(email, password) {
    try {
      await this.initialize();

      // Step 1: Navigate to Google Login
      await this.page.goto("https://accounts.google.com/login", {
        waitUntil: "networkidle2",
      });

      // Step 2: Enter the email
      await this.page.type("input[type=email]", email, { delay: 100 });
      await this.page.click("#identifierNext");

      // Step 3: Wait for password input
      await this.page.waitForSelector("input[type=password]", {
        timeout: 10000,
        visible: true,
      });

      // Step 4: Enter password
      await this.page.type("input[type=password]", password, { delay: 100 });
      await this.page.click("#passwordNext");

      // Step 5: Keep checking the URL in a loop for 20 seconds
      let urlFound = false;
      const maxRetries = 20; // 20 retries of 1 second each (20 seconds total)
      for (let i = 0; i < maxRetries; i++) {
        const currentURL = this.page.url();
        if (currentURL.includes("challenge")) {
          urlFound = true;
          break; // Exit the loop if 'challenge' parameter is found
        }
        await new Promise((resolve) => setTimeout(resolve, 1000)); // Wait 1 second between checks
      }

      // Step 6: If 'challenge' is found, handle 2-Step Verification using Authenticator App
      if (urlFound) {
        console.log("Challenge URL detected.");

        await this.page.waitForSelector("button[type='button']", {
          visible: true,
        });

        // Step 6.1: Wait and click 'Try another way'
        let tryAnotherWayClicked = false;
        for (let attempt = 0; attempt < maxRetries; attempt++) {
          tryAnotherWayClicked = await this.page.evaluate(() => {
            const spanElement = Array.from(
              document.querySelectorAll("span")
            ).find((el) => el.textContent === "Try another way");
            if (spanElement) {
              spanElement.click();
              return true;
            }
            return false;
          });
          console.log(tryAnotherWayClicked);

          if (tryAnotherWayClicked) break; // Exit loop if clicked successfully
          await new Promise((resolve) => setTimeout(resolve, 1000)); // Wait 1 second before trying again
        }

        if (!tryAnotherWayClicked) {
          return "Error: 'Try another way' option not found after multiple attempts.";
        }

        // Step 6.2: Wait and click 'Get a verification code from the Google Authenticator app'
        let authenticatorOptionClicked = false;
        for (let attempt = 0; attempt < maxRetries; attempt++) {
          authenticatorOptionClicked = await this.page.evaluate(() => {
            const divElement = Array.from(
              document.querySelectorAll("div")
            ).find(
              (el) =>
                el.textContent ===
                "Get a verification code from the Google Authenticator app"
            );
            if (divElement) {
              divElement.click();
              return true;
            }
            return false;
          });

          if (authenticatorOptionClicked) break; // Exit loop if clicked successfully
          await new Promise((resolve) => setTimeout(resolve, 1000)); // Wait 1 second before trying again
        }

        if (!authenticatorOptionClicked) {
          return "Error: 'Get a verification code from the Google Authenticator app' option not found.";
        }

        // Step 6.3: Send response to user to check the Authenticator app
        return `Check your Authenticator app for a verification code for ${email} and send it to /otp.`;
      }

      // Step 7: If no 'challenge' was found, login was successful
      return "Login successful, no 2-Step Verification required.";
    } catch (error) {
      return `Error during login: ${error.message}`;
    }
  }

  async verifyOTP(otp) {
    try {
      if (!this.page) {
        return "Error: No active page to verify OTP.";
      }

      // Wait for OTP input field and enter the OTP
      await this.page.waitForSelector("#totpPin", { visible: true });
      await this.page.type("#totpPin", otp, { delay: 100 });
      await this.page.evaluate(() => {
        const nextButton = Array.from(document.querySelectorAll("span")).find(
          (el) => el.textContent === "Next"
        );
        nextButton?.click();
      });

      // Wait and check if the h1 tag contains "Welcome"
      await this.page.waitForNavigation();
      const loginSuccess = await this.page.evaluate(() => {
        const h1Elements = Array.from(document.getElementsByTagName("h1"));
        return h1Elements.length && h1Elements[0].innerText.includes("Welcome");
      });

      if (loginSuccess) {
        return "Login successful.";
      } else {
        throw Error("Invalid OTP or failed to login.");
      }
    } catch (error) {
      return `Error during OTP verification: ${error.message}`;
    }
  }

  async sendEmail(to, subject, body) {
    try {
      if (!this.page) {
        return "Error: No active page to send email.";
      }

      // Step 1: Navigate to Gmail Compose
      await this.page.goto(
        "https://mail.google.com/mail/u/0/#inbox?compose=new",
        {
          waitUntil: "networkidle2",
        }
      );

      // Step 2: Fill in the email details
      await this.page.waitForSelector("input[aria-label='To recipients']", {
        visible: true,
      });
      await this.page.type("input[aria-label='To recipients']", to, {
        delay: 100,
      });
      await this.page.type("input[aria-label='Subject']", subject, {
        delay: 100,
      });
      await this.page.type("div[aria-label='Message Body']", body, {
        delay: 100,
      });

      // Step 3: Send the email
      await this.page.click("div[aria-label='Send ‪(Ctrl-Enter)‬']");

      // Step 4: Wait for a confirmation message
      await this.page.waitForTimeout(2000); // Wait for 2 seconds

      return "Email sent successfully.";
    } catch (error) {
      return `Error during email sending: ${error.message}`;
    }
  }

  async generateEmail(request, tone) {
    try {
      const prompt = `Generate an email based on the following request: "${request}". Ensure the tone of the email is ${tone}.`;

      const completion = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [
          {
            role: "system",
            content:
              "You are a helpful assistant who writes emails. Remember, unless explicitly asked, you should not include the recipient's name or placeholders. Your emails should be general and adaptable.",
          },
          { role: "user", content: prompt },
        ],
      });
      return completion.choices[0].message.content;
    } catch (error) {
      return `Error generating email: ${error.message}`;
    }
  }

  async searchInbox(query) {
    try {
      await this.page.goto("https://mail.google.com/mail/u/0/#inbox", {
        waitUntil: "networkidle2",
      });
  
      await this.page.waitForSelector("input[aria-label='Search mail']");
  
      // Type search query and press Enter
      await this.page.type("input[aria-label='Search mail']", query, { delay: 100 });
      await this.page.keyboard.press('Enter');
  
      // Wait for search results to appear
      await this.page.waitForSelector(".Cp");
  
      // Extract email details
      const emails = await this.page.evaluate(() => {
        const rows = Array.from(document.querySelectorAll("tr.zA"));
        return rows.map(row => {
          const sender = row.querySelector(".yP") ? row.querySelector(".yP").innerText : '';
          const subject = row.querySelector(".bog") ? row.querySelector(".bog").innerText : '';
          const snippet = row.querySelector(".y2") ? row.querySelector(".y2").innerText.trim() : '';
          const dateElement = row.querySelector('span[title]');
          const date = dateElement ? new Date(dateElement.getAttribute('title')) : null;
          const emailidElement = row.querySelector('span[data-hovercard-id]');
          const emailid = emailidElement ? emailidElement.getAttribute('data-hovercard-id') : 'No Email ID';
  
          return { sender, subject, snippet, date, emailid };
        });
      });
  
      const analytics = this.analyzeInboxEmails(emails);
  
      return {
        success: true,
        emails: emails.length > 0 ? emails : [],
        totalInboxEmails: emails.length,
        analytics,
      };
    } catch (error) {
      console.error("Error searching inbox:", error.message);
      return {
        success: false,
        message: `Error searching inbox: ${error.message}`,
      };
    }
  }
  
  async searchSent(query) {
    try {
      await this.page.goto("https://mail.google.com/mail/u/0/#sent", {
        waitUntil: "networkidle2",
      });
  
      await this.page.waitForSelector("input[aria-label='Search mail']");
  
      // Type search query and press Enter
      await this.page.type("input[aria-label='Search mail']", query, { delay: 100 });
      await this.page.keyboard.press('Enter');
  
      // Wait for search results to appear
      await this.page.waitForSelector(".Cp");
  
      // Extract email details
      const emails = await this.page.evaluate(() => {
        const rows = Array.from(document.querySelectorAll("tr.zA"));
        return rows.map(row => {
          const sender = row.querySelector(".bA4 .yP") ? row.querySelector(".bA4 .yP").innerText : '';
          const subject = row.querySelector(".xT span.bog") ? row.querySelector(".xT span.bog").innerText : '';
          const snippet = row.querySelector(".y2") ? row.querySelector(".y2").innerText.trim() : '';
          const dateElement = row.querySelector("td.xW.xY span[title]");
          const date = dateElement ? new Date(dateElement.getAttribute("title")) : null;
          const emailidElement = row.querySelector('span[data-hovercard-id]');
          const emailid = emailidElement ? emailidElement.getAttribute('data-hovercard-id') : 'No Email ID';
  
          return { sender, subject, snippet, date, emailid };
        });
      });
  
      const analytics = this.analyzeSentEmails(emails);
  
      return {
        success: true,
        emails: emails.length > 0 ? emails : [],
        totalSentEmails: emails.length,
        analytics,
      };
    } catch (error) {
      console.error("Error searching sent items:", error.message);
      return {
        success: false,
        message: `Error searching sent items: ${error.message}`,
      };
    }
  }
  
  analyzeSentEmails(emails) {
    const stats = {
      perDay: 0,
      perWeek: 0,
      perMonth: 0,
      topSenders: {},
      topRecipients: {},
    };
  
    const now = new Date();
  
    emails.forEach(email => {
      if (email.date) {
        const diffTime = Math.abs(now - email.date);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
        if (diffDays <= 1) stats.perDay++;
        if (diffDays <= 7) stats.perWeek++;
        if (diffDays <= 30) stats.perMonth++;
  
        // Count top senders and recipients
        if (email.sender) stats.topSenders[email.sender] = (stats.topSenders[email.sender] || 0) + 1;
        if (email.emailid) stats.topRecipients[email.emailid] = (stats.topRecipients[email.emailid] || 0) + 1;
      }
    });
  
    // Sort top senders and recipients by frequency
    stats.topSenders = Object.entries(stats.topSenders)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5); // Top 5 senders
 
    return stats;
  }
  
  analyzeInboxEmails(emails) {
    const stats = {
      perDay: 0,
      perWeek: 0,
      perMonth: 0,
      topSenders: {},
      topRecipients: {},
    };
  
    const now = new Date();
  
    emails.forEach(email => {
      if (email.date) {
        const diffTime = Math.abs(now - email.date);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
        if (diffDays <= 1) stats.perDay++;
        if (diffDays <= 7) stats.perWeek++;
        if (diffDays <= 30) stats.perMonth++;
  
        // Count top senders and recipients
        if (email.sender) stats.topSenders[email.sender] = (stats.topSenders[email.sender] || 0) + 1;
        if (email.emailid) stats.topRecipients[email.emailid] = (stats.topRecipients[email.emailid] || 0) + 1;
      }
    });
  
  
    stats.topRecipients = Object.entries(stats.topRecipients)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5); // Top 5 recipients
  
    return stats;
  }
  

    async checkDuplicateEmail(to, subject) {
        try {
            // Go to the sent emails page
            await this.page.goto("https://mail.google.com/mail/u/0/#sent", {
                waitUntil: "networkidle2",
            });

            // Wait for the search input to load
            await this.page.waitForSelector("input[placeholder='Search mail']", {
                timeout: 10000,
            });

            // Type in the search query with the specific subject and recipient email
            await this.page.type("input[placeholder='Search mail']", `to:${to}`,`subject:${subject}`, { delay: 100 });
            await this.page.keyboard.press('Enter');

            // Wait for the search results to load (or timeout if no results)
            try {
                await this.page.waitForSelector("tr.zA.yO", { timeout: 5000 });
            } catch (error) {
                // If no results are found within the timeout, assume no duplicate exists
                return false;
            }

            // Check if any email row is present in the search results
            const emails = await this.page.evaluate(() => {
                return Array.from(document.querySelectorAll("tr.zA.yO")).map(row => {
                    const subjectElement = row.querySelector(".y6 span");
                    return subjectElement ? subjectElement.innerText : '';
                });
            });

            // Check if the subject exists in the sent emails
            return emails.some(sentSubject => sentSubject === subject);
        } catch (error) {
            console.error(`Error checking for duplicate emails: ${error.message}`);
            return false; // Return false on error to allow email sending
        }
    }

    async close() {
        await this.browser.close();
    }
}




module.exports = Gmail;

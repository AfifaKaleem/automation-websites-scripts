const express = require('express');
const bodyParser = require('body-parser');
const Yahoo = require('./Yahoo');

const app = express();
const port = process.env.PORT || 3000;

app.use(bodyParser.json());

let yahooInstance;

app.post('/init', async (req, res) => {
    try {
        yahooInstance = new Yahoo();
        await yahooInstance.init();
        res.status(200).send("Yahoo instance initialized successfully.");
    } catch (error) {
        console.error("Initialization failed:", error);
        res.status(500).send("Failed to initialize Yahoo instance.");
    }
});

app.post('/login', async (req, res) => {
    const { username, password } = req.body;
    try {
        await yahooInstance.login(username, password);
        res.status(200).send("Logged in successfully.");
    } catch (error) {
        console.error("Login failed:", error);
        res.status(500).send("Login failed.");
    }
});

app.post('/handle-otp', async (req, res) => {
    const { otp } = req.body;
    try {
        await yahooInstance.handleOTP(otp);
        res.status(200).send("OTP handled successfully.");
    } catch (error) {
        console.error("Handling OTP failed:", error);
        res.status(500).send("Failed to handle OTP.");
    }
});

app.post('/logout', async (req, res) => {
    try {
        await yahooInstance.logout();
        res.status(200).send("Logged out successfully.");
    } catch (error) {
        console.error("Logout failed:", error);
        res.status(500).send("Logout failed.");
    }
});

app.post('/search/inbox', async (req, res) => {
    const { hashtag } = req.body;
    try {
        const emails = await yahooInstance.searchEmailsByHashtagInInbox(hashtag);
        res.status(200).json(emails);
    } catch (error) {
        console.error("Inbox search failed:", error);
        res.status(500).send("Inbox search failed.");
    }
});

app.post('/search/sent', async (req, res) => {
    const { hashtag } = req.body;
    try {
        const emails = await yahooInstance.searchEmailsByHashtagInSent(hashtag);
        res.status(200).json(emails);
    } catch (error) {
        console.error("Sent search failed:", error);
        res.status(500).send("Sent search failed.");
    }
});


// Route to check for duplicate email before sending
app.post("/check-duplicate-email", async (req, res) => {
    const { to, subject } = req.body;

    if (!to || !subject) {
        return res.status(400).json({
            success: false,
            message: "Recipient email and subject are required.",
            canSend: false,
        });
    }

    try {
        // Wait for the result from the checkDuplicateEmail method
        const duplicateFound = await yahooInstance.checkDuplicateEmail(to, subject);
        
        if (duplicateFound) {
            // If duplicate is found, prevent sending the email
            return res.json({
                success: true,
                message: "Duplicate email found. Email not sent.",
                canSend: false, // Flag indicating email cannot be sent
                totalduplicate:duplicateFound.length
            });
        } else {
            // If no duplicate is found, email can be sent
            return res.json({
                success: true,
                message: "No duplicate email found. Safe to send.",
                canSend: true, // Flag indicating email can be sent
                totalduplicate:0
            });
        }
    } catch (error) {
        // Handle errors and prevent email from being sent if there's an issue
        return res.status(500).json({
            success: false,
            message: `Error checking for duplicate emails: ${error.message}`,
            canSend: false, // Flag indicating email should not be sent due to error
        });
    }
});

// Generate email endpoint
app.post('/generateEmail', async (req, res) => {
    const { to, subject, body } = req.body;

    try {
        await yahooInstance.generateEmail(to, subject, body);
        res.status(200).json({ success: true, message: 'Email generated' });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to generate email', error: error.message });
    }
});

// Send email endpoint
app.post('/sendEmail', async (req, res) => {
    try {
        await yahooInstance.sendEmail();
        res.status(200).json({ success: true, message: 'Email sent successfully' });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Failed to send email', error: error.message });
    }
});

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});

// Close the browser on server shutdown
process.on('SIGINT', async () => {
    if (yahooInstance) {
        await yahooInstance.close();
    }
    process.exit();
});

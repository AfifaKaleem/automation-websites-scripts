// Yahoo.js
const puppeteer = require('puppeteer');

class Yahoo {
    constructor() {
        this.browser = null;
        this.page = null;
        this.sentEmails = []; // An array to store sent email data (to, subject)
    }

    async init() {
        this.browser = await puppeteer.launch({ headless: false });
        this.page = await this.browser.newPage();
        await this.page.setViewport({ width: 1920, height: 1080 });
    }

    async login(username, password) {
        try {
            await this.page.goto('https://login.yahoo.com/');
            await this.page.type('#login-username', username);
            await this.page.click('#login-signin');
            await this.page.waitForSelector('#login-passwd', { visible: true });
            await this.page.type('#login-passwd', password);
            await this.page.click('#login-signin');

            console.log("Logged in successfully");
        } catch (error) {
            console.error("Login failed:", error);
        }
    }

    async handleOTP(otp) {
        try {
            await this.page.waitForSelector('#verification-code-field', { timeout: 10000 });
            await this.page.type('#verification-code-field', otp);
            await this.page.click('#verify-code-button');
            await this.page.waitForNavigation();
        } catch (error) {
            console.log("OTP not required or timeout reached.");
        }
    }

    async logout() {
        try {
            await this.page.goto('https://mail.yahoo.com/');
            await this.page.waitForSelector('#ybarAccountMenuOpener');
            await this.page.click('#ybarAccountMenuOpener');
            await this.page.waitForSelector('a[href*="logout"]');
            await this.page.click('a[href*="logout"]');
            await this.page.waitForNavigation();
            console.log("Logged out successfully");
        } catch (error) {
            console.error("Logout failed:", error);
        }
    }

    async searchEmailsByHashtagInInbox(hashtag) {
        try {
            await this.page.goto('https://mail.yahoo.com/');
            await this.page.waitForSelector('#search-box-pills-typeahead-input');
    
            // Type the hashtag into the search box
            await this.page.type('#search-box-pills-typeahead-input', `#${hashtag}`);
            await this.page.keyboard.press('Enter');
            await this.page.waitForSelector('div[data-test-id="virtual-list"]');
    
            // Extract emails based on updated selectors
            const emails = await this.page.evaluate(() => {
                const emailNodes = document.querySelectorAll('ul[role="list"] > li');
                return Array.from(emailNodes)
                    .map(node => {
                        const emailId = node.querySelector('div[id^="email-sender-"]')?.title || ''; // Sender's email/title
                        const date = node.querySelector('div[id^="email-date-"]')?.innerText || ''; // Email date
                        const subject = node.querySelector('div[id^="email-subject"]')?.title || ''; // Subject
                        const snippetElement = node.querySelector('div[id^="email-snippet"]');
                        const title = snippetElement ? snippetElement.textContent.trim() : ''; // Snippet text
                        return { emailId, subject, date, title };
                    })

            });
    
            const analytics = this.analyzeInboxEmails(emails);
  
            return {
              success: true,
              emails: emails.length > 0 ? emails : [],
              totalInboxEmails: emails.length,
              analytics,
            };

           
        } catch (error) {
            console.error("Search in inbox failed:", error);
            return [];
        }
    }
    
    
    async searchEmailsByHashtagInSent(hashtag) {
        try {
            await this.page.goto('https://mail.yahoo.com/n/folders/2?.src=ym&reason=myc');
            await this.page.waitForSelector('button[data-test-id="left-rail-Sent-icon"]');
            await this.page.click('button[data-test-id="left-rail-Sent-icon"]');

            await this.page.waitForSelector('#search-box-pills-typeahead-input');
            await this.page.type('#search-box-pills-typeahead-input', `#${hashtag}`);
            await this.page.keyboard.press('Enter');
            await this.page.waitForSelector('div[data-test-id="virtual-list"]');

            const emails = await this.page.evaluate(() => {
                const emailNodes = document.querySelectorAll('ul[role="list"] > li');
                return Array.from(emailNodes).map(node => {
                    const emailId = node.querySelector('div[id^="email-sender-"]')?.title || ''; // Sender's email/title
                    const date = node.querySelector('div[id^="email-date-"]')?.innerText || ''; // Email date
                    const subject = node.querySelector('div[id^="email-subject"]')?.title || ''; // Subject
                    const snippetElement = node.querySelector('div[id^="email-snippet"]');
                    const title = snippetElement ? snippetElement.textContent.trim() : ''; // Snippet text
                    return { emailId, subject, date, title };
                })
                  // Filter out empty results
                  .filter(email => email.emailId || email.subject || email.date || email.title);
            });
            const analytics = this.analyzeSentEmails(emails);
  
      return {
        success: true,
        emails: emails.length > 0 ? emails : [],
        totalSentEmails: emails.length,
        analytics,
      };
        } catch (error) {
            console.error("Search in sent folder failed:", error);
            return [];
        }
    }

    analyzeSentEmails(emails) {
        const stats = {
          perDay: 0,
          perWeek: 0,
          perMonth: 0,
          topSenders: {},
          topRecipients: {},
        };
      
        const now = new Date();
      
        emails.forEach(email => {
          if (email.date) {
            const diffTime = Math.abs(now - email.date);
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      
            if (diffDays <= 1) stats.perDay++;
            if (diffDays <= 7) stats.perWeek++;
            if (diffDays <= 30) stats.perMonth++;
      
            // Count top senders and recipients
            if (email.sender) stats.topSenders[email.sender] = (stats.topSenders[email.sender] || 0) + 1;
            if (email.emailid) stats.topRecipients[email.emailid] = (stats.topRecipients[email.emailid] || 0) + 1;
          }
        });
      
        // Sort top senders and recipients by frequency
        stats.topSenders = Object.entries(stats.topSenders)
          .sort((a, b) => b[1] - a[1])
          .slice(0, 5); // Top 5 senders
     
        return stats;
      }
      
      analyzeInboxEmails(emails) {
        const stats = {
          perDay: 0,
          perWeek: 0,
          perMonth: 0,
          topSenders: {},
          topRecipients: {},
        };
      
        const now = new Date();
      
        emails.forEach(email => {
          if (email.date) {
            const diffTime = Math.abs(now - email.date);
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      
            if (diffDays <= 1) stats.perDay++;
            if (diffDays <= 7) stats.perWeek++;
            if (diffDays <= 30) stats.perMonth++;
      
            // Count top senders and recipients
            if (email.sender) stats.topSenders[email.sender] = (stats.topSenders[email.sender] || 0) + 1;
            if (email.emailid) stats.topRecipients[email.emailid] = (stats.topRecipients[email.emailid] || 0) + 1;
          }
        });
      
      
        stats.topRecipients = Object.entries(stats.topRecipients)
          .sort((a, b) => b[1] - a[1])
          .slice(0, 5); // Top 5 recipients
      
        return stats;
      }
    async checkDuplicateEmail(to, subject) {
        try {
            await this.page.goto('https://mail.yahoo.com/');
            await this.page.waitForSelector('button[data-test-id="left-rail-Sent-icon"]', { timeout: 10000 });
            await this.page.click('button[data-test-id="left-rail-Sent-icon"]');
            await this.page.waitForSelector('#search-box-pills-typeahead-input', { timeout: 10000 });
    
            await this.page.type('#search-box-pills-typeahead-input', `to:${to} subject:${subject}`);
            await this.page.keyboard.press('Enter');
            
            // Wait for results to load or handle no results
            try {
                await this.page.waitForSelector('div[data-test-id="virtual-list"]', { timeout: 5000 });
            } catch {
                return false; // No duplicates found
            }
    
            // Check for duplicates
            const duplicate = await this.page.evaluate((subject) => {
                const emailRows = Array.from(document.querySelectorAll('div[data-test-id="virtual-list"]'));
                return emailRows.some(row => 
                    row.querySelector('div[id^="email-subject"]')?.innerText.trim().toLowerCase() === subject.trim().toLowerCase()
                );
            }, subject);
    
            return duplicate;
        } catch (error) {
            console.error(`Error checking for duplicate emails: ${error.message}`);
            return false;
        }
    }

    async generateEmail(to, subject, body) {
        try {
            await this.page.goto('https://mail.yahoo.com/');
            await this.page.waitForSelector('a[data-test-id="compose-button"]', { timeout: 10000 });
            await this.page.click('a[data-test-id="compose-button"]');

            // Wait for the compose modal to appear and fill in the details
            await this.page.waitForSelector('input[data-test-id="message-to-field"]');
            await this.page.type('input[data-test-id="message-to-field"]', to);

            await this.page.waitForSelector('input[data-test-id="compose-subject"]');
            await this.page.type('input[data-test-id="compose-subject"]', subject);

            await this.page.waitForSelector('div[data-test-id="rte"]');
            await this.page.type('div[data-test-id="rte"]', body);

            console.log("Email generated successfully");
        } catch (error) {
            console.error("Error generating email:", error);
        }
    }

    async sendEmail() {
        try {
            await this.page.waitForSelector('button[data-test-id="compose-send-button"]', { timeout: 10000 });
            await this.page.click('button[data-test-id="compose-send-button"]');

            // Wait for a confirmation that the email was sent
            await this.page.waitForSelector('span[data-test-id="notification-message"]', { timeout: 10000 });
            const confirmationMessage = await this.page.$eval(
                'span[data-test-id="notification-message"]',
                el => el.innerText
            );

            if (confirmationMessage.includes("Sent")) {
                console.log("Email sent successfully");
            } else {
                console.error("Email was not sent");
            }
        } catch (error) {
            console.error("Error sending email:", error);
        }
    }
    
    async close() {
        await this.browser.close();
        console.log("Browser closed");
    }
}

module.exports = Yahoo;

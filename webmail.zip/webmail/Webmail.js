const puppeteer = require("puppeteer");
const OpenAI = require("openai");
require("dotenv").config();

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

class Webmail {
    constructor() {
        this.browser = null;
        this.page = null;
    }

    async initialize() {
        if (!this.browser) {
            this.browser = await puppeteer.launch({
                headless: false,
                args: ['--start-maximized'], // Launch browser maximized
            });
    
            this.page = await this.browser.newPage();
            this.page.setDefaultNavigationTimeout(90000);
    
            // Set viewport to match fullscreen resolution
            const dimensions = await this.page.evaluate(() => ({
                width: window.screen.width,
                height: window.screen.height
            }));
            await this.page.setViewport({
                width: dimensions.width,
                height: dimensions.height
            });
        }
    }
    

    async login(email, password) {
        try {
            await this.initialize();

            // Step 1: Navigate to Google Login
            await this.page.goto("https://beladed.com:2096 ", {
                timeout: 60000,
            });

            // Step 2: Enter the email
            await this.page.waitForSelector("input[type='text']", { timeout: 60000 });
            await this.page.type("input[type='text']", email);
            // Step 3: Wait for password input
            await this.page.waitForSelector("input[type='password']", { timeout: 10000 });
            // Step 4: Enter password
            await this.page.type("input[type='password']", password);
            await this.page.waitForSelector("button[type=submit]", { timeout: 60000 });
            await this.page.keyboard.press("Enter");

            // Step 7: If no 'challenge' was found, login was successful
            return "Login successful, ";
        } catch (error) {
            return `Error during login: ${error.message}`;
        }
    }


    async sendEmail(to, subject, body) {
        try {
            if (!this.page) {
                return "Error: No active page to send email.";
            }
            await this.page.waitForSelector('a#rcmbtn112', { timeout: 60000 });
            await this.page.click('a#rcmbtn112');  // Clicking by ID')
            // Step 2: Fill in the email details
            await this.page.waitForSelector("textarea#_to", {
                visible: true,
            });
            await this.page.type("textarea#_to", to, {
                delay: 100,
            });
            await this.page.type("input#compose-subject", subject, {
                delay: 100,
            });
            await this.page.type("textarea#composebody", body, {
                delay: 100,
            });

            // Step 3: Send the email
            //   await this.page.click("div[aria-label='Send ‪(Ctrl-Enter)‬']");
            await this.page.click('a#rcmbtn111')

            return "Email sent successfully.";
        } catch (error) {
            return `Error during email sending: ${error.message}`;
        }
    }

    async generateEmail(request, tone) {
        try {
            const prompt = `Generate an email based on the following request: "${request}". Ensure the tone of the email is ${tone}.`;

            const completion = await openai.chat.completions.create({
                model: "gpt-4o-mini",
                messages: [
                    {
                        role: "system",
                        content:
                            "You are a helpful assistant who writes emails. Remember, unless explicitly asked, you should not include the recipient's name or placeholders. Your emails should be general and adaptable.",
                    },
                    { role: "user", content: prompt },
                ],
            });
            return completion.choices[0].message.content;
        } catch (error) {
            return `Error generating email: ${error.message}`;
        }
    }

    async searchInbox(query) {
        try {
            await this.page.waitForSelector("input#quicksearchbox");
            await this.page.click('input#quicksearchbox');
    
            // Type search query and press Enter
            await this.page.type("input#quicksearchbox", query, { delay: 100 });
            await this.page.keyboard.press('Enter');
    
            // Wait for search results to appear and ensure they are fully loaded
            await this.page.waitForFunction(() => {
                const rows = document.querySelectorAll("#messagelist tbody tr#rcmrowMw");
                return rows.length > 0;
            }, { timeout: 60000 });
    
            const emails = await this.page.evaluate(() => {
                const rows = Array.from(document.querySelectorAll("#messagelist tbody tr.message"));
    
                return rows.map(row => {
                    const rows = document.querySelector('tr.message');
                    const subjectElement = rows.querySelector('td.subject a span');
                    const senderElement = rows.querySelector('td.fromto span.rcmContactAddress');
                    const dateElement = row.querySelector('.date');
                    const sizeElement = row.querySelector('.size');
                    const flagElement = row.querySelector('.flag span');
    
                    return {
                        subject: subjectElement ? subjectElement.innerText : 'No Subject',
                        sender: senderElement ? senderElement.getAttribute('title') : 'Unknown Sender',
                        date: dateElement ? dateElement.innerText : 'No Date',
                        size: sizeElement ? sizeElement.innerText : 'Unknown Size',
                        flagStatus: flagElement ? flagElement.getAttribute('title') : 'Not Flagged',
                    };
                });
            });
    
            const analytics = this.analyzeInboxEmails(emails);
    
            return {
                success: true,
                emails: emails.length > 0 ? emails : [],
                totalInboxEmails: emails.length,
                analytics,
            };
        } catch (error) {
            console.error("Error searching inbox:", error.message);
            return {
                success: false,
                message: `Error searching inbox: ${error.message}`,
            };
        }
    }
    

    async searchSent(query) {
        try {
           
            await this.page.waitForSelector('li.mailbox.sent a[rel="INBOX.Sent"]',{timeout:60000});
            await this.page.click('li.mailbox.sent a[rel="INBOX.Sent"]');
            // Type search query and press Enter
            await this.page.type("input#quicksearchbox", query, { delay: 100 });
            await this.page.keyboard.press('Enter');
    
            // Wait for search results to appear and ensure they are fully loaded
            await this.page.waitForFunction(() => {
                const rows = document.querySelectorAll("#messagelist tbody tr.message");
                return rows.length > 0;
            }, { timeout: 60000 });
    
            const emails = await this.page.evaluate(() => {
                const rows = Array.from(document.querySelectorAll("#messagelist tbody tr.message"));
    
                return rows.map(row => {
                    const rows = document.querySelector('tr.message');
                    const subjectElement = rows.querySelector('td.subject a span');
                    const senderElement = rows.querySelector('td.fromto span.rcmContactAddress');
                    const dateElement = row.querySelector('.date');
                    const sizeElement = row.querySelector('.size');
                    const flagElement = row.querySelector('.flag span');
    
                    return {
                        subject: subjectElement ? subjectElement.innerText : 'No Subject',
                        sender: senderElement ? senderElement.getAttribute('title') : 'Unknown Sender',
                        date: dateElement ? dateElement.innerText : 'No Date',
                        size: sizeElement ? sizeElement.innerText : 'Unknown Size',
                        flagStatus: flagElement ? flagElement.getAttribute('title') : 'Not Flagged',
                    };
                });
            });
         
           

            const analytics = this.analyzeSentEmails(emails);

            return {
                success: true,
                emails: emails.length > 0 ? emails : [],
                totalSentEmails: emails.length,
                analytics,
            };
        } catch (error) {
            console.error("Error searching sent items:", error.message);
            return {
                success: false,
                message: `Error searching sent items: ${error.message}`,
            };
        }
    }

    analyzeSentEmails(emails) {
        const stats = {
            perDay: 0,
            perWeek: 0,
            perMonth: 0,
            topSenders: {},
           
        };

        const now = new Date();

        emails.forEach(email => {
            if (email.date) {
                const diffTime = Math.abs(now - email.date);
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

                if (diffDays <= 1) stats.perDay++;
                if (diffDays <= 7) stats.perWeek++;
                if (diffDays <= 30) stats.perMonth++;

                // Count top senders and recipients
                if (email.sender) stats.topSenders[email.sender] = (stats.topSenders[email.sender] || 0) + 1;
                
            }
        });

        // Sort top senders and recipients by frequency
        stats.topSenders = Object.entries(stats.topSenders)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 5); // Top 5 senders

        return stats;
    }

    analyzeInboxEmails(emails) {
        const stats = {
            perDay: 0,
            perWeek: 0,
            perMonth: 0,
            topRecipients: {},
        };

        const now = new Date();

        emails.forEach(email => {
            if (email.date) {
                const diffTime = Math.abs(now - email.date);
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

                if (diffDays <= 1) stats.perDay++;
                if (diffDays <= 7) stats.perWeek++;
                if (diffDays <= 30) stats.perMonth++;

                // Count top senders and recipients
                if (email.sender) stats.topRecipients[email.sender] = (stats.topRecipients[email.sender] || 0) + 1;
                
            }
        });


        stats.topRecipients = Object.entries(stats.topRecipients)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 5); // Top 5 recipients

        return stats;
    }


    async checkDuplicateEmail(to, subject) {
        try {
            // Go to the sent emails page
            // await this.page.goto("https://beladed.com:2096/cpsess8088416156/3rdparty/roundcube/?_task=mail&_mbox=INBOX.Sent", {
            //     timeout:60000,
            // });
            await this.page.waitForSelector('li.mailbox.sent a[rel="INBOX.Sent"]',{timeout:60000});
            await this.page.click('li.mailbox.sent a[rel="INBOX.Sent"]');
            await this.page.waitForSelector("input#quicksearchbox");
            await this.page.click('input#quicksearchbox');

            // Type search query and press Enter
            await this.page.type("input#quicksearchbox", `to:${to}`, `subject:${subject}`, { delay: 100 });
            await this.page.keyboard.press('Enter');

            // Wait for the search results to load (or timeout if no results)
            try {
                await this.page.waitForSelector("#messagelist tbody tr.message", { timeout: 5000 });
            } catch (error) {
                // If no results are found within the timeout, assume no duplicate exists
                return false;
            }

            // Check if any email row is present in the search results
            const emails = await this.page.evaluate(() => {
                return Array.from(document.querySelectorAll("#messagelist tbody tr.message")).map(row => {
                    const rows = document.querySelector('tr.message');
                    const subjectElement = rows.querySelector('td.subject a span');
                    return subjectElement ? subjectElement.innerText : '';
                });
            });

            // Check if the subject exists in the sent emails
            return emails.some(sentSubject => sentSubject === subject);
        } catch (error) {
            console.error(`Error checking for duplicate emails: ${error.message}`);
            return false; // Return false on error to allow email sending
        }
    }

    async close() {
        await this.browser.close();
    }
}




module.exports = Webmail;

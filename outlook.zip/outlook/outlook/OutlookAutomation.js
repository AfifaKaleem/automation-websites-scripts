const puppeteer = require('puppeteer');

class OutlookAutomation {
    constructor() {
        this.browser = null;
        this.page = null;
    }

    async init() {
        this.browser = await puppeteer.launch({ headless: false });
        this.page = await this.browser.newPage();
        await this.page.setViewport({ width: 1280, height: 800 });
        await this.page.setUserAgent(
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36'
        );
    }

    async login(email, password) {
        try {
            // Navigate to the new login page URL
            await this.page.goto(
                'https://login.live.com/login.srf?wa=wsignin1.0&rpsnv=164&ct=1730465490&rver=7.5.2211.0&wp=MBI_SSL&wreply=https%3a%2f%2foutlook.live.com%2fowa%2f%3fnlp%3d1%26cobrandid%3dab0455a0-8d03-46b9-b18b-df2f57b9e44c%26culture%3den-us%26country%3dus%26RpsCsrfState%3d894e9102-519b-d576-93b3-fea3ef0d5ed8&id=292841&aadredir=1&CBCXT=out&lw=1&fl=dob%2cflname%2cwld&cobrandid=ab0455a0-8d03-46b9-b18b-df2f57b9e44c',
                { waitUntil: 'networkidle2', timeout: 60000 }
            );

            // Wait for the email input field to load and enter the email
            await this.page.waitForSelector('input[type="email"]', { timeout: 10000 });
            await this.page.type('input[type="email"]', email);
            await this.page.click('#idSIButton9');

            // await this.handleOtp();

            // Wait for the password input field and enter the password
            await this.page.waitForSelector('input[type="password"]', { timeout: 10000 });
            await this.page.type('input[type="password"]', password);
            await this.page.click('button[type="submit"]');
            await this.page.waitForNavigation();



            // Confirm "Stay signed in?" prompt
            await this.page.waitForSelector('input#checkboxField');
            await this.page.click('input#checkboxField');
            await this.page.waitForSelector('button[type="submit"]', { visible: true });
            await this.page.click('button[type="submit"]');


            console.log("Login successful");
        } catch (error) {
            console.error("Login failed:", error);
        }
    }


    async handleOtp(otpSelector) {
        try {
            await this.page.waitForSelector('input#idTxtBx_OTC_Password');
            await this.page.type('input#idTxtBx_OTC_Password', otpSelector);
            await this.page.waitForSelector('button#primaryButton');
            await this.page.click('button#primaryButton');

            // Confirm "Stay signed in?" prompt
            await this.page.waitForSelector('input#checkboxField');
            await this.page.click('input#checkboxField');
            await this.page.waitForSelector('button[type="submit"]', { visible: true });
            await this.page.click('button[type="submit"]');
            console.log("Otp written succesfully")
        }
        catch (error) {
            console.error("Error handling OTP:", error);
        }
    }




    async searchHashtagInInbox(hashtag) {
        try {
            await this.page.waitForSelector('#topSearchInput', { visible: true, timeout: 10000 });
            await this.page.click('#topSearchInput'); // Focus the search input
            // Ensure "Inbox" is selected in the dropdown
            await this.page.waitForSelector('#searchScopeButtonId', { visible: true, timeout: 10000 });

            // Click the dropdown to expand options
            await this.page.click('#searchScopeButtonId');

            // Wait for the dropdown options to be visible
            await this.page.waitForSelector('.ms-Dropdown-title', { visible: true });

            // Select the "Inbox" option
            await this.page.evaluate(() => {
                const dropdownOptions = Array.from(document.querySelectorAll('.ms-Dropdown-title span'));
                const inboxOption = dropdownOptions.find(option => option.textContent.includes('Inbox'));
                inboxOption?.click(); // Click "Inbox" if it exists
            });
            console.log("Selected 'Inbox' in the search scope.");

            // Wait for the search input to be visible and type the hashtag
            await this.page.waitForSelector('#topSearchInput', { visible: true, timeout: 10000 });
            await this.page.click('#topSearchInput'); // Focus the search input
            await this.page.type('#topSearchInput', `#${hashtag}`, { delay: 100 }); // Type hashtag with delay

            // Simulate pressing the Enter key to initiate the search
            await this.page.keyboard.press('Enter');
            console.log(`Searched for hashtag: #${hashtag}`);

            // Wait for the results container to appear after search
            await this.page.waitForSelector('.jGG6V', { visible: true, timeout: 15000 });

            // Check if there are any email results
            const emailElements = await this.page.$$('.jGG6V');
            if (emailElements.length === 0) {
                console.log('No emails found with the specified hashtag.');
                return [{ error: 'No emails matched the hashtag.' }];
            }

            // Extract email details from the search results
            const emails = await this.page.evaluate(() => {
                const emailElements = Array.from(document.querySelectorAll('.jGG6V'));
                return emailElements.map(email => {
                    // Extract specific details from each email
                    const subject = email.querySelector('span.TtcXM')?.innerText || 'No Subject';
                    const dateAndTime = email.querySelector('span._rWRU')?.innerText || 'No Time';
                    const snippet = email.querySelector('span.FqgPc')?.innerText || 'No Snippet';
                    const titleElement = email.querySelector('span[title]');
                    const title = titleElement?.innerText || 'No Title';
                    const emailId = titleElement?.getAttribute('title') || 'No Email ID';

                    return { subject, title, snippet, dateAndTime, emailId };
                });
            });

            const analytics = this.analyzeInboxEmails(emails);
  
            return {
              success: true,
              emails: emails.length > 0 ? emails : [],
              totalInboxEmails: emails.length,
              analytics,
            };
        } catch (error) {
            // Log and return error if search fails
            console.error(`Error searching for hashtag:`, error);
            return [{ error: `Error searching for hashtag: ${error.message}` }];
        }
    }

    async searchHashtagInSent(hashtag) {
        try {
            // Navigate to the Sent Items page
            await this.page.goto(`https://outlook.live.com/mail/0/sentitems`);
    
            // Wait for the search input to appear and type the hashtag
            await this.page.waitForSelector('#topSearchInput', { visible: true, timeout: 10000 });
            await this.page.click('#topSearchInput');
            await this.page.type('#topSearchInput', `#${hashtag}`, { delay: 100 });
    
            // Press Enter to initiate the search
            await this.page.keyboard.press('Enter');
            console.log(`Searched for hashtag: #${hashtag}`);
    
            // Wait for search results
            await this.page.waitForSelector('.jGG6V', { visible: true, timeout: 15000 });
    
            // Check for email results
            const emailElements = await this.page.$$('.jGG6V');
            if (emailElements.length === 0) {
                console.log('No emails found with the specified hashtag.');
                return { success: true, emails: [], totalSentEmails: 0, analytics: {} };
            }
    
            // Extract email details from the results
            const emails = await this.page.evaluate(() => {
                const emailElements = Array.from(document.querySelectorAll('.jGG6V'));
                return emailElements.map(email => {
                    const subject = email.querySelector('span.TtcXM')?.innerText || 'No Subject';
                    const dateAndTime = email.querySelector('span._rWRU')?.innerText || 'No Time';
                    const snippet = email.querySelector('span.FqgPc')?.innerText || 'No Snippet';
                    const titleElement = email.querySelector('span[title]');
                    const emailId = titleElement?.getAttribute('title') || 'No Email ID';
                    const date = new Date(dateAndTime); // Convert date string to Date object
    
                    return {
                        subject,
                        title: subject,
                        snippet,
                        date,
                        emailId,
                    };
                });
            });
    
            // Analyze the emails
            const analytics = this.analyzeSentEmails(emails);
    
            return {
                success: true,
                emails: emails.length > 0 ? emails : [],
                totalSentEmails: emails.length,
                analytics,
            };
        } catch (error) {
            console.error(`Error searching for hashtag:`, error);
            return { success: false, message: `Error searching for hashtag: ${error.message}` };
        }
    }
    
    analyzeSentEmails(emails) {
        const stats = {
            perDay: 0,
            perWeek: 0,
            perMonth: 0,
            topSenders: {},
        };
    
        const now = new Date();
    
        emails.forEach(email => {
            if (email.date) {
                const diffTime = Math.abs(now - email.date);
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
                if (diffDays <= 1) stats.perDay++;
                if (diffDays <= 7) stats.perWeek++;
                if (diffDays <= 30) stats.perMonth++;
    
                // Count top senders
                if (email.sender) stats.topSenders[email.sender] = (stats.topSenders[email.sender] || 0) + 1;
            }
        });
    
        // Sort top senders by frequency
        stats.topSenders = Object.entries(stats.topSenders)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 5); // Top 5 senders
    
        return stats;
    }
    
      analyzeInboxEmails(emails) {
        const stats = {
          perDay: 0,
          perWeek: 0,
          perMonth: 0,
          topSenders: {},
          topRecipients: {},
        };
      
        const now = new Date();
      
        emails.forEach(email => {
          if (email.date) {
            const diffTime = Math.abs(now - email.date);
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      
            if (diffDays <= 1) stats.perDay++;
            if (diffDays <= 7) stats.perWeek++;
            if (diffDays <= 30) stats.perMonth++;
      
            // Count top senders and recipients
            if (email.sender) stats.topSenders[email.sender] = (stats.topSenders[email.sender] || 0) + 1;
            if (email.emailid) stats.topRecipients[email.emailid] = (stats.topRecipients[email.emailid] || 0) + 1;
          }
        });
      
      
        stats.topRecipients = Object.entries(stats.topRecipients)
          .sort((a, b) => b[1] - a[1])
          .slice(0, 5); // Top 5 recipients
      
        return stats;
      }
    async logout() {
        try {
            await this.page.goto('https://outlook.live.com/owa/');
            await this.page.waitForTimeout(2000);
            await this.page.click('[aria-label="Account manager"]');
            await this.page.waitForTimeout(2000);
            await this.page.click('[aria-label="Sign out"]');
            await this.page.waitForTimeout(3000);

            console.log("Logout successful");
        } catch (error) {
            console.error("Logout failed:", error);
        }
    }



    // async generateEmail(subject, body, recipients) {
    //     try {
    //         await this.page.goto('https://outlook.live.com/mail/0/compose', { waitUntil: 'networkidle2' });
    //         await this.page.waitForSelector('div[role="textbox"]', { visible: true });
    //         await this.page.type('div[role="textbox"]', recipients.join('; '), { delay: 100 });
    //         await this.page.type('input[type="text"]', subject, { delay: 100 });
    //         await this.page.type('div[aria-label="Message body"]', body, { delay: 100 });

    //         console.log("Email generated successfully");
    //     } catch (error) {
    //         console.error("Error generating email:", error);
    //     }
    // }

    async sendEmail(to, subject, body) {
        try {
            // Go to the compose email page directly
            await this.page.goto('https://outlook.live.com/mail/0/compose', { waitUntil: 'networkidle2' });
    
            // Wait for the "To" field and enter the recipient email address
            await this.page.waitForSelector('div[aria-label="To"]');
            await this.page.type('div[aria-label="To"]', to, { delay: 100 });
            await this.page.keyboard.press('Enter'); // Confirm the email address
    
            // Wait for the "Subject" field and enter the subject
            await this.page.waitForSelector('input[aria-label="Add a subject"]');
            await this.page.type('input[aria-label="Add a subject"]', subject, { delay: 100 });
    
            // Wait for the "Message body" and type the email body
            await this.page.waitForSelector("#docking_DockingTriggerPart_0");
            await this.page.type("#docking_DockingTriggerPart_0", body, { delay: 100 });
    
            // Click the "Send" button
            await this.page.click("button[aria-label='Send']");
    
            return "Email sent successfully.";
        } catch (error) {
            return `Error during Outlook email sending: ${error.message}`;
        }
    }
    
    async checkDuplicateEmail(to, subject) {
        try {
            // Go to the Sent Items page
            await this.page.goto("https://outlook.live.com/mail/sentitems", {
                waitUntil: "networkidle2",
            });
    
            // Wait for the search input to load
            await this.page.waitForSelector("#topSearchInput", { timeout: 10000 });
    
            // Type in the search query with the specific subject and recipient email
            await this.page.type("#topSearchInput", `to:${to} subject:${subject}`, { delay: 100 });
            await this.page.keyboard.press('Enter');
    
            // Wait for the search results to load
            await this.page.waitForSelector(".jGG6V", { timeout: 15000 });
    
            // Evaluate if any email in the results matches both the to and subject fields
            const duplicateFound = await this.page.evaluate((to, subject) => {
                const emailRows = document.querySelectorAll('.jGG6V'); // Adjust selector if necessary
                return Array.from(emailRows).some(row => {
                    const recipient = row.querySelector("span[title]")?.innerText.trim().toLowerCase(); // Replace with actual selector
                    const emailSubject = row.querySelector("span.TtcXM")?.innerText.trim().toLowerCase(); // Replace with actual selector
                    return recipient === to.trim().toLowerCase() && emailSubject === subject.trim().toLowerCase();
                });
            }, to, subject);
    
            console.log(duplicateFound ? "Duplicate email found." : "No duplicate email found.");
            return duplicateFound;
        } catch (error) {
            console.error(`Error checking for duplicate emails: ${error.message}`);
            return false; // Return false on error to allow email sending
        }
    }
    
    


    async close() {
        await this.page.close();
        await this.browser.close();
    }
}

module.exports = OutlookAutomation;

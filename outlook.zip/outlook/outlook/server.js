
const express = require('express');
const OutlookAutomation = require('./OutlookAutomation'); // Adjust path if needed
const app = express();
const port = process.env.PORT || 3000; // Use environment variable for port

app.use(express.json());

// Initialize the automation instance
const outlookAutomation = new OutlookAutomation();

// Middleware for input validation
const validateLoginInput = (req, res, next) => {
    const { email, password } = req.body;
    if (!email || !password) {
        return res.status(400).json({ success: false, message: "Email and password are required." });
    }
    next();
};

const validateHashtagInput = (req, res, next) => {
    const { hashtag } = req.body;
    if (!hashtag) {
        return res.status(400).json({ success: false, message: "Hashtag is required." });
    }
    next();
};

app.post('/init', async (req, res) => {
    try {
        await outlookAutomation.init();
        res.status(200).json({ success: true, message: "Browser initialized" });
    } catch (error) {
        res.status(500).json({ success: false, message: "Failed to initialize browser: " + error.message });
    }
});

app.post('/login', validateLoginInput, async (req, res) => {
    const { email, password } = req.body;
    try {
        await outlookAutomation.login(email, password);
        res.status(200).json({ success: true, message: "Login successful" });
    } catch (error) {
        res.status(500).json({ success: false, message: "Login failed: " + error.message });
    }
});

// OTP handling route
app.post('/handle-otp', async (req, res) => {
    const { otpSelector } = req.body;
    try {
        await outlookAutomation.handleOtp(otpSelector);
        res.json({ success: true, message: "OTP handled successfully." });
    } catch (error) {
        res.status(500).json({ success: false, message: "Failed to handle OTP: " + error.message });
    }
});


// Send email if no duplicates are found
app.post("/sendEmail", async (req, res) => {
    const { to, subject, body } = req.body;
    try {
        
            await outlookAutomation.sendEmail(to, subject, body);
            res.status(200).json({ success: true, message: "Email sent successfully!" });
        
    } catch (error) {
        res.status(500).json({ success: false, message: "Error sending email: " + error.message });
    }
});

// Define the endpoint for searching hashtags
app.post('/search/hashtag/inbox', validateHashtagInput, async (req, res) => {
    const { hashtag } = req.body;
    try {
        const results = await outlookAutomation.searchHashtagInInbox(hashtag);
        return res.status(200).json({ success: true, data: results });
    } catch (error) {
        return res.status(500).json({ success: false, message: 'Failed to search hashtag.' });
    }
});

// Define the endpoint for searching hashtags in sent items
app.post('/search/hashtag/sent', validateHashtagInput, async (req, res) => {
    const { hashtag } = req.body;
    try {
        const results = await outlookAutomation.searchHashtagInSent(hashtag);
        return res.status(200).json({ success: true, data: results });
    } catch (error) {
        return res.status(500).json({ success: false, message: 'Failed to search hashtag.' });
    }
});

app.post('/logout', async (req, res) => {
    try {
        await outlookAutomation.logout();
        res.status(200).json({ success: true, message: "Logout successful" });
    } catch (error) {
        res.status(500).json({ success: false, message: "Logout failed: " + error.message });
    }
});

// Route to check for duplicate email before sending
app.post("/check-duplicate-email", async (req, res) => {
    const { to, subject } = req.body;

    if (!to || !subject) {
        return res.status(400).json({
            success: false,
            message: "Recipient email and subject are required.",
            canSend: false,
        });
    }
        const duplicateFound = await outlookAutomation.checkDuplicateEmail(to, subject);

        if (duplicateFound ) {
            // If duplicate is not found, prevent sending the email
            return res.json({
                success: true,
                message: "Duplicate email found. Email not sent.",
                canSend: false, // Flag indicating email cannot be sent
                total: duplicateFound.length,
                
            });
        } else {
            // If  duplicate is found, email can be sent
            return res.json({
                success: true,
                message: "No duplicate email found. Safe to send.",
                canSend: true, // Flag indicating email can be sent
                total:0
            });
        }
   
});

  // Route to send emails to multiple people
app.post("/send-emails", async (req, res) => {
    const { to, subject, body } = req.body;
  
    if (!Array.isArray(to) || !subject || !body) {
      return res.status(400).json({
        success: false,
        message: "Recipient list (array), subject, and body are required.",
      });
    }
  
    try {
      // Join the email addresses with commas
      const recipientList = to.join(",");
      
      // Send a single email to all recipients
      const result = await gmail.sendEmail(recipientList, subject, body);
      return res.json({
        success: true,
        message: result,

      });
    } catch (error) {
      return res.status(500).json({
        success: false,
        message: `Error: ${error.message}`,
      });
    }
  });

app.post('/close', async (req, res) => {
    try {
        await outlookAutomation.close();
        res.status(200).json({ success: true, message: "Browser closed" });
    } catch (error) {
        res.status(500).json({ success: false, message: "Failed to close browser: " + error.message });
    }
});

// Start the server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});

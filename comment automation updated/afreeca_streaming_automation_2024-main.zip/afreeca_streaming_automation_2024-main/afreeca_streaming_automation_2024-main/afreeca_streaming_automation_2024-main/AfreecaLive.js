const express = require('express');
const playwright = require('playwright');
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { OpenAI } = require('openai');
const slugify = require('slugify');

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

class AfreecaLive {
  constructor() {
    this.browser = null;
    this.page = null;
    this.cache = {};  // In-memory cache
  }
  async init() {
    try {
      // Launch the browser and create a new context and page
      this.browser = await playwright.chromium.launch({ headless: false });
      const context = await this.browser.newContext();
      this.page = await context.newPage();

      // Load cache from file if it exists
      this.loadCache();
      console.log("Browser initialized successfully.");
    } catch (error) {
      console.error("Error initializing browser:", error);
    }
  }

  // Helper functions to manage caching
  loadCache() {
    const cacheFile = path.join(__dirname, 'jokes_cache.json');
    if (fs.existsSync(cacheFile)) {
      try {
        const data = fs.readFileSync(cacheFile, 'utf8');
        this.cache = JSON.parse(data);
      } catch (error) {
        console.error('Error loading cache:', error);
      }
    }
  }

  saveCache() {
    const cacheFile = path.join(__dirname, 'jokes_cache.json');
    try {
      fs.writeFileSync(cacheFile, JSON.stringify(this.cache, null, 2));
    } catch (error) {
      console.error('Error saving cache:', error);
    }
  }


  async login(username, password) {
    try {
      await this.page.goto("https://login.afreecatv.com/afreeca/login.php", {
        timeout: 60000,
      });

      // Fill in username
      await this.page.fill('input[name="uid"]', username);

      // Fill in password
      await this.page.fill('input[name="password"]', password);

      // Click the login button
      await this.page.click("button[type='button']");

      // Wait for login confirmation
      // await this.page.waitForTimeout(5000); // Adjust this time based on the actual login process

      console.log("AfreecaTV Login successful");
      return { success: true, message: "AfreecaTV Login successful" };
    } catch (error) {
      console.error("Error logging in to AfreecaTV:", error);
      return {
        success: false,
        message: "Error logging in to AfreecaTV: " + error.message,
      };
    }
  }

  async getStreamDetails() {
    try {
      // Navigate to the dashboard page
      await this.page.goto("https://dashboard.afreecatv.com/index.php", {
        timeout: 60000,
      });

      // Click the button to reveal the stream key
      await this.page.click("#btnShowKey");

      // Extract the stream key and server URL
      const streamDetails = await this.page.evaluate(() => {
        const streamKey = document.querySelector(
          'input[name="frmStreamKey"]'
        ).value;
        const serverUrl = document.querySelector("#ServerUrl").innerText;

        return { streamKey, serverUrl };
      });

      console.log("Stream details retrieved:", streamDetails);
      return { success: true, streamDetails };
    } catch (error) {
      console.error("Error retrieving stream details:", error);
      return {
        success: false,
        message: "Error retrieving stream details: " + error.message,
      };
    }
  }

  async updateStreamTitle(title) {
    try {
      // Navigate to the dashboard page
      await this.page.goto("https://dashboard.afreecatv.com/index.php", {
        timeout: 60000,
      });

      // Locate the input for the broadcast title
      const titleInput = await this.page.$('input[name="frmTitle"]');

      if (titleInput) {
        // Clear the existing title and type the new one
        await titleInput.fill("");
        await titleInput.type(title);

        // Click the update button
        await this.page.click("#button_update");

        // Wait for a brief moment to ensure the action is completed
        await this.page.waitForTimeout(2000);

        console.log("Stream title updated successfully");
        return { success: true, message: "Stream title updated successfully" };
      } else {
        console.error("Failed to find the broadcast title input");
        return {
          success: false,
          message: "Failed to find the broadcast title input",
        };
      }
    } catch (error) {
      console.error("Error updating stream title:", error);
      return {
        success: false,
        message: "Error updating stream title: " + error.message,
      };
    }
  }

  async searchHashtags(hashtag) {
    try {
      console.log(`Searching for hashtag: ${hashtag}`);
  
      // Navigate to the page with the search query
      await this.page.goto(`https://www.sooplive.co.kr/search?szLocation=total_search&szSearchType=total&szKeyword=${hashtag}`);
      await this.page.fill('input[type="text"]', hashtag);
      await this.page.keyboard.press("Enter");
  
      // Wait for the results to load
      await this.page.waitForSelector('.cBox-list');
  
      // Extract live video details
      const liveVideos = await this.page.$$eval('.cBox-list ul li', (items) => {
        return items.map((item) => {
          const username = item.querySelector('.nick_wrap .nick span')?.innerText || '';
          const photoUrl = item.querySelector('a img')?.src || '';
          const profileUrl = item.querySelector('.thumb_warp a')?.href || '';
          const title = item.querySelector('.title a')?.innerText || '';
          const description = item.querySelector('.tag_wrap')?.innerText || '';
          const displayName = item.querySelector('.nick_wrap .nick span')?.innerText || '';
          const postUrl = item.querySelector('.title a')?.href || '';
  
          return {
            title,
            username,
            postUrl,
            displayName,
            profileUrl,
            photoUrl,
            description
          };
        });
      });
  
      console.log("User details extracted:", liveVideos);
  
      // Extract comments for each video
      const userComments = [];
      for (const user of liveVideos) {
        if (user.postUrl) {
          console.log(`Navigating to video page: ${user.postUrl}`);
          await this.page.goto(user.postUrl);
  
         
  
          // Attempt to wait for comments to load
          try {
            console.log("Waiting for comments...");
            await this.page.waitForSelector('.cmmt-txt p', { timeout: 60000 }); // Reduce timeout
          } catch (e) {
            console.log(`Comments not visible for post: ${user.postUrl}. Skipping.`);
            continue;
          }
           // Check if comments section exists
           const hasCommentsSection = await this.page.$('.cmmt-txt p');
           if (!hasCommentsSection) {
             console.log(`No comments section found for post: ${user.postUrl}. Skipping.`);
             continue;
           }
  
          // Extract comments
          console.log("Extracting comments...");
          const comments = await this.page.evaluate(() => {
            const commentElements = document.querySelectorAll('.cmmt-txt p');
            return Array.from(commentElements).map(comment => {
              return { commentText: comment.textContent.trim() };
            });
          });
  
          userComments.push({
            ...user,
            comments: comments
          });
  
          console.log(`Extracted ${comments.length} comments from video: ${user.postUrl}`);
        }
      }
  
      console.log("Comments extraction complete:", userComments);
      return userComments;
  
    } catch (error) {
      console.error('Error searching live videos:', error);
      throw new Error('Error searching live videos: ' + error.message);
    }
  }
  

  async generateTopicJokes(topic) {
    try {
      if (this.cache[topic]) {
        console.log('Returning cached jokes for topic:', topic);
        return this.cache[topic].topicJokes;
      }

      const topicPrompt = `Tell me 50 jokes related to "${topic}", each less than 20 words.`;
      const topicResponse = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [
          { role: "system", content: "You are a helpful assistant." },
          { role: "user", content: topicPrompt },
        ],
      });

      const topicJokes = topicResponse.choices[0].message.content.split("\n").filter(joke => joke.trim());
      this.cache[topic] = this.cache[topic] || {};
      this.cache[topic].topicJokes = topicJokes;
      this.saveCache();

      return topicJokes;
    } catch (error) {
      console.error("Error generating topic jokes:", error);
      return [];
    }
  }

  async generatePostJokes(hashtag) {
    try {
      // Fetch posts based on hashtag
      const posts = await this.searchHashtags(hashtag);
      const postJokes = [];
      const limitedPosts = posts.slice(0, 20);  // Limit to the first 20 posts

      for (const post of limitedPosts) {
        const postContent = post.title + ' ' + post.description + ' '+post.comments;
        const postPrompt = `Generate 25 jokes related to the following post content: "${postContent}"`;

        try {
          const postResponse = await openai.chat.completions.create({
            model: "gpt-3.5-turbo",
            messages: [
              { role: "system", content: "You are a humorous assistant." },
              { role: "user", content: postPrompt },
            ],
          });

          const postSpecificJokes = postResponse.choices[0].message.content.split("\n").filter(joke => joke.trim());
          // postJokes.push(...postSpecificJokes);
          postJokes.push(postSpecificJokes);
        } catch (error) {
          console.error(`Error generating jokes for post: ${post.title}`);
          postJokes.push([]);
        }
      }

      return postJokes;
    } catch (error) {
      console.error("Error generating post jokes:", error);
      return [];
    }
  }

  shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]]; // Swap elements
    }
    return array;
  }
  async JokesFile(topic, shuffledTopicJokes) {
    try {
      const jokesFilePath = path.join(__dirname, `${slugify(topic)}_topic_jokes.json`);
      const jokesData = {
        topicJokes: shuffledTopicJokes,
      };

      fs.writeFileSync(jokesFilePath, JSON.stringify(jokesData, null, 2));
      console.log(`Topic jokes saved to ${jokesFilePath}`);
    } catch (error) {
      console.error("Error saving topic jokes to file:", error);
    }
  }

  async SaveJokeFile(topic) {
    try {
      const topicJokes = await this.generateTopicJokes(topic);
      if (!topicJokes || topicJokes.length === 0) {
        console.log("No topic jokes generated.");
        return;
      }

      // Save the generated jokes to cache
      this.cache[topic] = { topicJokes };
      this.saveCache();

      const shuffledTopicJokes = this.shuffleArray(topicJokes); // Shuffle the topic jokes
      await this.JokesFile(topic, shuffledTopicJokes);
    } catch (error) {
      console.error("Error in SaveJokeFile:", error.message);
    }
  }

  async JokesFilePosts(posts, shuffledPostJokes) {
    try {
      // Use the first 20 characters of the posts string for the filename if posts is a single string
      const filename = Array.isArray(posts)
        ? "posts"
        : slugify(posts.substring(0, 20));

      const jokesFilePath = path.join(__dirname, `${filename}_post_jokes.json`);
      const jokesData = {
        postJokes: shuffledPostJokes,
      };

      fs.writeFileSync(jokesFilePath, JSON.stringify(jokesData, null, 2));
      console.log(`Post-specific jokes saved to ${jokesFilePath}`);
    } catch (error) {
      console.error("Error saving post-specific jokes to file:", error);
    }
  }

  async SavePostsJokeFile(posts) {
    try {
      // Fetch post-specific jokes directly, assuming they are already generated and cached
      const postJokes = this.cache[posts]?.postJokes;

      // If no jokes are found in the cache, log and exit
      if (!postJokes || postJokes.length === 0) {
        console.log("No post-specific jokes generated.");
        return;
      }

      // Save the generated jokes to a file directly
      await this.JokesFilePosts(posts, postJokes);  // Directly save the post-specific jokes
    } catch (error) {
      console.error("Error in SavePostsJokeFile:", error.message);
    }
  }


  async postC(postUrl, joke, username) {
    try {
    
      // Preprocess the joke to remove numbers or numbered prefixes
      const cleanJoke = joke.replace(/^\d+\.\s*/, ''); // Remove numbers followed by a period and space
      console.log(`Posting joke: "${cleanJoke}" to ${postUrl}`);
      await this.page.goto(postUrl, { timeout: 60000 });
      await this.page.waitForSelector('#write-inp_comment', { visible: true });
      await this.page.fill('#write-inp_comment', `${cleanJoke} @${username} #beladed`);
      await this.page.waitForSelector('button.btn-basic.blue', { visible: true });
      await this.page.click('button.btn-basic.blue');
      console.log("joke Posted successfully");
    } catch (error) {
      console.error(`Failed to post comment on ${postUrl}:`, error.message)
    }
  }

  async automateCommentingVideo(hashtag) {
    try {
      const posts = await this.searchHashtags(hashtag);

      for (const post of posts) {
        const postUrl = post.postUrl;
        const topicJokes = await this.generateTopicJokes(post.title);
        const postSpecificJokes = await this.generatePostJokes(hashtag);

        const allJokes = this.shuffleArray([
          ...topicJokes,
          ...postSpecificJokes.flat(),
        ]);
    
        const jokeToPost = allJokes[0]; // You can select a different one if you prefer
      await this.postC(postUrl, jokeToPost, post.username);
      
    }
    } catch (error) {
      console.error("Error automating commenting:", error.message);
    }
  }


  async close() {
    await this.browser.close();
  }
}

module.exports = AfreecaLive;

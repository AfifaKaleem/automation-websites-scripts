const express = require("express");
const AfreecaLive = require("./AfreecaLive");
const app = express();
const port = 3000;

app.use(express.json());

let afreecaLive;

app.post("/api/automation/afreecatv/login", async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.json({ message: "Username and Password are required" });
  }

  if (!afreecaLive) {
    afreecaLive = new AfreecaLive();
    await afreecaLive.init();
  }
  const loginResponse = await afreecaLive.login(username, password);
  res.json(loginResponse);
});

app.get("/api/automation/afreecatv/stream-details", async (req, res) => {
  if (!afreecaLive) {
    return res.json({ message: "Please login first" });
  }
  const streamDetails = await afreecaLive.getStreamDetails();
  res.json(streamDetails);
});

app.post("/api/automation/afreecatv/update-title", async (req, res) => {
  const { title } = req.body;
  if (!title) {
    return res.json({ message: "Title is required" });
  }

  if (!afreecaLive) {
    return res.json({ message: "Please login first" });
  }
  const updateResponse = await afreecaLive.updateStreamTitle(title);
  res.json(updateResponse);
});

app.get("/api/automation/afreecatv/logout", async (req, res) => {
  if (!afreecaLive) {
    return res.json({ message: "Please login first" });
  }
  await afreecaLive.close();
  afreecaLive = null;
  res.json("Logout Successfull");
});

// New endpoint to search hashtags on AfreecaTV
app.post("/api/automation/afreecatv/search-hashtags", async (req, res) => {
  const { hashtag } = req.body;
  if (!hashtag) {
    return res.status(400).json({ message: "Hashtag is required" });
  }

  if (!afreecaLive) {
    return res.status(403).json({ message: "Please login first" });
  }

  try {
    const searchResults = await afreecaLive.searchHashtags(hashtag);
    res.json({searchResults});
  } catch (error) {
    res.status(500).json({ message: "Failed to search hashtags", error: error.message });
  }
});

/**
 * Endpoint to automate commenting on posts based on hashtag.
 */
app.post("/api/automation/afreecatv/automate-commentingVideo", async (req, res) => {
  const { hashtag } = req.body;
  if (!afreecaLive) {
    return res.status(400).json({ message: "Please log in first" });
  }


  if (!hashtag) {
    return res.status(400).json({ message: "Hashtag is required" });
  }


  try {
    await afreecaLive.automateCommentingVideo(hashtag);
    res.status(200).json({ message: "Commenting automation completed successfully" });
  } catch (error) {
    console.error("Commenting automation failed:", error);
    res.status(500).json({ message: "Commenting automation failed.", error: error.message });
  }
});

/**
 * Endpoint to generate jokes based on a topic.
 */
app.post("/api/automation/afreecatv/generate-jokes-topic", async (req, res) => {
  const { topic} = req.body;

  if (!topic) {
    return res.status(400).json({ message: "Topic is required" });
  }

  try {
    const jokes = await afreecaLive.generateTopicJokes(topic);
    res.status(200).json({ jokes });
  } catch (error) {
    console.error("Joke generation failed:", error);
    res.status(500).json({ message: "Joke generation failed.", error: error.message });
  }
});


/**
 * Endpoint to generate jokes based on a topic.
 */
app.post("/api/automation/afreecatv/generate-jokes-posts", async (req, res) => {
  const { posts} = req.body;

  if (!posts) {
    return res.status(400).json({ message: "Topic is required" });
  }

  try {
    const jokes = await afreecaLive.generatePostJokes(posts);
    res.status(200).json({ jokes });
  } catch (error) {
    console.error("Joke generation failed:", error);
    res.status(500).json({ message: "Joke generation failed.", error: error.message });
  }
});
/**
 * Endpoint to save jokes to a file.
 */
app.post("/api/automation/afreecatv/save-jokes-topic",  async (req, res) => {
  const {  topic} = req.body;
  if (!afreecaLive) {
    return res.status(400).json({ message: "Please log in first" });
  }
  try {
    await afreecaLive.SaveJokeFile(topic);
    res.status(200).json({ message: `Jokes saved for "${topic}".` });
  } catch (error) {
    console.error("Saving jokes failed:", error);
    res.status(500).json({ message: "Failed to save jokes.", error: error.message });
  }
});

app.post("/api/automation/afreecatv/save-jokes-posts",  async (req, res) => {
  const {  posts} = req.body;
  if (!afreecaLive) {
    return res.status(400).json({ message: "Please log in first" });
  }
  try {
    await afreecaLive.SavePostsJokeFile(posts);
    res.status(200).json({ message: `Jokes saved for "${posts}".` });
  } catch (error) {
    console.error("Saving jokes failed:", error);
    res.status(500).json({ message: "Failed to save jokes.", error: error.message });
  }
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});

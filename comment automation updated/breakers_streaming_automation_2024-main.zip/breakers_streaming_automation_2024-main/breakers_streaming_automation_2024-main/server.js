const express = require("express");
const BreakersLive = require("./BreakersLive");
const app = express();
const port = 3000;

app.use(express.json());

let breakersLive;

app.post("/api/automation/breakers/login", async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.json({ message: "Username and Password are required" });
  }

  if (!breakersLive) {
    breakersLive = new BreakersLive();
    await breakersLive.init();
  }
  const loginResponse = await breakersLive.login(username, password);
  res.json(loginResponse);
});

app.get("/api/automation/breakers/stream-details", async (req, res) => {
  if (!breakersLive) {
    return res.json({ message: "Please login first" });
  }
  const streamDetails = await breakersLive.getStreamDetails();
  res.json(streamDetails);
});

app.post("/api/automation/breakers/update-description", async (req, res) => {
  const description = req.body.description || "";

  if (!breakersLive) {
    return res.json({ message: "Please login first" });
  }
  const updateResponse = await breakersLive.updateStreamDescription(
    description
  );
  res.json(updateResponse);
});

app.post("/api/automation/breakers/search", async (req, res) => {
  const { pageUrl } = req.body;

  if (!pageUrl || typeof pageUrl !== "string" || !pageUrl.startsWith("http")) {
      return res.status(400).send({ error: "Invalid pageUrl" });
  }

  try {
      const results = await breakersLive.scrapeSearchResults(pageUrl);
      res.json(results);
  } catch (error) {
      console.error("Error during scraping:", error);
      res.status(500).send({ error: error.message });
  }
});

/**
 * Endpoint to automate commenting on posts based on hashtag.
 */
app.post("/api/automation/breakers/automate-commenting", async (req, res) => {
  const { pageUrl } = req.body;
  if (!breakersLive) {
    return res.status(400).json({ message: "Please log in first" });
  }


  if (!pageUrl) {
    return res.status(400).json({ message: "Hashtag is required" });
  }


  try {
    await breakersLive.automateCommenting(pageUrl);
    res.status(200).json({ message: "Commenting automation completed successfully" });
  } catch (error) {
    console.error("Commenting automation failed:", error);
    res.status(500).json({ message: "Commenting automation failed.", error: error.message });
  }
});

/**
 * Endpoint to generate jokes based on a topic.
 */
app.post("/api/automation/breakers/generate-jokes-topic", async (req, res) => {
  const { topic } = req.body;

  if (!topic) {
    return res.status(400).json({ message: "Topic is required" });
  }

  try {
    const jokes = await breakersLive.generateTopicJokes(topic);
    res.status(200).json({ jokes });
  } catch (error) {
    console.error("Joke generation failed:", error);
    res.status(500).json({ message: "Joke generation failed.", error: error.message });
  }
});

app.post("/api/automation/breakers/generate-jokes-posts", async (req, res) => {
  const { posts} = req.body;

  if (!posts) {
    return res.status(400).json({ message: "Topic is required" });
  }

  try {
    const jokes = await breakersLive.generatePostJokes(posts);
    res.status(200).json({ jokes });
  } catch (error) {
    console.error("Joke generation failed:", error);
    res.status(500).json({ message: "Joke generation failed.", error: error.message });
  }
});

/**
 * Endpoint to save jokes to a file.
 */
app.post("/api/automation/breakers/save-jokes-topic",  async (req, res) => {
  const {  topic } = req.body;
  if (!breakersLive) {
    return res.status(400).json({ message: "Please log in first" });
  }


  try {
    await breakersLive.SaveJokeFile(topic);
    res.status(200).json({ message: `Jokes saved for "${topic}".` });
  } catch (error) {
    console.error("Saving jokes failed:", error);
    res.status(500).json({ message: "Failed to save jokes.", error: error.message });
  }
});

app.post("/api/automation/breakers/save-jokes-posts",  async (req, res) => {
  const { posts } = req.body;
  if (!breakersLive) {
    return res.status(400).json({ message: "Please log in first" });
  }
  try {
    await breakersLive.SavePostsJokeFile(posts);
    res.status(200).json({ message: `Jokes saved for "${posts}".` });
  } catch (error) {
    console.error("Saving jokes failed:", error);
    res.status(500).json({ message: "Failed to save jokes.", error: error.message });
  }
});
app.get("/api/automation/breakers/logout", async (req, res) => {
  if (!breakersLive) {
    return res.json({ message: "Please login first" });
  }
  await breakersLive.logout();
  await breakersLive.close();
  breakersLive = null;
  res.send("Log out successful");
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});

const { chromium } = require("playwright");
// const fs = require('fs/promises');
const fs = require('fs');
const path = require('path');
const { OpenAI } = require('openai');
const slugify = require('slugify');
require('dotenv').config();

const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY,
});


class BreakersLive {
  constructor() {
    this.browser = null;
    this.page = null;
    this.cache={};
  }

    // Helper functions to manage caching
    loadCache() {
        const cacheFile = path.join(__dirname, 'jokes_cache.json');
        if (fs.existsSync(cacheFile)) {
            try {
                const data = fs.readFileSync(cacheFile, 'utf8');
                this.cache = JSON.parse(data);
            } catch (error) {
                console.error('Error loading cache:', error);
            }
        }
    }

    saveCache() {
        const cacheFile = path.join(__dirname, 'jokes_cache.json');
        try {
            fs.writeFileSync(cacheFile, JSON.stringify(this.cache, null, 2));
        } catch (error) {
            console.error('Error saving cache:', error);
        }
    }


  async init() {
    this.browser = await chromium.launch({
      headless: false,
      channel: "chrome",
    });
    const context = await this.browser.newContext();
    this.page = await context.newPage();
  }

  async login(username, password) {
    try {
      await this.page.goto("https://breakers.tv", { timeout: 180000 });

      // Click the Sign In button
      await this.page.click(".menu2Broadcast");

      // Wait for the sign-in modal to appear
      await this.page.waitForSelector('form[action="/signin?a=process"]', {
        timeout: 60000,
      });

      // Fill in username
      await this.page.fill('input[name="u2"]', username);

      // Fill in password
      await this.page.fill('input[name="p2"]', password);

      // Submit the form
      await this.page.click('input[type="submit"].menuBtnBlue');

      // Wait for login confirmation, assuming successful login redirects or changes the DOM
      await this.page.waitForTimeout(5000); // Adjust time according to actual loading time

      console.log("Login successful");
      return { success: true, message: "Login successful" };
    } catch (error) {
      console.error("Error logging in:", error);
      return { success: false, message: "Error logging in: " + error.message };
    }
  }

  async getStreamDetails() {
    try {
      // Navigate to the channel settings page
      await this.page.goto("https://breakers.tv/settings/channel", {
        timeout: 60000,
      });

      // Extract the stream key
      const streamKey = await this.page.$eval(
        'input[name="embed_link"]',
        (el) => el.value
      );

      // Extract the ingest servers, ignoring the first entry where location is "Select"
      const ingestServers = await this.page.evaluate(() => {
        const servers = [];
        const serverForms = document.querySelectorAll('form[name^="frmSK"]');

        serverForms.forEach((form) => {
          const serverUrl = form.querySelector(
            'input[name="embed_link"]'
          ).value;
          const serverLocation = form
            .querySelector("div.menuBtnBlue")
            .innerText.trim();

          // Ignore the first entry with location "Select"
          if (serverLocation.toLowerCase() !== "select") {
            servers.push({ serverUrl, serverLocation });
          }
        });

        return servers;
      });

      console.log("Stream details retrieved:", { streamKey, ingestServers });
      return { success: true, streamKey, ingestServers };
    } catch (error) {
      console.error("Error retrieving stream details:", error);
      return {
        success: false,
        message: "Error retrieving stream details: " + error.message,
      };
    }
  }

  async updateStreamDescription(description) {
    try {
      // Navigate to the channel settings page
      await this.page.goto("https://breakers.tv/settings/channel", {
        timeout: 60000,
      });

      // Locate the textarea for stream description
      const descriptionArea = await this.page.$('textarea[name="chanAbout"]');

      if (descriptionArea) {
        // Clear the existing text
        await descriptionArea.fill("");

        // Add the new description
        await descriptionArea.type(description);

        // Click the save button
        await this.page.click(
          '.settingsSaveBtn[onclick="Settings.updateAbout();"]'
        );

        // Wait for a brief moment to ensure the action is completed
        await this.page.waitForTimeout(2000);

        console.log("Stream description updated successfully");
        return {
          success: true,
          message: "Stream description updated successfully",
        };
      } else {
        console.error("Failed to find the stream description textarea");
        return {
          success: false,
          message: "Failed to find the stream description textarea",
        };
      }
    } catch (error) {
      console.error("Error updating stream description:", error);
      return {
        success: false,
        message: "Error updating stream description: " + error.message,
      };
    }
  }

  async logout() {
    try {
      // Navigate to the logout URL or perform the logout action
      await this.page.goto("https://breakers.tv/logout", { timeout: 60000 });
      console.log("Log out successful");
    } catch (error) {
      console.error("Error logging out:", error);
    }
  }

  async scrapeSearchResults(pageUrl) {
    
      // Ensure postUrl is valid
      if (typeof pageUrl !== "string" || !pageUrl.startsWith("http")) {
          console.error(`Invalid post URL:`, pageUrl);
      }

      console.log("Navigating to:", pageUrl);
    try {
        // Navigate to the page with the search results
        await this.page.goto(pageUrl);

        // Wait for search results to load
        await this.page.waitForSelector('.catPageContainerLeft');

        // Extract search results
        const searchResults = await this.page.evaluate(() => {
            const results = [];
            const items = document.querySelectorAll('.browsePageStreamBox');

            items.forEach(item => {
                // const title = item.querySelector('.catPageTitle2')?.innerText || '';
                const displayName = item.querySelector('.browserPageStreamBox_lower_account')?.innerText.trim() || '';
                const username = displayName;
                const description = item.querySelector('.browserPageStreamBox_lower_status')?.innerText.trim() || '';
                const photoUrl = item.querySelector('.browsePageStreamBox_inner img')?.src || '';
                const postUrl = item.querySelector('a')?.href || '';

                results.push({ displayName, username, title:description, description, photoUrl, profileUrl:postUrl, postUrl });
            });

            return results;
        });

        console.log('Search Results:', searchResults);

        // Visit each post URL and extract existing comments
        for (let result of searchResults) {
            if (result.postUrl) {
                await this.page.goto(result.postUrl);
                await this.page.waitForTimeout(2000); // Adjust as necessary for page load

                const existingComments = await this.page.evaluate(() => {
                    const comments = [];
                    const commentElements = document.querySelectorAll('ul.vs_chatv9_chatbox >li '); // Update with the correct selector
                    commentElements.forEach(comment => {
                      const commentText = comment.querySelector('ul.vs_chatv9_chatbox >li div.vs_chatv9_msg_body')?.innerText.trim(); // Extract only the text content
                      if (commentText) {
                          comments.push(commentText); // Push only the comment text
                      }
                  });

                  return comments;
              });

              result.existingComments = existingComments;
          }
      }

      console.log('Final Results with Comments:', searchResults);
      return searchResults;

  } catch (error) {
      console.error('Error:', error);
  }
}


  async postComment(postUrl, joke, username) {
    try {
      if (!postUrl) {
        console.error("Error: postUrl is undefined or invalid.");
        return;
      }

      const cleanJoke = joke.replace(/^\d+\.\s*/, "");
      await this.page.goto(postUrl, { timeout: 70000 });

      await this.page.waitForSelector('textarea[placeholder="Type something nice..."]', {
        visible: true,
        timeout: 70000,
      });

      const commentField = await this.page.$('textarea[placeholder="Type something nice..."]');
      if (commentField) {
        await commentField.click();
        await this.page.type('textarea[placeholder="Type something nice..."]', `${cleanJoke} @${username} #beladed`, {
          delay: 100,
        });
      }

      await this.page.waitForSelector('div.vs_chatv9_input_options_btn_send', {
        visible: true,
      });
      await this.page.click('div.vs_chatv9_input_options_btn_send');

      console.log(`Comment posted successfully on ${postUrl}: "${cleanJoke}"`);
    } catch (error) {
      console.error(`Failed to post comment on ${postUrl}:`, error.message);
    }
  }

  async generateTopicJokes(topic) {
    try {
      if (this.cache[topic]) {
        console.log('Returning cached jokes for topic:', topic);
        return this.cache[topic].topicJokes;
      }
  
      const topicPrompt = `Tell me 50 jokes related to "${topic}", each less than 20 words.`;
      const topicResponse = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [
          { role: "system", content: "You are a helpful assistant." },
          { role: "user", content: topicPrompt },
        ],
      });
  
      const topicJokes = topicResponse.choices[0].message.content.split("\n").filter(joke => joke.trim());
      this.cache[topic] = this.cache[topic] || {};
      this.cache[topic].topicJokes = topicJokes;
      this.saveCache();
  
      return topicJokes;
    } catch (error) {
      console.error("Error generating topic jokes:", error);
      return [];
    }
  }

  async generatePostJokes(pageUrl) {
    try {
        const posts = await this.scrapeSearchResults(pageUrl);

        if (!Array.isArray(posts) || posts.length === 0) {
            console.error("No posts found to generate jokes.");
            return [];
        }

        const postJokes = [];

        for (const post of posts) {
            const postContent = `
                Title: ${post.title || "No Title"}
                Description: ${post.description || "No Description"}
                Comments: ${(post.comments || [])
                    .map(comment => comment.commentText)
                    .join(" ") || "No Comments"}
            `;

            const postPrompt = `Generate 25 unique, humorous, and post-specific jokes inspired by the following content:\n${postContent}`;

            try {
                console.log("Generating jokes for post:", post.title || "Untitled Post");

                const postResponse = await openai.chat.completions.create({
                    model: "gpt-3.5-turbo",
                    messages: [
                        { role: "system", content: "You are a humorous assistant." },
                        { role: "user", content: postPrompt },
                    ],
                });

                const jokes = postResponse.choices[0].message.content
                    .split("\n")
                    .filter(joke => joke.trim());

                postJokes.push({ post, jokes });
            } catch (error) {
                console.error(`Error generating jokes for post: ${post.title || "Unknown Title"}`, error);
                postJokes.push({ post, jokes: [] });
            }
        }

        console.log("Generated Jokes:", JSON.stringify(postJokes, null, 2));
        return postJokes;

    } catch (error) {
        console.error("Error generating post jokes:", error);
        return [];
    }
}

  async JokesFile(topic, shuffledTopicJokes) {
    try {
        const jokesFilePath = path.join(__dirname, `${slugify(topic)}_topic_jokes.json`);
        const jokesData = {
            topicJokes: shuffledTopicJokes,
        };

        fs.writeFileSync(jokesFilePath, JSON.stringify(jokesData, null, 2));
        console.log(`Topic jokes saved to ${jokesFilePath}`);
    } catch (error) {
        console.error("Error saving topic jokes to file:", error);
    }
}

async SaveJokeFile(topic) {
    try {
        const topicJokes = await this.generateTopicJokes(topic);
        if (!topicJokes || topicJokes.length === 0) {
            console.log("No topic jokes generated.");
            return;
        }

        // Save the generated jokes to cache
        this.cache[topic] = { topicJokes };
        this.saveCache();

        const shuffledTopicJokes = this.shuffleArray(topicJokes); // Shuffle the topic jokes
        await this.JokesFile(topic, shuffledTopicJokes);
    } catch (error) {
        console.error("Error in SaveJokeFile:", error.message);
    }
}

async JokesFilePosts(posts, shuffledPostJokes) {
    try {
        const jokesFilePath = path.join(__dirname, `${slugify(posts)}_post_jokes.json`);
        const jokesData = {
            postJokes: shuffledPostJokes,
        };

        fs.writeFileSync(jokesFilePath, JSON.stringify(jokesData, null, 2));
        console.log(`Topic jokes saved to ${jokesFilePath}`);
    } catch (error) {
        console.error("Error saving topic jokes to file:", error);

    }
}

async SavePostsJokeFile(posts) {
    try {
        const postJokes = await this.generatePostJokes(posts);
        if (!postJokes || postJokes.length === 0) {
            console.log("No topic jokes generated.");
            return;
        }

        // Save the generated jokes to cache
        this.cache[posts] = { postJokes };
        this.saveCache();

        const shuffledPostJokes = this.shuffleArray(postJokes); // Shuffle the topic jokes
        await this.JokesFilePosts(posts, shuffledPostJokes);
    } catch (error) {
        console.error("Error in SavePostsJokeFile:", error.message);
    }
}

  async automateCommenting(pageUrl) {
    // Automation logic
    try {
      // Step 1: Search for posts using the provided hashtag
      const searching= await this.scrapeSearchResults(pageUrl);
      
      if (searching.length === 0) {
        console.log('No posts found with the provided hashtag.');
        return;
      }
  
      // Step 2: Generate jokes for the posts
      const postJokes = await this.generatePostJokes(pageUrl);
      if (postJokes.length === 0) {
        console.log('No jokes generated for the posts.');
        return;
      }
  
      // Step 3: Shuffle the jokes for randomness
      const shuffledPostJokes = this.shuffleArray(postJokes);
  
      // Step 4: Iterate over posts to post comments
      for (let i = 0; i < searching.length; i++) {
        const post = searching[i];
  
        // Ensure videoUrl exists
        if (!post.postUrl) {
          console.error(`Error: videoUrl is undefined or invalid for post: ${post.title}`);
          continue;  // Skip this post
        }
  
        // Step 4: Select one joke from the shuffled list
        const joke = shuffledPostJokes[i]?.jokes[0] || "Here's a funny joke!"; // Choose the first joke after shuffling
        
        // Post the comment to the video
        await this.postComment(post.postUrl, joke, post.username);
  
        console.log(`Comment posted: "${joke}" on ${post.postUrl}`);
      }
  
      console.log("Automated commenting completed for all search results.");
    } catch (error) {
      console.error("Error during automated commenting:", error.message);
    }
  }

  shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
  }

  async close() {
    await this.browser.close();
  }
}

module.exports = BreakersLive;

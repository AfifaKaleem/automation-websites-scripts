const { chromium } = require("playwright");
const fs = require('fs');
const path = require('path');
const { OpenAI } = require('openai');
const slugify = require('slugify');
// const { title } = require("process");
require('dotenv').config();

const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY,
});


class InstagramLive {
  constructor() {
    this.browser = null;
    this.page = null;
    this.cache= {};
  }
  // Helper functions to manage caching
  loadCache() {
    const cacheFile = path.join(__dirname, 'jokes_cache.json');
    if (fs.existsSync(cacheFile)) {
        try {
            const data = fs.readFileSync(cacheFile, 'utf8');
            this.cache = JSON.parse(data);
        } catch (error) {
            console.error('Error loading cache:', error);
        }
    }
}

saveCache() {
    const cacheFile = path.join(__dirname, 'jokes_cache.json');
    try {
        fs.writeFileSync(cacheFile, JSON.stringify(this.cache, null, 2));
    } catch (error) {
        console.error('Error saving cache:', error);
    }
}

async initialize() {
  // Launch a new browser instance
  this.browser = await chromium.launch({
      headless: false, // Set to true to run in the background
      args: ['--start-maximized'], // Start the browser in full-screen mode
  });

  // Create a new page
  this.page = await this.browser.newPage();

  // Set the viewport size
  await this.page.setViewportSize({
      width: 1920,  // You can adjust this based on your screen resolution
      height: 1080  // You can adjust this based on your screen resolution
  });
}

  async login(username, password) {
    await this.initialize();

    // Navigate to Instagram
    await this.page.goto("https://www.instagram.com/");

    // Wait for the login form to appear
    await this.page.waitForSelector('input[name="username"]');
    await this.page.waitForSelector('input[name="password"]');

    // Fill in the username and password
    await this.page.fill('input[name="username"]', username);
    await this.page.waitForTimeout(1000); // Pause to mimic human behavior
    await this.page.fill('input[name="password"]', password);
    await this.page.waitForTimeout(1000); // Pause to mimic human behavior

    // Click the login button
    await this.page.click('button[type="submit"]');

    // Wait for navigation after login
    await this.page.waitForNavigation();

    this.isLoggedIn = true;
    console.log("Logged in to Instagram successfully.");

    return {
      status: "success",
      message: "Logged in to Instagram successfully.",
    };
  }

  async logout() {
    // First, check if the user is logged in
    if (!this.isLoggedIn) {
      throw new Error("User is not logged in");
    }

    // Locate the "More" button by targeting the span containing the text "More"
    const moreButton = await this.page.locator(
      '//span[contains(text(), "More")]'
    );
    await moreButton.click();
    await this.page.waitForTimeout(1500); // Pause to ensure the dropdown opens

    // Locate the "Log Out" option by targeting the span containing the text "Log out"
    const logoutButton = await this.page.locator(
      '//span[contains(text(), "Log out")]'
    );
    await logoutButton.click();

    // Optionally, wait for navigation to ensure logout is complete
    await this.page.waitForNavigation();

    this.isLoggedIn = false;
    console.log("Logged out of Instagram successfully.");
    return {
      status: "success",
      message: "Logged out of Instagram successfully.",
    };
  }

  async getStreamDetails(audience, title) {
    // First, check if the user is logged in
    if (!this.isLoggedIn) {
      throw new Error("User is not logged in");
    }

    // Click on the "Create" button
    const createButton = await this.page.locator(
      '//span[contains(text(), "Create")]'
    );
    await createButton.click();
    await this.page.waitForTimeout(1000); // Wait for 1 second

    // Click on "Live video"
    const liveVideoButton = await this.page.locator(
      '//span[contains(text(), "Live video")]'
    );
    await liveVideoButton.click();

    // Wait for the "Add live video details" text to appear
    await this.page.waitForSelector(
      '//span[contains(text(), "Add live video details")]'
    );

    // Fill in the title
    await this.page.fill(
      'input[name="live-creation-modal-create-screen-title-input"]',
      title
    );
    await this.page.waitForTimeout(563); // Wait for 563 milliseconds

    // Click on the "Audience" button
    const audienceButton = await this.page.locator(
      '//span[contains(text(), "Audience")]'
    );
    await audienceButton.click();

    // Wait for the audience dialog to appear
    await this.page.waitForSelector('div[role="dialog"]');

    // Click on the appropriate audience button based on the user's choice
    const audienceSelector = `//button[contains(text(), "${audience}")]`;
    const audienceOptionButton = await this.page.locator(audienceSelector);
    await audienceOptionButton.click();

    // Click the "Next" button (using text-based selector)
    const nextButton = await this.page.locator(
      '//div[contains(text(), "Next")]'
    );
    await nextButton.click();

    // Wait for the next page or element that contains stream URL and key
    await this.page.waitForSelector(
      'input[name="live-creation-modal-start-pane-stream-url"]'
    );
    await this.page.waitForSelector(
      'input[name="live-creation-modal-start-pane-stream-key"]'
    );

    // Get the stream URL and key
    const streamUrl = await this.page.inputValue(
      'input[name="live-creation-modal-start-pane-stream-url"]'
    );
    const streamKey = await this.page.inputValue(
      'input[name="live-creation-modal-start-pane-stream-key"]'
    );

    // Set the flag that stream details have been retrieved
    this.hasStreamDetails = true;

    return {
      streamUrl,
      streamKey,
      audience,
      title,
    };
  }

  async goLive() {
    // Check if the user has retrieved stream details
    if (!this.hasStreamDetails) {
      throw new Error(
        "Stream details have not been retrieved. Please get the stream details first."
      );
    }

    // Locate the second "Go Live" button by targeting the second h4 element containing the text "Go live"
    const goLiveButton = await this.page.locator(
      '(//h4[contains(text(), "Go live")])[2]/ancestor::button'
    );

    // Check if the "Go Live" button is disabled
    const isDisabled = await goLiveButton.isDisabled();
    if (isDisabled) {
      throw new Error(
        "Instagram is not receiving the video/audio signals. Please start the stream from your client streaming software."
      );
    }

    // Click the "Go Live" button
    await goLiveButton.click();

    this.isStreamStarted = true;
    console.log("Stream started successfully.");
    return {
      status: "success",
      message: "Stream started successfully.",
    };
  }

  async stopLiveStream() {
    // Check if the stream is started
    if (!this.isStreamStarted) {
      throw new Error("No stream is currently started.");
    }

    // Locate the "Stop Live Video" button by targeting the h4 element containing the text "Stop live video."
    const stopLiveButton = await this.page.locator(
      '(//h4[contains(text(), "End live video")])[2]/ancestor::button'
    );

    // Click the "Stop Live Video" button
    await stopLiveButton.click();

    this.isStreamStarted = false;
    console.log("Stream stopped successfully.");
    return {
      status: "success",
      message: "Stream stopped successfully.",
    };
  }



  async searchHashtag(hashtag) {
    try {
        // Navigate to the hashtag search page
        await this.page.goto(`https://www.instagram.com/explore/tags/${hashtag}/`);

        // Wait for the main content to load
        await this.page.waitForSelector('main', { timeout: 60000 });

        // Scroll to load more posts
        const totalScrollHeight = 10000; // Adjust this value to how much you want to scroll
        let lastHeight = 0;
        while (true) {
            // Scroll down to the bottom
            await this.page.evaluate('window.scrollTo(0, document.body.scrollHeight);');
            await this.page.waitForTimeout(2000); // Wait for new posts to load

            // Get the new scroll height and compare it with the last scroll height
            const newHeight = await this.page.evaluate('document.body.scrollHeight');
            if (newHeight === lastHeight || newHeight > totalScrollHeight) break;
            lastHeight = newHeight;
        }

        // Extract hashtag data
        const hashtagResults = await this.page.$$eval('main a', (elements) => {
            return elements.map((el) => {
                const href = el.getAttribute('href');
                const username = href ? href.split('/')[1] : null; // Username extracted from href
                const profileUrl = username ? `https://www.instagram.com/${username}/` : null; // Full profile URL

                // Extract post URL
                const postUrl = el ? el.href : null;

                // Extract image URL (if available)
                const imageElement = el.querySelector('img');
                const imageUrl = imageElement ? imageElement.src : "No image"; // Image URL
                const title = imageElement ? imageElement.alt : "No title"; // Title extracted from the alt attribute

                // Extract the description (alt text of image)
                const description = imageElement ? imageElement.alt : null;

                // Try to extract existing comments - handle dynamic comment section
              

                return {
                    username,
                    displayname: username,
                    description,
                    profileUrl,
                    postUrl,
                    imageUrl,
                    title
                };
            }).filter(result => result.username); // Filter out results without a username
        });  // Extract comments for each video
        const userComments = [];
        for (const user of hashtagResults) {
          if (user.postUrl) {
            console.log(`Navigating to video page: ${user.postUrl}`);
            await this.page.goto(user.postUr);
    
            // Wait for comments to load (handling potential delays)
            try {
              await this.page.waitForSelector('span._ap3a', { timeout: 70000 });
            } catch (e) {
              console.log(`Comments not visible for post: ${user.postUrl}. Skipping.`);
              continue;
            }
    
            // Extract the comments
            const comments = await this.page.$$eval('span._ap3a', (commentNodes) => {
              return commentNodes.map(commentNode => {
                const commentText = commentNode.querySelector('span._ap3a')?.textContent.trim() || 'No text';
                return { commentText };
              });
            });
    
            userComments.push({
              ...user,
              comments
            });
    
            console.log(`Extracted ${comments.length} comments from video: ${user.postUrl}`);
          }
        }
    
        console.log("Comments extraction complete.");
        return { userComments };

    } catch (error) {
        console.error("Error searching for hashtags:", error);
        throw new Error("Error searching for hashtags: " + error.message);
    }
}

async generateTopicJokes(topic) {
  try {
    if (this.cache[topic]) {
      console.log('Returning cached jokes for topic:', topic);
      return this.cache[topic].topicJokes;
    }

    const topicPrompt = `Tell me 50 jokes related to "${topic}", each less than 20 words.`;
    const topicResponse = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        { role: "system", content: "You are a helpful assistant." },
        { role: "user", content: topicPrompt },
      ],
    });

    const topicJokes = topicResponse.choices[0].message.content.split("\n").filter(joke => joke.trim());
    this.cache[topic] = this.cache[topic] || {};
    this.cache[topic].topicJokes = topicJokes;
    this.saveCache();

    return topicJokes;
  } catch (error) {
    console.error("Error generating topic jokes:", error);
    return [];
  }
}

async generatePostJokes(hashtag) {
  try {
    // Fetch posts based on hashtag
    const { userComments } = await this.searchHashtag(hashtag);

    if (!Array.isArray(userComments)) {
      throw new Error("Expected an array of posts but got something else.");
    }

    const postJokes = [];
    const limitedPosts = userComments.slice(0, 20); // Limit to the first 20 posts

    for (const post of limitedPosts) {
      const postContent = `
        Title: ${post.title} 
        Description: ${post.description}
        Comments: ${post.comments.map(comment => comment.commentText).join(" ")}
      `;
      const postPrompt = `Generate 25 jokes related to the following post content: "${postContent}"`;

      try {
        const postResponse = await openai.chat.completions.create({
          model: "gpt-3.5-turbo",
          messages: [
            { role: "system", content: "You are a humorous assistant." },
            { role: "user", content: postPrompt },
          ],
        });

        const postSpecificJokes = postResponse.choices[0].message.content
          .split("\n")
          .filter(joke => joke.trim());
        postJokes.push({  jokes: postSpecificJokes });
      } catch (error) {
        console.error(`Error generating jokes for post: ${post.title}`);
        postJokes.push({ jokes: [] });
      }
    }

    // Save jokes to a JSON file
    // this.SavePostsJokeFile(hashtag, postJokes);

    return postJokes;
  } catch (error) {
    console.error("Error generating post jokes:", error);
    return [];
  }
}

shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]]; // Swap elements
    }
    return array;
}
async JokesFile(topic, shuffledTopicJokes) {
  try {
      const jokesFilePath = path.join(__dirname, `${slugify(topic)}_topic_jokes.json`);
      const jokesData = {
          topicJokes: shuffledTopicJokes,
      };

      fs.writeFileSync(jokesFilePath, JSON.stringify(jokesData, null, 2));
      console.log(`Topic jokes saved to ${jokesFilePath}`);
  } catch (error) {
      console.error("Error saving topic jokes to file:", error);
  }
}

async SaveJokeFile(topic) {
  try {
      const topicJokes = await this.generateTopicJokes(topic);
      if (!topicJokes || topicJokes.length === 0) {
          console.log("No topic jokes generated.");
          return;
      }

      // Save the generated jokes to cache
      this.cache[topic] = { topicJokes };
      this.saveCache();

      const shuffledTopicJokes = this.shuffleArray(topicJokes); // Shuffle the topic jokes
      await this.JokesFile(topic, shuffledTopicJokes);
  } catch (error) {
      console.error("Error in SaveJokeFile:", error.message);
  }
}


async SavePostsJokeFile(hashtag,shuffledPostJokes) {
try {
  const jokesFilePath = path.join(__dirname, `${hashtag}_posts_jokes.json`);
  fs.writeFileSync(jokesFilePath, JSON.stringify(shuffledPostJokes, null, 2));
  console.log(`Jokes for hashtag "${hashtag}" saved to ${jokesFilePath}`);
} catch (error) {
  console.error("Error saving jokes to file:", error);
}
}


async postComment(postUrl, joke, username) {
  try {
    if (!postUrl) {
      console.error("Error: postUrl is undefined or invalid.");
      return;
  }
  // Preprocess the joke to remove numbers or numbered prefixes
  const cleanJoke = joke.replace(/^\d+\.\s*/, ''); // Remove numbers followed by a period and space
  console.log(`Posting joke: "${cleanJoke}" to ${postUrl}`);
      await this.page.goto(postUrl, { timeout: 60000 });

      // Wait for the comment input field to load
      console.log("Waiting for the comment input field...");
      await this.page.waitForSelector('textarea[aria-label="Add a comment…"]', { visible: true, timeout: 60000 });

      // Click the comment input field
      console.log("Clicking the comment input field...");
      const commentField = await this.page.$('textarea[aria-label="Add a comment…"]');
      if (commentField) {
          await commentField.click();
      } else {
          throw new Error("Comment input field not found.");
      }

      // Type the comment
      console.log(`Typing the comment: "${cleanJoke} @${username} #beladed"`);
      await this.page.fill('textarea[aria-label="Add a comment…"]', `${cleanJoke} @${username} #beladed`, { delay: 100 });

      // Wait for the Post button to be enabled
      console.log("Waiting for the Post button...");
      await this.page.waitForSelector('div[role="button"]:not([aria-disabled="true"])', { visible: true, timeout: 10000 });

      // Click the Post button
      console.log("Clicking the Post button...");
      await this.page.waitForSelector('div[role="button"]:has-text("Post")', { visible: true, timeout: 60000 });
      await this.page.click('div[role="button"]:has-text("Post")');
    
      console.log(`Comment posted successfully on ${postUrl}: "${cleanJoke}"`);
  } catch (error) {
      console.error(`Failed to post comment on ${postUrl}:`, error.message);
  }
}

async automateCommenting(hashtag) {
  try {
    // Step 1: Search for posts using the provided hashtag
    const { userComments } = await this.searchHashtag(hashtag);
    
    if (userComments.length === 0) {
      console.log('No posts found with the provided hashtag.');
      return;
    }

    // Step 2: Generate jokes for the posts
    const postJokes = await this.generatePostJokes(hashtag);
    if (postJokes.length === 0) {
      console.log('No jokes generated for the posts.');
      return;
    }

    // Step 3: Shuffle the jokes for randomness
    const shuffledPostJokes = this.shuffleArray(postJokes);

    // Step 4: Iterate over posts to post comments
    for (let i = 0; i < userComments.length; i++) {
      const post = userComments[i];

      // Ensure postUrl exists
      if (!post.postUrl) {
        console.error(`Error: postUrl is undefined or invalid for post: ${post.title}`);
        continue;  // Skip this post
      }

      // Step 4: Select one joke from the shuffled list
      const joke = shuffledPostJokes[i]?.jokes[0] || "Here's a funny joke!"; // Choose the first joke after shuffling
      
      // Post the comment to the video
      await this.postComment(post.postUrl, joke, post.username);

      console.log(`Comment posted: "${joke}" on ${post.postUrl}`);
    }

    console.log("Automated commenting completed for all search results.");
  } catch (error) {
    console.error("Error during automated commenting:", error.message);
  }
}

  async close() {
    if (this.page) {
      await this.page.close();
    }
    if (this.context) {
      await this.context.close();
    }
    if (this.browser) {
      await this.browser.close();
    }
  }
}

module.exports = InstagramLive;

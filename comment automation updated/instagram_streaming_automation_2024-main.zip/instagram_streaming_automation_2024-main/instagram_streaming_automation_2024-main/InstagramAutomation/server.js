const express = require("express");
const InstagramLive = require("./instagramLive");

const app = express();
app.use(express.json());

const instagramLive = new InstagramLive();;
require('dotenv').config();
app.use(express.urlencoded({ extended: true })); // For parsing URL-encoded data

app.post("/login", async (req, res) => {
  const { username, password } = req.body;

  // Validate the username and password
  if (!username || !password) {
    return res.status(400).json({
      status: "error",
      message: "Username and password cannot be empty.",
    });
  }

  try {
    await instagramLive.initialize();
    await instagramLive.login(username, password);
    res
      .status(200)
      .json({ status: "success", message: "Logged in successfully." });
  } catch (error) {
    res.status(500).json({ status: "error", message: error.message });
  }
});

app.post("/logout", async (req, res) => {
  try {
    await instagramLive.logout();
    res
      .status(200)
      .json({ status: "success", message: "Logged out successfully." });
  } catch (error) {
    res.status(500).json({ status: "error", message: error.message });
  }
});

app.post("/GetStreamDetails", async (req, res) => {
  const { Audience, Title } = req.body;

  // Validate The Audience
  const ValidAudiences = ["Public", "Practice", "Close Friends"];
  if (!ValidAudiences.includes(Audience)) {
    return res.status(400).json({
      status: "error",
      message:
        "Invalid Audience Option. Accepted Values Are: Public, Practice, Close Friends.",
    });
  }

  try {
    const StreamDetails = await instagramLive.getStreamDetails(Audience, Title);
    res.status(200).json({
      status: "success",
      data: StreamDetails,
    });
  } catch (error) {
    res.status(500).json({ status: "error", message: error.message });
  }
});

app.post("/goLive", async (req, res) => {
  try {
    const goLiveResult = await instagramLive.goLive();
    res.status(200).json({
      status: "success",
      message: goLiveResult.message,
    });
  } catch (error) {
    res.status(500).json({ status: "error", message: error.message });
  }
});

app.post("/stopLiveStream", async (req, res) => {
  try {
    const stopLiveResult = await instagramLive.stopLiveStream();
    res.status(200).json({
      status: "success",
      message: stopLiveResult.message,
    });
  } catch (error) {
    res.status(500).json({ status: "error", message: error.message });
  }
});

app.post("/search-hashtags", async (req, res) => {
  const { hashtag } = req.body;

  // Validate the hashtag
  if (!hashtag) {
      return res.status(400).json({
          status: "error",
          message: "Hashtag cannot be empty.",
      });
  }

  try {
      const posts = await instagramLive.searchHashtag(hashtag);
      res.status(200).json(posts);
  } catch (error) {
      res.status(500).json({ status: "error", message: error.message });
  }
});


/**
 * Endpoint to automate commenting on posts based on hashtag.
 */
app.post("/automate-commenting", async (req, res) => {
  const { hashtag } = req.body;
  if (!instagramLive) {
    return res.status(400).json({ message: "Please log in first" });
  }


  if (!hashtag) {
    return res.status(400).json({ message: "Hashtag is required" });
  }


  try {
    await instagramLive.automateCommenting(hashtag);
    res.status(200).json({ message: "Commenting automation completed successfully" });
  } catch (error) {
    console.error("Commenting automation failed:", error);
    res.status(500).json({ message: "Commenting automation failed.", error: error.message });
  }
});

/**
 * Endpoint to generate jokes based on a topic.
 */
app.post("/generate-jokes-topic", async (req, res) => {
  const { topic } = req.body;

  if (!topic ) {
    return res.status(400).json({ message: "Topic is required" });
  }

  try {
    const jokes = await instagramLive.generateTopicJokes(topic);
    res.status(200).json({ jokes });
  } catch (error) {
    console.error("Joke generation failed:", error);
    res.status(500).json({ message: "Joke generation failed.", error: error.message });
  }
});
app.post("/generate-jokes-posts", async (req, res) => {
  const { posts } = req.body;

  if (  !posts) {
    return res.status(400).json({ message: "Topic is required" });
  }

  try {
    const jokes = await instagramLive.generatePostJokes(posts);
    res.status(200).json({ jokes,posts });
  } catch (error) {
    console.error("Joke generation failed:", error);
    res.status(500).json({ message: "Joke generation failed.", error: error.message });
  }
});

/**
 * Endpoint to save jokes to a file.
 */
app.post("/save-jokes-topic",  async (req, res) => {
  const {  topic} = req.body;
  if (!instagramLive) {
    return res.status(400).json({ message: "Please log in first" });
  }


  try {
    await instagramLive.SaveJokeFile(topic);
    res.status(200).json({ message: `Jokes saved for "${topic}".` });
  } catch (error) {
    console.error("Saving jokes failed:", error);
    res.status(500).json({ message: "Failed to save jokes.", error: error.message });
  }
});

app.post("/save-jokes-posts",  async (req, res) => {
  const {  posts} = req.body;
  if (!instagramLive) {
    return res.status(400).json({ message: "Please log in first" });
  }


  try {
    await instagramLive.SavePostsJokeFile(posts);
    res.status(200).json({ message: `Jokes saved for "${posts}".` });
  } catch (error) {
    console.error("Saving jokes failed:", error);
    res.status(500).json({ message: "Failed to save jokes.", error: error.message });
  }
});

app.listen(3000, () => {
  console.log("Server running on port 3000");
});

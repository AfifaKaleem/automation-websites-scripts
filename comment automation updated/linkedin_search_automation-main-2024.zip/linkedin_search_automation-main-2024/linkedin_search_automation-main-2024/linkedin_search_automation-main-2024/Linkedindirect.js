const { firefox, chromium, webkit } = require('playwright');
const fs = require('fs');
const path = require('path');
const { OpenAI } = require('openai');
const slugify = require('slugify');
require('dotenv').config();

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

class Linkedindirect {
  constructor(browserType = 'chromium') {
    this.browserType = browserType;
    this.browser = null;
    this.page = null;
    this.cache = {};  // In-memory cache
  }
  async init() {
    try {
      // Launch the browser and create a new context and page
      this.browser = await playwright.chromium.launch({ headless: false });
      const context = await this.browser.newContext();
      this.page = await context.newPage();

      // Load cache from file if it exists
      this.loadCache();
      console.log("Browser initialized successfully.");
    } catch (error) {
      console.error("Error initializing browser:", error);
    }
  }

  // Helper functions to manage caching
  loadCache() {
    const cacheFile = path.join(__dirname, 'jokes_cache.json');
    if (fs.existsSync(cacheFile)) {
      try {
        const data = fs.readFileSync(cacheFile, 'utf8');
        this.cache = JSON.parse(data);
      } catch (error) {
        console.error('Error loading cache:', error);
      }
    }
  }

  saveCache() {
    const cacheFile = path.join(__dirname, 'jokes_cache.json');
    try {
      fs.writeFileSync(cacheFile, JSON.stringify(this.cache, null, 2));
    } catch (error) {
      console.error('Error saving cache:', error);
    }
  }

  async init() {
    try {
      const validateBrowser = { firefox, chromium, webkit };
      if (validateBrowser[this.browserType]) {
        this.browser = await validateBrowser[this.browserType].launch({ headless: false });
        const context = await this.browser.newContext();
        this.page = await context.newPage();
        console.log(`${this.browserType} browser launched successfully`);
      } else {
        throw new Error("Invalid browser type specified");
      }
    } catch (error) {
      console.error('Error launching browser:', error);
      throw error;
    }
  }

  async login(email, password) {
    try {
      if (!this.page) {
        throw new Error("Browser not initialized. Call init() first.");
      }
      await this.page.goto('https://www.linkedin.com/');
      await this.page.click('a[data-tracking-control-name="guest_homepage-basic_nav-header-signin"]');
      await this.page.fill('input[id="username"]', email);
      await this.page.fill('input[id="password"]', password);
      await this.page.click('button[aria-label="Sign in"]');

      await this.page.waitForNavigation({ waitUntil: "networkidle" });
      console.log("Logged in successfully");
    } catch (error) {
      console.error("Error logging in:", error);
      throw error;
    }
  }
  async logout() {
    try {
      if (!this.page) {
        throw new Error("Browser not initialized. Call init() first.");
      }
      await this.page.goto('https://www.linkedin.com/m/logout/');
      console.log("Logged out successfully");
    } catch (error) {
      console.error("Error logging out:", error);
      throw error;
    }
  }


  async postInGroup(groupId, postContent) {
    try {
      if (!this.page) {
        throw new Error("Browser not initialized. Call init() first.");
      }

      // Navigate to the LinkedIn group
      await this.page.goto(`https://www.linkedin.com/groups/${groupId}`, { waitUntil: "networkidle" });
      console.log(`Navigated to group: ${groupId}`);

      // Wait for the button to start a post using the specific class and text
      await this.page.waitForSelector('button.artdeco-button--tertiary span.truncate.block.text-align-left', { timeout: 10000 });
      await this.page.click('button.artdeco-button--tertiary span.truncate.block.text-align-left');
      console.log("Clicked 'Start a post' button");

      // Wait for the text editor to load and fill in the post content
      await this.page.waitForSelector('div.ql-editor[contenteditable="true"]');
      await this.page.fill('div.ql-editor[contenteditable="true"]', postContent);
      console.log("Post content filled");

      // Wait for the 'Post' button to appear and click to submit the post
      await this.page.waitForSelector('button.share-actions__primary-action.artdeco-button--primary');
      await this.page.click('button.share-actions__primary-action.artdeco-button--primary');
      console.log("Post submitted successfully");

    } catch (error) {
      console.error("Error posting in group:", error);
      throw error;
    }
  }


  //search automation


  async searchLinkedInGroup(query) {
    if (!this.page) {
      throw new Error('Browser not initialized. Call init() first.');
    }

    // Navigate to LinkedIn search page and search for groups
    await this.page.goto('https://www.linkedin.com/search/results/groups/');

    // Fill the search bar with the query
    await this.page.fill('input[placeholder="Search"]', query);
    await this.page.press('input[placeholder="Search"]', 'Enter');

    // Wait for search results to load
    await this.page.waitForSelector('ul[role="list"]');

    // Extract group details from the search results
    const groups = await this.page.$$eval('ul[role="list"] li ', (items) => {
      return items.map(item => {
        const groupName = item.querySelector('span')?.innerText || '';
        const groupUrl = item.querySelector('a')?.href || '';
        const groupPhotoUrl = item.querySelector('img')?.src || '';
        const userName = item.querySelector('span')?.innerText || ''; // Assuming admin/moderator's name is here
        const description =item.querySelector('p')?.innerText || '';

        return {
          groupName,
          groupUrl,
          groupPhotoUrl,
          userName,
          description,
          title:description
        };
      });
    });
    // Extract comments for each video
    const userComments = [];
    for (const user of groups) {
      if (user.groupUrl) {
        console.log(`Navigating to video page: ${user.groupUrl}`);
        await this.page.goto(user.groupUrl);

        // Wait for comments to load (handling potential delays)
        try {
          // Click on the comments button
          const commentsButtonSelector = `button[aria-label*="comments"][type="button"]`;
          await this.page.waitForSelector(commentsButtonSelector, { timeout: 5000 });
          await this.page.click(commentsButtonSelector);
          await this.page.waitForSelector('span[dir="ltr"]', { timeout: 70000 });
        } catch (e) {
          console.log(`Comments not visible for post: ${user.groupUrl}. Skipping.`);
          continue;
        }

        // Extract the comments
        const comments = await this.page.$$eval('span[dir="ltr"]', (commentNodes) => {
          return commentNodes.map(commentNode => {
            const commentText = commentNode.querySelector('span[dir="ltr"]')?.innerText.trim() || 'No text';
            return { commentText };
          });
        });

        userComments.push({
          ...user,
          comments
        });

        console.log(`Extracted ${comments.length} comments from video: ${user.groupUrl}`);
      }
    }

    console.log("Comments extraction complete.");
    return { userComments }

  }

  async searchLinkedInPostUsers(query) {
    // Navigate to LinkedIn post search page
    await this.page.goto('https://www.linkedin.com/search/results/content/');

    // Enter the search query
    await this.page.fill('input[placeholder="Search"]', query);
    await this.page.press('input[placeholder="Search"]', 'Enter');

    // Wait for search results to load
    await this.page.waitForSelector('ul[role="list"]');

    // Extract post user details from the search results
    const posts = await this.page.$$eval('ul[role="list"] li', (items) => {
      const extractUsernameFromLinkedInUrl = (url) => {
        let username = '';

        if (url.includes('/in/')) {
          // Extract username for user profile URLs
          const parts = url.split('/in/');
          if (parts.length > 1) {
            username = parts[1].split('/')[0]; // Get the part after '/in/' before the next '/'
          }
        } else if (url.includes('/company/')) {
          // Extract company name for company profile URLs
          const parts = url.split('/company/');
          if (parts.length > 1) {
            username = parts[1].split('/')[0]; // Get the part after '/company/' before the next '/'
          }
        }

        return username;
      };

      return items.map(item => {
        const displayName = item.querySelector('span[dir="ltr"]')?.textContent.trim() || '';
        const userProfileUrl = item.querySelector('a')?.href || '';
        const photoUrl = item.querySelector('img')?.src || ''; // Fetching photo URL

        const userName = extractUsernameFromLinkedInUrl(userProfileUrl); // Extracted username from URL
        // Extract post URLs from the feed
        const postUrls = item.querySelector('a[data-control-id] ')?.href || '';
        const title = item.querySelector('.update-components-update-v2__commentary span.break-words span[dir="ltr"]')?.innerText || '';
        return {
          displayName,
          userName,
          userProfileUrl,
          photoUrl,
          postUrls,
          title,
          description:title
        };
      });
    });

     // Extract comments for each video
     const userComments = [];
     for (const user of posts) {
       if (user.postUrls) {
         console.log(`Navigating to video page: ${user.postUrls}`);
         await this.page.goto(user.postUrls);
 
         // Wait for comments to load (handling potential delays)
         try {
            // Click on the comments button
            const commentsButtonSelector = `button[aria-label*="comments"][type="button"]`;
            await this.page.waitForSelector(commentsButtonSelector, { timeout: 60000 });
            await this.page.click(commentsButtonSelector);
            await this.page.waitForSelector(commentsButtonSelector, { timeout: 60000 });
            await this.page.click(commentsButtonSelector);
           await this.page.waitForSelector('span[dir="ltr"]', { timeout: 70000 });
         } catch (e) {
           console.log(`Comments not visible for post: ${user.postUrls}. Skipping.`);
           continue;
         }
 
         // Extract the comments
         const comments = await this.page.$$eval('span[dir="ltr"]', (commentNodes) => {
           return commentNodes.map(commentNode => {
             const commentText = commentNode.querySelector('span[dir="ltr"]')?.innerText.trim() || 'No text';
             return { commentText };
           });
         });
 
         userComments.push({
           ...user,
           comments
         });
 
         console.log(`Extracted ${comments.length} comments from video: ${user.postUrls}`);
       }
     }
 
     console.log("Comments extraction complete.");
     return { userComments }
  }


  // Perform LinkedIn hashtag search
  async searchLinkedInHashtags(hashtag) {
    if (!this.page) {
      throw new Error('Browser not initialized. Call init() first.');
    }

    // Navigate to LinkedIn search results
    await this.page.goto('https://www.linkedin.com/search/results/content/');

    // Fill the search bar with the hashtag
    await this.page.fill('input[placeholder="Search"]', `#${hashtag}`);
    await this.page.press('input[placeholder="Search"]', 'Enter');

    // Wait for search results to load
    await this.page.waitForSelector('ul[role="list"]');

    // Extract posts
    const posts = await this.page.$$eval('ul[role="list"] li', (items) => {
      return items.map(item => {
        const postUrl = item.querySelector('a')?.href || '';

        // Extract author details
        const authorElement = item.querySelector('a[href*="/in/"]');
        const displayName = authorElement?.querySelector('span')?.textContent.trim() || '';
        const profileUrl = authorElement?.href || '';
        const photoUrl = item.querySelector('img')?.src || '';
        const title = item.querySelector('.update-components-update-v2__commentary span.break-words span[dir="ltr"]')?.innerText || '';

        // Extract username
        let username = '';
        if (profileUrl) {
          const parts = profileUrl.split('/in/');
          if (parts.length > 1) {
            username = parts[1].split('/')[0];
          }
        }

        return {
          postUrl,
          displayName,
          username,
          profileUrl,
          photoUrl,
          title,
          description: title,
        };
      });
    });


    // Extract comments for each video
    const userComments = [];
    for (const user of posts) {
      if (user.postUrl) {
        console.log(`Navigating to video page: ${user.postUrl}`);
        await this.page.goto(user.postUrl);

        // Wait for comments to load (handling potential delays)
        try {
          // Click on the comments button
          const commentsButtonSelector = `button[aria-label*="comments"][type="button"]`;
          await this.page.waitForSelector(commentsButtonSelector, { timeout: 60000 });
          await this.page.click(commentsButtonSelector);
          await this.page.waitForSelector(commentsButtonSelector, { timeout: 60000 });
          await this.page.click(commentsButtonSelector);
          await this.page.waitForSelector('span[dir="ltr"]', { timeout: 70000 });
        } catch (e) {
          console.log(`Comments not visible for post: ${user.postUrl}. Skipping.`);
          continue;
        }

        // Extract the comments
        const comments = await this.page.$$eval('span[dir="ltr"]', (commentNodes) => {
          return commentNodes.map(commentNode => {
            const commentText = commentNode.querySelector('span[dir="ltr"]')?.innerText.trim() || 'No text';
            return { commentText };
          });
        });

        userComments.push({
          ...user,
          comments
        });

        console.log(`Extracted ${comments.length} comments from video: ${user.postUrl}`);
      }
    }

    console.log("Comments extraction complete.");
    return { userComments }
  }



  async searchLinkedInGroupUsers(groupUrl) {
    if (!this.page) {
      throw new Error('Browser not initialized. Call init() first.');
    }

    // Navigate to the specified LinkedIn group page
    await this.page.goto(groupUrl);

    // Wait for the group members section to be visible
    await this.page.waitForSelector('div.scaffold-finite-scroll__content');

    // Extract user details from the group page
    const users = await this.page.$$eval('ul[aria-label="Members"] li', (items) => {
      return items.map(item => {
        const displayName = item.querySelector('div.artdeco-entity-lockup__title')?.textContent.trim() || '';
        const userProfileUrl = item.querySelector('a')?.href || '';
        const photoUrl = item.querySelector('img')?.src || ''; // Fetching photo URL

        let userName = '';
        if (userProfileUrl) {
          const parts = userProfileUrl.split('/in/');
          if (parts.length > 1) {
            userName = parts[1].split('/')[0]; // Extract the username part
          }
        }

        return {
          displayName,
          userName,
          userProfileUrl,
          photoUrl
        };
      });
    });

    return users;
  }

  async searchLinkedInLiveUsers(query) {
    if (!this.page) {
      throw new Error('Browser not initialized. Call init() first.');
    }

    // Navigate to LinkedIn search page
    await this.page.goto('https://www.linkedin.com/search/results/all/');

    // Fill the search bar with the query
    await this.page.fill('input[placeholder="Search"]', query);
    await this.page.press('input[placeholder="Search"]', 'Enter');

    // Wait for search results to load
    await this.page.waitForSelector('ul[role="list"]');

    // Extract user details from the search results
    const users = await this.page.$$eval('ul[role="list"] li', (items) => {
      return items.map(item => {
        const userName = item.querySelector('span.entity-result__title-text')?.textContent.trim() || '';
        const userProfileUrl = item.querySelector('a')?.href || '';
        const userPhotoUrl = item.querySelector('img')?.src || ''; // This might not always be available
        const title = item.querySelector('feed-shared-update-v2__description ')?.innerText || '';


        return {
          userName,
          userProfileUrl,
          userPhotoUrl,
          title
        };
      });
    });

    console.log('Live users found:', users);
    return users;
  }

  //generate topic and post specific jokes
  async generateTopicJokes(topic) {
    try {
      if (this.cache[topic]) {
        console.log('Returning cached jokes for topic:', topic);
        return this.cache[topic].topicJokes;
      }

      const topicPrompt = `Tell me 50 jokes related to "${topic}", each less than 20 words.`;
      const topicResponse = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [
          { role: "system", content: "You are a helpful assistant." },
          { role: "user", content: topicPrompt },
        ],
      });

      const topicJokes = topicResponse.choices[0].message.content.split("\n").filter(joke => joke.trim());
      this.cache[topic] = this.cache[topic] || {};
      this.cache[topic].topicJokes = topicJokes;
      this.saveCache();

      return topicJokes;
    } catch (error) {
      console.error("Error generating topic jokes:", error);
      return [];
    }
  }

  //generate post specific jokes for groups 
  async generatePostJokesGroups(query) {
    try {
      // Fetch posts based on hashtag
      const { userComments } = await this.searchLinkedInGroup(query);

      if (!Array.isArray(userComments)) {
        throw new Error("Expected an array of posts but got something else.");
      }

      const postJokes = [];
      const limitedPosts = userComments.slice(0, 20); // Limit to the first 20 posts

      for (const post of limitedPosts) {
        const postContent = `
          Title: ${post.title} 
          Description: ${post.description}
          Comments: ${post.comments.map(comment => comment.commentText).join(" ")}
        `;
        const postPrompt = `Generate 25 jokes related to the following post content: "${postContent}"`;

        try {
          const postResponse = await openai.chat.completions.create({
            model: "gpt-3.5-turbo",
            messages: [
              { role: "system", content: "You are a humorous assistant." },
              { role: "user", content: postPrompt },
            ],
          });

          const postSpecificJokes = postResponse.choices[0].message.content
            .split("\n")
            .filter(joke => joke.trim());
          postJokes.push({ jokes: postSpecificJokes });
        } catch (error) {
          console.error(`Error generating jokes for post: ${post.title}`);
          postJokes.push({ jokes: [] });
        }
      }

      // Save jokes to a JSON file
      // this.SavePostsJokeFile(hashtag, postJokes);

      return postJokes;
    } catch (error) {
      console.error("Error generating post jokes:", error);
      return [];
    }
  }

  //generate post specific jokes for different posts 
  async generatePostJokesPosting(query) {
    try {
      // Fetch posts based on hashtag
      const { userComments } = await this.searchLinkedInPostUsers(query);

      if (!Array.isArray(userComments)) {
        throw new Error("Expected an array of posts but got something else.");
      }

      const postJokes = [];
      const limitedPosts = userComments.slice(0, 20); // Limit to the first 20 posts

      for (const post of limitedPosts) {
        const postContent = `
          Title: ${post.title} 
          Description: ${post.description}
          Comments: ${post.comments.map(comment => comment.commentText).join(" ")}
        `;
        const postPrompt = `Generate 25 jokes related to the following post content: "${postContent}"`;

        try {
          const postResponse = await openai.chat.completions.create({
            model: "gpt-3.5-turbo",
            messages: [
              { role: "system", content: "You are a humorous assistant." },
              { role: "user", content: postPrompt },
            ],
          });

          const postSpecificJokes = postResponse.choices[0].message.content
            .split("\n")
            .filter(joke => joke.trim());
          postJokes.push({ jokes: postSpecificJokes });
        } catch (error) {
          console.error(`Error generating jokes for post: ${post.title}`);
          postJokes.push({ jokes: [] });
        }
      }

      // Save jokes to a JSON file
      // this.SavePostsJokeFile(hashtag, postJokes);

      return postJokes;
    } catch (error) {
      console.error("Error generating post jokes:", error);
      return [];
    }
  }

  //generate post specific jokes for live  
  async generatePostJokesLive(query) {
    try {
      // Fetch posts based on hashtag
      const { userComments } = await this.searchLinkedInHashtags(query);

      if (!Array.isArray(userComments)) {
        throw new Error("Expected an array of posts but got something else.");
      }

      const postJokes = [];
      const limitedPosts = userComments.slice(0, 20); // Limit to the first 20 posts

      for (const post of limitedPosts) {
        const postContent = `
            Title: ${post.title} 
            Description: ${post.description}
            Comments: ${post.comments.map(comment => comment.commentText).join(" ")}
          `;
        const postPrompt = `Generate 25 jokes related to the following post content: "${postContent}"`;

        try {
          const postResponse = await openai.chat.completions.create({
            model: "gpt-3.5-turbo",
            messages: [
              { role: "system", content: "You are a humorous assistant." },
              { role: "user", content: postPrompt },
            ],
          });

          const postSpecificJokes = postResponse.choices[0].message.content
            .split("\n")
            .filter(joke => joke.trim());
          postJokes.push({ jokes: postSpecificJokes });
        } catch (error) {
          console.error(`Error generating jokes for post: ${post.title}`);
          postJokes.push({ jokes: [] });
        }
      }

      // Save jokes to a JSON file
      // this.SavePostsJokeFile(hashtag, postJokes);

      return postJokes;
    } catch (error) {
      console.error("Error generating post jokes:", error);
      return [];
    }
  }

  //shuffle the array of jokes
  shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]]; // Swap elements
    }
    return array;
  }

  //save topic based and post specific jokes 
  async JokesFile(topic, shuffledTopicJokes) {
    try {
      const jokesFilePath = path.join(__dirname, `${slugify(topic)}_topic_jokes.json`);
      const jokesData = {
        topicJokes: shuffledTopicJokes,
      };

      fs.writeFileSync(jokesFilePath, JSON.stringify(jokesData, null, 2));
      console.log(`Topic jokes saved to ${jokesFilePath}`);
    } catch (error) {
      console.error("Error saving topic jokes to file:", error);
    }
  }

  async SaveJokeFile(topic) {
    try {
      const topicJokes = await this.generateTopicJokes(topic);
      if (!topicJokes || topicJokes.length === 0) {
        console.log("No topic jokes generated.");
        return;
      }

      // Save the generated jokes to cache
      this.cache[topic] = { topicJokes };
      this.saveCache();

      const shuffledTopicJokes = this.shuffleArray(topicJokes); // Shuffle the topic jokes
      await this.JokesFile(topic, shuffledTopicJokes);
    } catch (error) {
      console.error("Error in SaveJokeFile:", error.message);
    }
  }

  //save post based jokes
  async SavePostsJokeFile(hashtag, shuffledPostJokes) {
    try {
      const jokesFilePath = path.join(__dirname, `${hashtag}_posts_jokes.json`);
      fs.writeFileSync(jokesFilePath, JSON.stringify(shuffledPostJokes, null, 2));
      console.log(`Jokes for hashtag "${hashtag}" saved to ${jokesFilePath}`);
    } catch (error) {
      console.error("Error saving jokes to file:", error);
    }
  }


  //post Comments 

  async postCommentonGroups(groupUrl, joke, username) {
    try {
      await this.page.goto(groupUrl, { timeout: 60000 });

      // Wait for the comment input area to load
      await this.page.waitForSelector('button[aria-label="Comment"]');
      await this.page.click('button[aria-label="Comment"]');
      // Wait for the comment form to be visible
      await this.page.waitForSelector('.comments-comment-box__form');

      // Click on the comment editor to activate it
      await this.page.click('.ql-editor[contenteditable="true"]');

      await this.page.fill('.ql-editor[contenteditable="true"]', `${joke} @${username} #beladed`, { delay: 100 });

      // Wait for the comment button to be available
      await this.page.waitForSelector('.comments-comment-box__submit-button--cr');

      // Click the "Comment" button to submit
      await this.page.click('.comments-comment-box__submit-button--cr');

      console.log('Comment submitted successfully!');



      console.log(`Comment posted successfully on ${groupUrl}: "${joke}"`);
    } catch (error) {
      console.error(`Failed to post comment on ${groupUrl}:`, error.message);
    }
  }

  async postCommentonPosts(postUrls, joke, username) {
    try {
      await this.page.goto(postUrls, { timeout: 60000 });

      // Wait for the comment input area to load
      await this.page.waitForSelector('button[aria-label="Comment"]');
      await this.page.click('button[aria-label="Comment"]');
      // Wait for the comment form to be visible
      await this.page.waitForSelector('.comments-comment-box__form');

      // Click on the comment editor to activate it
      await this.page.click('.ql-editor[contenteditable="true"]');

      await this.page.fill('.ql-editor[contenteditable="true"]', `${joke} @${username} #beladed`, { delay: 100 });

      // Wait for the comment button to be available
      await this.page.waitForSelector('.comments-comment-box__submit-button--cr');

      // Click the "Comment" button to submit
      await this.page.click('.comments-comment-box__submit-button--cr');

      console.log('Comment submitted successfully!');



      console.log(`Comment posted successfully on ${postUrls}: "${joke}"`);
    } catch (error) {
      console.error(`Failed to post comment on ${postUrls}:`, error.message);
    }
  }

  async postCommentonLive(postUrl, joke, username) {
    try {
      await this.page.goto(postUrl, { timeout: 60000 });

      // Wait for the comment input area to load
      await this.page.waitForSelector('button[aria-label="Comment"]');
      await this.page.click('button[aria-label="Comment"]');
      // Wait for the comment form to be visible
      await this.page.waitForSelector('.comments-comment-box__form');

      // Click on the comment editor to activate it
      await this.page.click('.ql-editor[contenteditable="true"]');

      await this.page.fill('.ql-editor[contenteditable="true"]', `${joke} @${username} #beladed`, { delay: 100 });

      // Wait for the comment button to be available
      await this.page.waitForSelector('.comments-comment-box__submit-button--cr');

      // Click the "Comment" button to submit
      await this.page.click('.comments-comment-box__submit-button--cr');

      console.log('Comment submitted successfully!');



      console.log(`Comment posted successfully on ${postUrl}: "${joke}"`);
    } catch (error) {
      console.error(`Failed to post comment on ${postUrl}:`, error.message);
    }
  }




  async automateCommentingonGroup(query) {
    try {
      // Step 1: Search for posts using the provided hashtag
      const { userComments } = await this.searchLinkedInGroup(query);

      if (userComments.length === 0) {
        console.log('No posts found with the provided hashtag.');
        return;
      }

      // Step 2: Generate jokes for the posts
      const postJokes = await this.generatePostJokesGroups(hashtag);
      if (postJokes.length === 0) {
        console.log('No jokes generated for the posts.');
        return;
      }

      // Step 3: Shuffle the jokes for randomness
      const shuffledPostJokes = this.shuffleArray(postJokes);

      // Step 4: Iterate over posts to post comments
      for (let i = 0; i < userComments.length; i++) {
        const post = userComments[i];

        // Ensure videoUrl exists
        if (!post.groupUrl) {
          console.error(`Error: videoUrl is undefined or invalid for post: ${post.title}`);
          continue;  // Skip this post
        }

        // Step 4: Select one joke from the shuffled list
        const joke = shuffledPostJokes[i]?.jokes[0] || "Here's a funny joke!"; // Choose the first joke after shuffling

        // Post the comment to the video
        await this.postCommentonGroups(post.groupUrl, joke, post.username);

        console.log(`Comment posted: "${joke}" on ${post.groupUrl}`);
      }

      console.log("Automated commenting completed for all search results.");
    } catch (error) {
      console.error("Error during automated commenting:", error.message);
    }
  }


  async automateCommentingonPost(query) {
    try {
      // Step 1: Search for posts using the provided hashtag
      const { userComments } = await this.searchLinkedInPostUsers(query);

      if (userComments.length === 0) {
        console.log('No posts found with the provided hashtag.');
        return;
      }

      // Step 2: Generate jokes for the posts
      const postJokes = await this.generatePostJokesPosting(hashtag);
      if (postJokes.length === 0) {
        console.log('No jokes generated for the posts.');
        return;
      }

      // Step 3: Shuffle the jokes for randomness
      const shuffledPostJokes = this.shuffleArray(postJokes);

      // Step 4: Iterate over posts to post comments
      for (let i = 0; i < userComments.length; i++) {
        const post = userComments[i];

        // Ensure videoUrl exists
        if (!post.postUrls) {
          console.error(`Error: videoUrl is undefined or invalid for post: ${post.title}`);
          continue;  // Skip this post
        }

        // Step 4: Select one joke from the shuffled list
        const joke = shuffledPostJokes[i]?.jokes[0] || "Here's a funny joke!"; // Choose the first joke after shuffling

        // Post the comment to the video
        await this.postCommentonPosts(post.postUrls, joke, post.username);

        console.log(`Comment posted: "${joke}" on ${post.postUrls}`);
      }

      console.log("Automated commenting completed for all search results.");
    } catch (error) {
      console.error("Error during automated commenting:", error.message);
    }
  }


  async automateCommentingonLive(hashtag) {
    try {
      // Step 1: Search for posts using the provided hashtag
      const { userComments } = await this.searchLinkedInHashtags(query);

      if (userComments.length === 0) {
        console.log('No posts found with the provided hashtag.');
        return;
      }

      // Step 2: Generate jokes for the posts
      const postJokes = await this.generatePostJokesPosting(hashtag);
      if (postJokes.length === 0) {
        console.log('No jokes generated for the posts.');
        return;
      }

      // Step 3: Shuffle the jokes for randomness
      const shuffledPostJokes = this.shuffleArray(postJokes);

      // Step 4: Iterate over posts to post comments
      for (let i = 0; i < userComments.length; i++) {
        const post = userComments[i];

        // Ensure videoUrl exists
        if (!post.postUrl) {
          console.error(`Error: videoUrl is undefined or invalid for post: ${post.title}`);
          continue;  // Skip this post
        }

        // Step 4: Select one joke from the shuffled list
        const joke = shuffledPostJokes[i]?.jokes[0] || "Here's a funny joke!"; // Choose the first joke after shuffling

        // Post the comment to the video
        await this.postCommentonLive(post.postUrl, joke, post.username);

        console.log(`Comment posted: "${joke}" on ${post.postUrl}`);
      }

      console.log("Automated commenting completed for all search results.");
    } catch (error) {
      console.error("Error during automated commenting:", error.message);
    }
  }


  async close() {
    try {
      if (this.browser) {
        await this.browser.close();
        console.log("Browser closed successfully");
      } else {
        throw new Error("Browser not initialized. Call init() first.");
      }
    } catch (error) {
      console.error("Error closing browser:", error);
    }
  }
}

module.exports = Linkedindirect;

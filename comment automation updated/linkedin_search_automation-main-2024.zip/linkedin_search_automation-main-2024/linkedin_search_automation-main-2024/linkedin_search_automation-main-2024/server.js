const express = require("express");
const bodyParser = require("body-parser");
const Linkedindirect = require("./Linkedindirect");

const app = express();
const port = 3000;

app.use(bodyParser.json());
require('dotenv').config();
app.use(express.urlencoded({ extended: true })); // For parsing URL-encoded data

let linkedinAutomation;

// Endpoint to initialize LinkedIn automation
app.post("/api/automation/Linkedindirect/init", async (req, res) => {
  const { browserType } = req.body;
  try {
    linkedinAutomation = new Linkedindirect(browserType || 'chromium');
    await linkedinAutomation.init();
    res.send({ message: "Linkedindirect automation initialized" });
  } catch (err) {
    res.status(500).json({ error: "Error initiating Linkedindirect", details: err.message });
  }
});

// Endpoint to log in to LinkedIn
app.post("/api/automation/Linkedindirect/login", async (req, res) => {
  const { email, password } = req.body;
  try {
    if (!linkedinAutomation) {
      return res.status(400).json({ error: "Linkedindirect automation is not initialized. Please call the init endpoint first." });
    }
    await linkedinAutomation.login(email, password);
    res.send({ message: "Logged in to Linkedindirect" });
  } catch (err) {
    res.status(500).json({ error: "Error logging in to Linkedindirect", details: err.message });
  }
});

// Endpoint to log out from LinkedIn
app.post("/api/automation/Linkedindirect/logout", async (req, res) => {
  try {
    if (!linkedinAutomation) {
      return res.status(400).json({ error: "Linkedindirect automation is not initialized. Please call the init endpoint first." });
    }
    await linkedinAutomation.logout();
    res.send({ message: "Logged out of Linkedindirect" });
  } catch (err) {
    res.status(500).json({ error: "Error logging out of Linkedindirect", details: err.message });
  }
});

// Endpoint to search LinkedIn groups
app.post('/api/automation/Linkedindirect/searchGroups', async (req, res) => {
  const { query } = req.body;
  try {
    if (!query) {
      return res.status(400).send('Search query is required.');
    }
    if (!linkedinAutomation) {
      return res.status(400).json({ error: "Linkedindirect automation is not initialized. Please call the init endpoint first." });
    }
    const groups = await linkedinAutomation.searchLinkedInGroup(query);
    res.json(groups);
  } catch (error) {
    console.error('Search failed:', error);
    res.status(500).send('Search failed.');
  }
});

// Endpoint to post in a LinkedIn group
app.post("/api/automation/Linkedindirect/postInGroup", async (req, res) => {
  const { groupId, postContent } = req.body;
  try {
    if (!linkedinAutomation) {
      return res.status(400).json({ error: "Linkedindirect automation is not initialized. Please call the init endpoint first." });
    }
    await linkedinAutomation.postInGroup(groupId, postContent);
    res.send({ message: "Post successfully made in LinkedIn group" });
  } catch (err) {
    res.status(500).json({ error: "Error posting in LinkedIn group", details: err.message });
  }
});

// Endpoint to search for LinkedIn Live users
app.post('/api/automation/Linkedindirect/searchLiveUsers', async (req, res) => {
  const { query } = req.body;
  try {
    if (!query) {
      return res.status(400).json({ error: 'Query is required' });
    }
    if (!linkedinAutomation) {
      return res.status(400).json({ error: "Linkedindirect automation is not initialized. Please call the init endpoint first." });
    }
    const users = await linkedinAutomation.searchLinkedInLiveUsers(query);
    return res.json({ users });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Failed to search for LinkedIn Live users' });
  }
});

// Endpoint to search for LinkedIn post users
app.post('/api/automation/Linkedindirect/searchPostUsers', async (req, res) => {
  const { query } = req.body;
  try {
    if (!query) {
      return res.status(400).json({ error: 'Query is required' });
    }
    if (!linkedinAutomation) {
      return res.status(400).json({ error: "Linkedindirect automation is not initialized. Please call the init endpoint first." });
    }
    const users = await linkedinAutomation.searchLinkedInPostUsers(query);
    return res.json({ users });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Failed to search for LinkedIn Post users' });
  }
});


// Endpoint to search for LinkedIn group users
app.post('/api/automation/Linkedindirect/searchGroupUsers', async (req, res) => {
  const { groupUrl } = req.body;
  try {
    if (!groupUrl) {
      return res.status(400).json({ error: 'groupUrl is required' });
    }
    if (!linkedinAutomation) {
      return res.status(400).json({ error: "Linkedindirect automation is not initialized. Please call the init endpoint first." });
    }
    const users = await linkedinAutomation.searchLinkedInGroupUsers(groupUrl);
    return res.json({ users });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Failed to search for LinkedIn Group users' });
  }
});


//Endpoint to search for LinkedIn hashtag users
app.post('/api/automation/Linkedindirect/searchHashtag', async (req, res) => {
  const { hashtag } = req.body;
  try {
    if (!hashtag) {
      return res.status(400).json({ error: 'hashtag is required' });
    }
    if (!linkedinAutomation) {
      return res.status(400).json({ error: "Linkedindirect automation is not initialized. Please call the init endpoint first." });
    }
    const users = await linkedinAutomation.searchLinkedInHashtags(hashtag);
    return res.json({ users });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Failed to search for LinkedIn hashtag users' });
  }
});


/**
 * Endpoint to generate jokes based on a topic.
 */
app.post("/api/automation/Linkedindirect/generate-jokes-groups", async (req, res) => {
  const { topic } = req.body;

  if (!topic) {
    return res.status(400).json({ message: "Topic is required" });
  }

  try {
    const jokes = await linkedinAutomation.generateTopicJokes(topic);
    res.status(200).json({ jokes });
  } catch (error) {
    console.error("Joke generation failed:", error);
    res.status(500).json({ message: "Joke generation failed.", error: error.message });
  }
});

/**
 * Endpoint to generate jokes based on a topic.
 */
app.post("/api/automation/Linkedindirect/generate-jokes-live", async (req, res) => {
  const { topic } = req.body;

  if (!topic) {
    return res.status(400).json({ message: "Topic is required" });
  }

  try {
    const jokes = await linkedinAutomation.generateTopicJokes(topic);
    res.status(200).json({ jokes });
  } catch (error) {
    console.error("Joke generation failed:", error);
    res.status(500).json({ message: "Joke generation failed.", error: error.message });
  }
});

/**
 * Endpoint to generate jokes based on a topic.
 */
app.post("/api/automation/Linkedindirect/generate-jokes-posts", async (req, res) => {
  const { topic } = req.body;

  if (!topic) {
    return res.status(400).json({ message: "Topic is required" });
  }

  try {
    const jokes = await linkedinAutomation.generateTopicJokes(topic);
    res.status(200).json({ jokes });
  } catch (error) {
    console.error("Joke generation failed:", error);
    res.status(500).json({ message: "Joke generation failed.", error: error.message });
  }
});


/**
 * Endpoint to generate jokes based on a posts on groups.
 */
app.post("/api/automation/Linkedindirect/generate-jokes-groups-postbased", async (req, res) => {
  const { query } = req.body;

  if (!query) {
    return res.status(400).json({ message: "Topic is required" });
  }

  try {
    const jokes = await linkedinAutomation.generatePostJokesGroups(query);
    res.status(200).json({ jokes });
  } catch (error) {
    console.error("Joke generation failed:", error);
    res.status(500).json({ message: "Joke generation failed.", error: error.message });
  }
});

/**
 * Endpoint to generate jokes based on a posts on live.
 */
app.post("/api/automation/Linkedindirect/generate-jokes-live-postbased", async (req, res) => {
  const { query } = req.body;

  if (!query) {
    return res.status(400).json({ message: "Topic is required" });
  }

  try {
    const jokes = await linkedinAutomation.generatePostJokesLive(query);
    res.status(200).json({ jokes });
  } catch (error) {
    console.error("Joke generation failed:", error);
    res.status(500).json({ message: "Joke generation failed.", error: error.message });
  }
});

/**
 * Endpoint to generate jokes based on a topic.
 */
app.post("/api/automation/Linkedindirect/generate-jokes-posts", async (req, res) => {
  const { query } = req.body;

  if (!query) {
    return res.status(400).json({ message: "Topic is required" });
  }

  try {
    const jokes = await linkedinAutomation.generatePostJokesPosting(query);
    res.status(200).json({ jokes });
  } catch (error) {
    console.error("Joke generation failed:", error);
    res.status(500).json({ message: "Joke generation failed.", error: error.message });
  }
});



/**
 * Endpoint to save jokes to a file.
 */
app.post("/api/automation/Linkedindirect/save-jokes-groups",  async (req, res) => {
  const {  topic } = req.body;
  if (!linkedinAutomation) {
    return res.status(400).json({ message: "Please log in first" });
  }


  try {
    await linkedinAutomation.SaveJokeFile(topic);
    res.status(200).json({ message: `Jokes saved for "${topic}".` });
  } catch (error) {
    console.error("Saving jokes failed:", error);
    res.status(500).json({ message: "Failed to save jokes.", error: error.message });
  }
});


/**
 * Endpoint to save jokes to a file.
 */
app.post("/api/automation/Linkedindirect/save-jokes-live",  async (req, res) => {
  const {  topic } = req.body;
  if (!linkedinAutomation) {
    return res.status(400).json({ message: "Please log in first" });
  }


  try {
    await linkedinAutomation.SaveJokeFile(topic);
    res.status(200).json({ message: `Jokes saved for "${topic}".` });
  } catch (error) {
    console.error("Saving jokes failed:", error);
    res.status(500).json({ message: "Failed to save jokes.", error: error.message });
  }
});


/**
 * Endpoint to save jokes to a file.
 */
app.post("/api/automation/Linkedindirect/save-jokes-posts",  async (req, res) => {
  const {  topic } = req.body;
  if (!linkedinAutomation) {
    return res.status(400).json({ message: "Please log in first" });
  }


  try {
    await linkedinAutomation.SaveJokeFile(topic);
    res.status(200).json({ message: `Jokes saved for "${topic}".` });
  } catch (error) {
    console.error("Saving jokes failed:", error);
    res.status(500).json({ message: "Failed to save jokes.", error: error.message });
  }
});


/**
 * Endpoint to save jokes to a file.
 */
app.post("/api/automation/Linkedindirect/save-jokes-groups-postbased",  async (req, res) => {
  const {  posts } = req.body;
  if (!linkedinAutomation) {
    return res.status(400).json({ message: "Please log in first" });
  }


  try {
    await linkedinAutomation.SavePostsJokeFile(posts);
    res.status(200).json({ message: `Jokes saved for "${posts}".` });
  } catch (error) {
    console.error("Saving jokes failed:", error);
    res.status(500).json({ message: "Failed to save jokes.", error: error.message });
  }
});


/**
 * Endpoint to save jokes to a file.
 */
app.post("/api/automation/Linkedindirect/save-jokes-live-postbased",  async (req, res) => {
  const {  posts } = req.body;
  if (!linkedinAutomation) {
    return res.status(400).json({ message: "Please log in first" });
  }


  try {
    await linkedinAutomation.SavePostsJokeFile(posts);
    res.status(200).json({ message: `Jokes saved for "${posts}".` });
  } catch (error) {
    console.error("Saving jokes failed:", error);
    res.status(500).json({ message: "Failed to save jokes.", error: error.message });
  }
});


/**
 * Endpoint to save jokes to a file.
 */
app.post("/api/automation/Linkedindirect/save-jokes-posts-postbased",  async (req, res) => {
  const {  posts } = req.body;
  if (!linkedinAutomation) {
    return res.status(400).json({ message: "Please log in first" });
  }


  try {
    await linkedinAutomation.SavePostsJokeFile(posts);
    res.status(200).json({ message: `Jokes saved for "${posts}".` });
  } catch (error) {
    console.error("Saving jokes failed:", error);
    res.status(500).json({ message: "Failed to save jokes.", error: error.message });
  }
});


app.post("/api/automation/Linkedindirect/automate-commenting-live", async (req, res) => {
  const { hashtag } = req.body;
  if (!linkedinAutomation) {
    return res.status(400).json({ message: "Please log in first" });
  }


  if (!hashtag) {
    return res.status(400).json({ message: "query is required" });
  }


  try {
    await linkedinAutomation.automateCommentingonLive(hashtag);
    res.status(200).json({ message: "Commenting automation completed successfully for live" });
  } catch (error) {
    console.error("Commenting automation failed:", error);
    res.status(500).json({ message: "Commenting automation failed.", error: error.message });
  }
});

/**
 * Endpoint to automate commenting on posts based on hashtag.
 */
app.post("/api/automation/Linkedindirect/automate-commenting-group", async (req, res) => {
  const { query } = req.body;
  if (!linkedinAutomation) {
    return res.status(400).json({ message: "Please log in first" });
  }


  if (!query) {
    return res.status(400).json({ message: "query is required" });
  }


  try {
    await linkedinAutomation.automateCommentingonGroup(query);
    res.status(200).json({ message: "Commenting automation completed successfully for groups" });
  } catch (error) {
    console.error("Commenting automation failed:", error);
    res.status(500).json({ message: "Commenting automation failed.", error: error.message });
  }
});

app.post("/api/automation/Linkedindirect/automate-commenting-posts", async (req, res) => {
  const { query } = req.body;
  if (!linkedinAutomation) {
    return res.status(400).json({ message: "Please log in first" });
  }


  if (!query) {
    return res.status(400).json({ message: "query is required" });
  }


  try {
    await linkedinAutomation.automateCommentingonPost(query);
    res.status(200).json({ message: "Commenting automation completed successfully for posts" });
  } catch (error) {
    console.error("Commenting automation failed:", error);
    res.status(500).json({ message: "Commenting automation failed.", error: error.message });
  }
});




// Start server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});

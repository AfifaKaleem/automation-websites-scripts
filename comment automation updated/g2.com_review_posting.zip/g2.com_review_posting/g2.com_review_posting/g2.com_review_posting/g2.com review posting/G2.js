const puppeteer = require('puppeteer');
const fs = require('fs');
const path = require('path');
const { OpenAI } = require('openai');
const slugify = require('slugify');
require('dotenv').config();

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

class G2 {
  constructor(browserType = 'chrome') {
    this.browserType = browserType;
    this.browser = null;
    this.page = null;
    this.cache={};
  }
 // Helper functions to manage caching
 loadCache() {
  const cacheFile = path.join(__dirname, 'jokes_cache.json');
  if (fs.existsSync(cacheFile)) {
      try {
          const data = fs.readFileSync(cacheFile, 'utf8');
          this.cache = JSON.parse(data);
      } catch (error) {
          console.error('Error loading cache:', error);
      }
  }
}

saveCache() {
  const cacheFile = path.join(__dirname, 'jokes_cache.json');
  try {
      fs.writeFileSync(cacheFile, JSON.stringify(this.cache, null, 2));
  } catch (error) {
      console.error('Error saving cache:', error);
  }
}
  async init() {
    try {
      const launchOptions = { headless: false };

      if (this.browserType === 'firefox') {
        // Puppeteer for Firefox (requires puppeteer-firefox package or proper setup)
        this.browser = await puppeteer.launch({ ...launchOptions, product: 'firefox' });
      } else {
        this.browser = await puppeteer.launch(launchOptions);
      }

      this.page = await this.browser.newPage(); // Open a new page
      this.loadCache();
      console.log(`${this.browserType} browser launched successfully`);
    } catch (error) {
      console.error('Error launching browser:', error);
      throw error;
    }
  }

  async loginG2(email, password) {
    try {
      await this.page.goto('https://www.g2.com/identities/start_login?return_to=https%253A%252F%252Fwww.g2.com%252F&onboard=true', {
        waitUntil: 'networkidle2',
        timeout: 60000
      });
      await this.page.waitForSelector('input[type="email"]', { timeout: 60000 });

      // Login with username and password
      await this.page.type('input[type="email"]', email);
      await this.page.type('input[type="password"]', password);
      await this.page.click('input[type="submit"]');

      // Wait for navigation to the homepage
      await this.page.waitForNavigation({ timeout: 60000 });
      console.log("Logged in to G2 successfully");
    } catch (error) {
      console.error("Error logging in to G2:", error);
      throw error;
    }
  }

  async logoutG2() {
    try {
      await this.page.goto('https://www.g2.com/', {
        waitUntil: 'networkidle2',
        timeout: 60000
      });
      await this.page.click('a[href*="https://www.g2.com/logout"]');
      await this.page.waitForNavigation();
      console.log("Logged out of G2 successfully");
    } catch (error) {
      console.error("Error logging out of G2:", error);
      throw error;
    }
  }

  async postReviewG2(title, likes, dislikes, businessproblemstext, noofEmployees, industryname) {
    try {

      // Navigate to the G2 review page
      await this.page.goto('https://www.g2.com/wizard/new-review/products/whereby/take_survey?last_completed_step=2&product_id=whereby&role=engineering', {
        waitUntil: 'networkidle2',
        timeout: 60000
      });

      // Select rating
      await this.page.waitForSelector('button[aria-label="5 Neutral"]', { visible: true, timeout: 60000 });
      await this.page.click('button[aria-label="5 Neutral"]');

      // Fill out review form
      await this.page.waitForSelector('input[type="text"]', { visible: true, timeout: 60000 });
      await this.page.type('input[type="text"]', title);

      await this.page.waitForSelector('textarea[aria-describedby="question-8-chars"]', { visible: true, timeout: 60000 });
      await this.page.type('textarea[aria-describedby="question-8-chars"]', likes);

      await this.page.waitForSelector('textarea[aria-describedby="question-9-chars"]', { visible: true, timeout: 60000 });
      await this.page.type('textarea[aria-describedby="question-9-chars"]', dislikes);

      // Navigate through steps
      await this.page.click('button[title="User"]');
      await this.page.click('button[data-testid="nextButton"]', { waitUntil: 'networkidle2', });

      await this.page.click('button[aria-haspopup="listbox"]');
      // await this.page.waitForSelector('li[data-testid="search-result-Telemedicine"]', { visible: true, timeout: 60000 });
      // await this.page.click('li[data-testid="search-result-Telemedicine"]');
      await this.page.type('textarea[aria-describedby="question-300-chars"]', businessproblemstext); // Corrected selector
      await this.page.click('button[aria-label="Yes"]');
      await this.page.click('button[aria-label="3 "]');
      // await this.page.click('button[aria-label="5 "]');
      // await this.page.click('button[aria-label="6 "]');
      // await this.page.click('button[aria-label="7 Most "]');
      await this.page.click('button[data-testid="nextButton"]',{waitUntil:"networkidle2"});

      await this.page.type('input[aria-labelledby="downshift-3-label"]', noofEmployees,{waitUntil:"networkidle2"});
      await this.page.click('button[aria-label="No"]');
      await this.page.click('button[aria-label="No"]');
      await this.page.click('button[aria-label="4 "]');
      await this.page.click('button[title="Still Implementing"]');
      await this.page.click('button.single-select__circular-item-button.focus:input__item--outline--ring.single-select__item--selected.input__item--outline--offset');
      // await this.page.click('button[role="radio"]');
      await this.page.click('button.single-select__circular-item-button.focus:input__item--outline--ring.single-select__item--selected.input__item--outline--offset');
      await this.page.click('button[data-testid="nextButton"]',{waitUntil:"networkidle2"});

      await this.page.click('button[data-testid="ssip-selected"]Other');
      await this.page.type('input[placeholder="Type to filter search results"]', industryname);
      await this.page.click('button[aria-label="No"]');
      await this.page.click('button[aria-label="I decline"]');
      // await this.page.click('button[data-testid="nextButton"]');
      await this.page.click('button[data-testid="submitButton"]');

      console.log("Review Posted on G2 successfully");
    } catch (error) {
      console.error("Error posting review on G2:", error);
    }
  }

//
  async searchDiscussions(query) {
    try {
      await this.page.goto(`https://www.g2.com/products/${query}/reviews#reviews`, { waitUntil: 'domcontentloaded' });

      // Wait for search results to load
      await this.page.waitForSelector(`a[href="/products/${query}/reviews#reviews"]`, { timeout: 5000 });
      await this.page.click(`a[href="/products/${query}/reviews#reviews"]`);
      await this.page.waitForSelector('div.x-track-in-viewport-initialized');

      // Extract data from each discussion post
      const discussions = await this.page.evaluate(() => {
        const discussionElements = document.querySelectorAll('div.x-track-in-viewport-initialized ');
        const results = [];

        discussionElements.forEach((discussion) => {
          const title = discussion.querySelector('div[itemprop="name"]')?.textContent.trim();
          const description = discussion.querySelector('div[itemprop="reviewBody"]')?.textContent.trim();
          const username = discussion.querySelector('a.link')?.textContent.trim();
          const displayName = discussion.querySelector('a.link')?.textContent.trim();
          const profileUrl = discussion.querySelector('a.link')?.href;
          const anchorElement = document.querySelector('a.pjax');
          const postUrl = anchorElement?.getAttribute('href');

          results.push({
            title,
            description,
            username,
            displayName,
            profileUrl,
            postUrl,
          });
        });

        return results;
      });

      console.log(discussions);
      return discussions;
    } catch (err) {
      console.error('Error searching discussion posts', err);
      throw err;
    }
  }


a
  async generateTopicJokes(topic) {
    try {
      if (this.cache[topic]) {
        console.log('Returning cached jokes for topic:', topic);
        return this.cache[topic].topicJokes;
      }
  
      const topicPrompt = `Tell me 50 jokes related to "${topic}", each less than 20 words.`;
      const topicResponse = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [
          { role: "system", content: "You are a helpful assistant." },
          { role: "user", content: topicPrompt },
        ],
      });
  
      const topicJokes = topicResponse.choices[0].message.content.split("\n").filter(joke => joke.trim());
      this.cache[topic] = this.cache[topic] || {};
      this.cache[topic].topicJokes = topicJokes;
      this.saveCache();
  
      return topicJokes;
    } catch (error) {
      console.error("Error generating topic jokes:", error);
      return [];
    }
  }
  async generatePostJokes(category) {
    try {
      // Fetch posts based on category
      const userComments = await this.searchCategory(category);
  
      const postJokes = [];
  
      for (const comment of userComments) {
        const postContent = `
          Title: ${comment.title || "No title"} 
          Description: ${comment.description || "No description"}
        `;
  
        const postPrompt = `Generate 25 jokes related to the following post content: "${postContent}"`;
  
        try {
          const postResponse = await openai.chat.completions.create({
            model: "gpt-3.5-turbo",
            messages: [
              { role: "system", content: "You are a humorous assistant." },
              { role: "user", content: postPrompt },
            ],
          });
  
          const postSpecificJokes = postResponse.choices[0].message.content
            .split("\n")
            .filter(joke => joke.trim());
  
          postJokes.push({
            title: comment.title,
            jokes: postSpecificJokes,
          });
        } catch (error) {
          console.error(`Error generating jokes for post: ${comment.title}`, error);
          postJokes.push({
            title: comment.title || "Unknown Title",
            jokes: [],
          });
        }
      }
  
      // Save jokes to a JSON file (optional)
      // await this.SavePostsJokeFile(category, postJokes);
  
      return postJokes;
    } catch (error) {
      console.error("Error generating post jokes:", error);
      return [];
    }
  }
  
  
  shuffleArray(array) {
      for (let i = array.length - 1; i > 0; i--) {
          const j = Math.floor(Math.random() * (i + 1));
          [array[i], array[j]] = [array[j], array[i]]; // Swap elements
      }
      return array;
  }
  async JokesFile(topic, shuffledTopicJokes) {
    try {
        const jokesFilePath = path.join(__dirname, `${slugify(topic)}_topic_jokes.json`);
        const jokesData = {
            topicJokes: shuffledTopicJokes,
        };

        fs.writeFileSync(jokesFilePath, JSON.stringify(jokesData, null, 2));
        console.log(`Topic jokes saved to ${jokesFilePath}`);
    } catch (error) {
        console.error("Error saving topic jokes to file:", error);
    }
}

async SaveJokeFile(topic) {
    try {
        const topicJokes = await this.generateTopicJokes(topic);
        if (!topicJokes || topicJokes.length === 0) {
            console.log("No topic jokes generated.");
            return;
        }

        // Save the generated jokes to cache
        this.cache[topic] = { topicJokes };
        this.saveCache();

        const shuffledTopicJokes = this.shuffleArray(topicJokes); // Shuffle the topic jokes
        await this.JokesFile(topic, shuffledTopicJokes);
    } catch (error) {
        console.error("Error in SaveJokeFile:", error.message);
    }
}
async JokesFile(posts, shuffledPostsJokes) {
  try {
      const jokesFilePath = path.join(__dirname, `${slugify(posts)}_posts_jokes.json`);
      const jokesData = {
          postsJokes: shuffledPostsJokes,
      };

      fs.writeFileSync(jokesFilePath, JSON.stringify(jokesData, null, 2));
      console.log(`Topic jokes saved to ${jokesFilePath}`);
  } catch (error) {
      console.error("Error saving topic jokes to file:", error);
  }
}

async SavePostsJokeFile(posts) {
  try {
      const postsJokes = await this.generatePostJokes(posts);
      if (!postsJokes || postsJokes.length === 0) {
          console.log("No topic jokes generated.");
          return;
      }

      // Save the generated jokes to cache
      this.cache[posts] = { postsJokes };
      this.saveCache();

      const shuffledTopicJokes = this.shuffleArray(postsJokes); // Shuffle the topic jokes
      await this.JokesFile(posts, shuffledTopicJokes);
  } catch (error) {
      console.error("Error in SaveJokeFile:", error.message);
  }
}


async postComment(postUrl, joke, username) {
  try {
    // Preprocess the joke to remove numbers or numbered prefixes
    const cleanJoke = joke.replace(/^\d+\.\s*/, ''); // Remove numbers followed by a period and space
    console.log(`Posting joke: "${cleanJoke}" to ${videoUrl}`);

    // Go to the post page
    await this.page.goto(postUrl, { timeout: 60000 });

    // Wait for the comment section to be available
    await this.page.waitForSelector('a[data-event-click-target="commentables/survey_responses#new"]', { timeout: 30000 });
    await this.page.click('a[data-event-click-target="commentables/survey_responses#new"]');
    await this.page.waitForSelector('textarea[placeholder="Write your comment..."]', { timeout: 30000 });
    await this.page.fill('textarea[placeholder="Write your comment..."]', `${cleanJoke} @${username} #beladed`);

    // await this.page.fill('.notranslate.public-DraftEditor-content', `${cleanJoke} @${username} #beladed`);
    
    // Click the "Post" button
    await this.page.click('button[data-submit-on-click-form="#modal-comment form"]');
    console.log(`Comment posted successfully on ${postUrl}: "${cleanJoke}"`);
  } catch (error) {
    console.error(`Failed to post comment on ${postUrl}:`, error.message);
  }
}

async automateCommenting(hashtag) {
  try {
    // Step 1: Search for posts using the provided hashtag
    const { userComments } = await this.searchDiscussions(hashtag);
    
    if (userComments.length === 0) {
      console.log('No posts found with the provided hashtag.');
      return;
    }

    // Step 2: Generate jokes for the posts
    const postJokes = await this.generatePostJokes(hashtag);
    if (postJokes.length === 0) {
      console.log('No jokes generated for the posts.');
      return;
    }

    // Step 3: Shuffle the jokes for randomness
    const shuffledPostJokes = this.shuffleArray(postJokes);

    // Step 4: Iterate over posts to post comments
    for (let i = 0; i < userComments.length; i++) {
      const post = userComments[i];

      // Ensure videoUrl exists
      if (!post.postUrl) {
        console.error(`Error: videoUrl is undefined or invalid for post: ${post.title}`);
        continue;  // Skip this post
      }

      // Step 4: Select one joke from the shuffled list
      const joke = shuffledPostJokes[i]?.jokes[0] || "Here's a funny joke!"; // Choose the first joke after shuffling
      
      // Post the comment to the video
      await this.postComment(post.postUrl, joke, post.username);

      console.log(`Comment posted: "${joke}" on ${post.postUrl}`);
    }

    console.log("Automated commenting completed for all search results.");
  } catch (error) {
    console.error("Error during automated commenting:", error.message);
  }
}

  async close() {
    try {
      if (this.browser) {
        await this.browser.close();
        console.log("Browser closed successfully");
      } else {
        throw new Error("Browser not initialized. Call init() first.");
      }
    } catch (error) {
      console.error("Error closing browser:", error);
      throw error;
    }
  }
}

module.exports = G2;


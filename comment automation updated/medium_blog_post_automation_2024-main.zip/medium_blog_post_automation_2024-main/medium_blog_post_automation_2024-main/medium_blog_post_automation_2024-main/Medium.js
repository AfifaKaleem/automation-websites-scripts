const puppeteer = require('puppeteer-extra');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');
const fs = require('fs');

// Add stealth plugin and use defaults (all tricks to hide Puppeteer usage)
puppeteer.use(StealthPlugin());
require('dotenv').config();

const path = require('path');
const { OpenAI } = require('openai');
const slugify = require('slugify');

const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY,
});


class Medium {
  constructor() {
    this.browser = null;
    this.page = null;
    this.cache = {};  // In-memory cache
  }
 

// Helper functions to manage caching
loadCache() {
  const cacheFile = path.join(__dirname, 'jokes_cache.json');
  if (fs.existsSync(cacheFile)) {
      try {
          const data = fs.readFileSync(cacheFile, 'utf8');
          this.cache = JSON.parse(data);
      } catch (error) {
          console.error('Error loading cache:', error);
      }
  }
}

saveCache() {
  const cacheFile = path.join(__dirname, 'jokes_cache.json');
  try {
      fs.writeFileSync(cacheFile, JSON.stringify(this.cache, null, 2));
  } catch (error) {
      console.error('Error saving cache:', error);
  }
}

  async init() {
    try {
      this.browser = await puppeteer.launch({
        headless: false, // Run in non-headless mode
        args: [
          '--no-sandbox',
          '--disable-setuid-sandbox',
          '--disable-web-security',
          '--disable-features=IsolateOrigins,site-per-process',
          '--start-maximized'
        ]
      });

      // Create a new page in the default browser context
      this.page = await this.browser.newPage();
      this.loadCache();

      await this.page.setUserAgent(
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.5735.199 Safari/537.36'
      );

      await this.page.setExtraHTTPHeaders({
        'accept-language': 'en-US,en;q=0.9',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-user': '?1',
        'sec-fetch-dest': 'document'
      });

      console.log('Puppeteer browser launched successfully with stealth mode');
    } catch (error) {
      console.error('Error launching browser:', error);
      throw error;
    }
  }

  async login(email, password) {
    try {
      await this.page.goto('https://medium.com/', { waitUntil: 'networkidle2' });

      // Click on the sign-in button
      await this.page.waitForSelector('a[href*="/m/signin"]', { visible: true });
      await this.page.click('a[href*="/m/signin"]');

      // Click on the Google sign-in option
      await this.page.waitForSelector('a[href*="/m/connect/google"]', { visible: true });
      await this.page.click('a[href*="/m/connect/google"]');

      // Wait for Google login page to load
      await this.page.waitForSelector('input[type="email"]', { visible: true, timeout: 20000 });
      await this.page.type('input[type="email"]', email, { delay: 100 });
      await this.page.click('#identifierNext');

      // Wait for password field and enter password
      await this.page.waitForSelector('input[type="password"]', { visible: true, timeout: 20000 });
      await this.page.type('input[type="password"]', password, { delay: 100 });
      await this.page.click('#passwordNext');

      // Wait for navigation after login
      await this.page.waitForNavigation({ waitUntil: 'networkidle2' });

      console.log('Logged in to Medium successfully');
    } catch (error) {
      console.error('Error logging in to Medium:', error);
      throw error;
    }
  }

  async post(title, context) {

    await this.page.goto('https://medium.com/new-story', { waitUntil: 'networkidle2', timeout: 60000 });

    // Wait for editor to load
    await this.page.waitForSelector('h3[data-testid="editorTitleParagraph"]', { visible: true, timeout: 60000 });
    await this.page.type('h3[data-testid="editorTitleParagraph"]', title);

    await this.page.waitForSelector('div[data-testid="editorParagraph"]', { visible: true, timeout: 60000 });
    await this.page.type('div[data-testid="editorParagraph"]', context);

    // Click on the "Show Pre-Publish" button or equivalent
    await this.page.waitForSelector('button.button button--primary button--filled button--smaller button--withChrome u-accentColor--buttonNormal button--publish js-publishButton js-buttonRequiresPostId u-paddingLeft10 u-paddingRight10 button--chromeless js-buttonDisabledPrimary is-touched', { visible: true, timeout: 60000 });
    await this.page.click('button.button button--primary button--filled button--smaller button--withChrome u-accentColor--buttonNormal button--publish js-publishButton js-buttonRequiresPostId u-paddingLeft10 u-paddingRight10 button--chromeless js-buttonDisabledPrimary is-touched');

    // Optionally, type additional content if needed
    // await this.page.type('div[data-testid="editorParagraph"]', storytext);

    // Confirm publishing
    await this.page.waitForSelector('button[data-action="publish"]', { visible: true, timeout: 60000 });
    await this.page.click('button[data-action="publish"]');

    console.log('Post published on Medium successfully');

  }

  async searchHashtag(hashtag) {
    try {
        // Navigate to the Medium search page with the hashtag
        await this.page.goto(`https://medium.com/search?q=%23${hashtag}`, { waitUntil: 'networkidle2' });
  
        // Wait for the search results to load
        await this.page.waitForSelector('div.cp.bh.cq.cr.cs.ct');  // Updated stable selector for the post container
  
        // Get the current page URL
        const pageUrl = await this.page.url();
        console.log(`Current page URL: ${pageUrl}`);
  
        // Extract the relevant blog post details
        const articles = await this.page.evaluate((pageUrl) => {
            let results = [];
            // Grab each post container
            let items = document.querySelectorAll('div.cp.bh.cq.cr.cs.ct > div');  // Based on your HTML structure
  
            items.forEach(item => {
                try {
                    // Extract the blog post URL
                    const postUrlElement = item.querySelector('a.af.ag.ah.ai.aj.ak.al.am.an.ao.ap.aq.ar.as.at');
                    const postUrl = postUrlElement ? postUrlElement.getAttribute('href') : null;
  
                    // If postUrl exists, format it correctly as a full URL
                    const fullPostUrl = postUrl ? `https://medium.com${postUrl}` : null;
  
                    // Extract the image (photoUrl)
                    const photoUrlElement = item.querySelector('img');
                    const photoUrl = photoUrlElement ? photoUrlElement.src : null;
  
                    // Extract the title (main text) from the <h2> tag
                    const titleElement = item.querySelector('h2');
                    const title = titleElement ? titleElement.innerText : null;
  
                    // Extract the subheading from the <h3> tag
                    const subheadingElement = item.querySelector('h3');
                    const subheading = subheadingElement ? subheadingElement.innerText : null;
  
                    // Combine title and subheading for the 'text'
                    const text = title && subheading ? `${title} - ${subheading}` : (title || subheading);
  
                    // Extract the profile URL
                    const profileUrlElement = item.querySelector('a');  // Assuming profile URL is under 'a'
                    const rawProfileUrl = profileUrlElement ? profileUrlElement.href : null;
  
                    // Format profile URL and username (extract username from the profile URL)
                    const cleanProfileUrl = rawProfileUrl ? rawProfileUrl.split('?')[0] : null;  // Remove query parameters
                    const username = cleanProfileUrl ? cleanProfileUrl.split('https://medium.com/')[1] : null;  // Extract username part
                    
                    // Ensure username is in the '@username' format
                    const formattedUsername = username ? `@${username}` : null;
  
                    // Extract the display name from the <p> tag
                    const displayNameElement = item.querySelector('p.bf.b.in.z.ef.hl.eg.eh.ei.ej.ek.el.bk');  // Updated selector for displayName
                    const displayName = displayNameElement ? displayNameElement.innerText : null;
  
                    // Only push to results if displayName or username is valid
                    if (displayName || formattedUsername) {
                        results.push({
                            displayName,
                            username: formattedUsername,  // Use formatted username as '@username'
                            postUrl: fullPostUrl,  // Use the formatted full URL
                            profileUrl: cleanProfileUrl,  // Ensure profile URL is formatted correctly
                            photoUrl,
                            text,
                            pageUrl,
                            subheading// Include the pageUrl in each result
                        });
                    }
                } catch (err) {
                    console.error("Error extracting data for an item", err);
                }
            });
  
            return results;
        }, pageUrl); // Pass pageUrl as an argument to the evaluate function
   // Extract comments for each article
   for (let article of articles) {
    if (article.postUrl) {
        try {
            await this.page.goto(article.postUrl, { waitUntil: 'networkidle2' });

            // Wait for the comments section to load
            await this.page.waitForSelector('div[class*="responsesStream"]', { timeout: 60000 }); // Adjust selector and timeout as needed

            // Extract comments
            const comments = await this.page.evaluate(() => {
                const commentElements = document.querySelectorAll('div[class*="responsesStream"]');
                const extractedComments = [];

                commentElements.forEach(comment => {
                    try {
                        // Extract the comment text
                        const textElement = comment.querySelector('p');
                        const text = textElement ? textElement.innerText : null;

                       
                            extractedComments.push({
                                text,
                                
                            });
                        }
                     catch (err) {
                        console.error('Error extracting a comment:', err);
                    }
                });

                return extractedComments;
            });

            // Attach comments to the article
            article.comments = comments;
        } catch (err) {
            console.error(`Error extracting comments for article: ${article.postUrl}`, err);
        }
    }
}
        // If results are found
        if (articles.length > 0) {
            console.log(`Results for #${hashtag}:`, articles);
            return {
                message: "Hashtag found results",
                hash: articles  // Return the articles found
            };
        } else {
            return {
                message: "No results found for the hashtag",
                hash: []  // Return an empty array if no articles are found
            };
        }
    } catch (error) {
        console.error('Error searching hashtag:', error);
        return {
            message: "Error occurred during the search",
            hash: []  // Return an empty array in case of an error
        };
    }
}


async generateTopicJokes(topic) {
  try {
    if (this.cache[topic]) {
      console.log('Returning cached jokes for topic:', topic);
      return this.cache[topic].topicJokes;
    }

    const topicPrompt = `Tell me 50 jokes related to "${topic}", each less than 20 words.`;
    const topicResponse = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        { role: "system", content: "You are a helpful assistant." },
        { role: "user", content: topicPrompt },
      ],
    });

    const topicJokes = topicResponse.choices[0].message.content.split("\n").filter(joke => joke.trim());
    this.cache[topic] = this.cache[topic] || {};
    this.cache[topic].topicJokes = topicJokes;
    this.saveCache();

    return topicJokes;
  } catch (error) {
    console.error("Error generating topic jokes:", error);
    return [];
  }
}

async generatePostJokes(hashtag) {
  try {
    // Fetch posts based on hashtag
    const { userComments } = await this.searchHashtag(hashtag);

    if (!Array.isArray(userComments)) {
      throw new Error("Expected an array of posts but got something else.");
    }

    const postJokes = [];
    const limitedPosts = userComments.slice(0, 20); // Limit to the first 20 posts

    for (const post of limitedPosts) {
      const postContent = `
        text: ${post.text} 
        Description: ${post.subheading}
        Comments: ${post.comments.map(comment => comment.commentText).join(" ")}
      `;
      const postPrompt = `Generate 25 jokes related to the following post content: "${postContent}"`;

      try {
        const postResponse = await openai.chat.completions.create({
          model: "gpt-3.5-turbo",
          messages: [
            { role: "system", content: "You are a humorous assistant." },
            { role: "user", content: postPrompt },
          ],
        });

        const postSpecificJokes = postResponse.choices[0].message.content
          .split("\n")
          .filter(joke => joke.trim());
        postJokes.push({  jokes: postSpecificJokes });
      } catch (error) {
        console.error(`Error generating jokes for post: ${post.text}`);
        postJokes.push({ jokes: [] });
      }
    }

    // Save jokes to a JSON file
    // this.SavePostsJokeFile(hashtag, postJokes);

    return postJokes;
  } catch (error) {
    console.error("Error generating post jokes:", error);
    return [];
  }
}
shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]]; // Swap elements
    }
    return array;
}
async JokesFile(topic, shuffledTopicJokes) {
    try {
        const jokesFilePath = path.join(__dirname, `${slugify(topic)}_jokes.json`);
        const jokesData = {
            topicJokes: shuffledTopicJokes,
        };
        
        fs.writeFileSync(jokesFilePath, JSON.stringify(jokesData, null, 2));
        console.log(`Jokes saved to ${jokesFilePath}`);
    } catch (error) {
        console.error("Error saving jokes to file:", error);
    }
}


async SaveJokeFile(topic) { 
    const { topicJokes } = await this.generateTopicJokes(topic); 
    if (topicJokes.length === 0 ) { 
        console.log("No jokes generated."); 
        return; 
    } 

    // Save the generated jokes to cache
    this.cache[topic] = { topicJokes }; 
    this.saveCache();

    const shuffledTopicJokes = this.shuffleArray(topicJokes); // Shuffle the topic jokes 
 
    await this.JokesFile(topic, shuffledTopicJokes); 
}



async JokesFilePosts(posts, shuffledPostJokes) {
  try {
      const jokesFilePath = path.join(__dirname, `${slugify(posts)}_jokes.json`);
      const jokesData = {
          postJokes: shuffledPostJokes
      };
      
      fs.writeFileSync(jokesFilePath, JSON.stringify(jokesData, null, 2));
      console.log(`Jokes saved to ${jokesFilePath}`);
  } catch (error) {
      console.error("Error saving jokes to file:", error);
  }
}


async SavePostsJokeFile( posts) { 
  const { postJokes } = await this.generatePostJokes( posts); 
  if (postJokes.length === 0) { 
      console.log("No jokes generated."); 
      return; 
  } 

  // Save the generated jokes to cache
  this.cache[topic] = { postJokes }; 
  this.saveCache();
  const shuffledPostJokes = postJokes.map(postJokes => this.shuffleArray(postJokes)); // Shuffle post-specific jokes for each post 

  await this.JokesFilePosts(posts, shuffledPostJokes); 
}


/**
* Post a comment on a Rumble post.
* @param {string} postUrl - The URL of the blog post.
* @param {string} joke - The joke to post.
* @param {string} username - The username to tag in the comment.
*/
async postComment(postUrl, joke, username) {
  try {


      // Preprocess the joke to remove numbers or numbered prefixes
      const cleanJoke = joke.replace(/^\d+\.\s*/, ''); // Remove numbers followed by a period and space
      console.log(`Posting joke: "${cleanJoke}" to ${postUrl} with @${username}`);

      // Navigate to the post URL
      await this.page.goto(postUrl, { timeout: 60000 });

      // Wait for the comment box to appear
      await this.page.waitForSelector('div[role="textbox"][contenteditable="true"]');  // Adjusted selector for the comment box

      // Fill the comment with the joke and tag the extracted username
      await this.page.fill('div[role="textbox"][contenteditable="true"]', `${cleanJoke} @${username} #beladed`);

      // Wait for the "Respond" button to appear and click it
      await this.page.waitForSelector('button[data-testid="ResponseRespondButton"]');  // Updated selector for the respond button
      await this.page.click('button[data-testid="ResponseRespondButton"]');

      console.log(`Comment posted successfully on ${postUrl}: "${cleanJoke}"`);

  } catch (error) {
      console.error(`Failed to post comment on ${postUrl}:`, error.message);
  }
}

async automateCommenting(hashtag) {
  try {
    // Step 1: Search for posts using the provided hashtag
    const  userComments  = await this.searchHashtag(hashtag);
    // Step 2: Generate jokes for the posts
    const postJokes = await this.generatePostJokes(hashtag);
 

    // Step 3: Shuffle the jokes for randomness
    const shuffledPostJokes = this.shuffleArray(postJokes);

    // Step 4: Iterate over posts to post comments
    for (let i = 0; i < userComments.length; i++) {
      const post = userComments[i];
      // Step 4: Select one joke from the shuffled list
      const joke = shuffledPostJokes[i]?.jokes[0] || "Here's a funny joke!"; // Choose the first joke after shuffling
      
      // Post the comment to the video
      await this.postComment(post.postUrl, joke, post.username);

      console.log(`Comment posted: "${joke}" on ${post.postUrl}`);
    }

    console.log("Automated commenting completed for all search results.");
  } catch (error) {
    console.error("Error during automated commenting:", error.message);
  }
}

  async logout() {
    try {
      await this.page.goto('https://medium.com/', { waitUntil: 'networkidle2' });
      await this.page.waitForSelector('img[aria-label="Account"]', { visible: true });
      await this.page.click('img[aria-label="Account"]');
      await this.page.waitForSelector('a[href*="/m/logout"]', { visible: true });
      await this.page.click('a[href*="/m/logout"]');
      await this.page.waitForNavigation({ waitUntil: 'networkidle2' });
      console.log('Logged out of Medium successfully');
    } catch (error) {
      console.error('Error logging out of Medium:', error);
      throw error;
    }
  }

  async close() {
    try {
      if (this.browser) {
        await this.browser.close();
        console.log('Browser closed successfully');
      } else {
        throw new Error('Browser not initialized. Call init() first.');
      }
    } catch (error) {
      console.error('Error closing browser:', error);
      throw error;
    }
  }

  async saveCookies() {
    try {
      const cookies = await this.page.cookies();
      fs.writeFileSync('./cookies.json', JSON.stringify(cookies));
      console.log('Cookies saved successfully');
    } catch (error) {
      console.error('Error saving cookies:', error);
      throw error;
    }
  }

  async loadCookies() {
    try {
      const cookies = JSON.parse(fs.readFileSync('./cookies.json', 'utf8'));
      await this.page.setCookie(...cookies);
      console.log('Cookies loaded successfully');
    } catch (error) {
      console.error('Error loading cookies:', error);
      throw error;
    }
  }
}

module.exports = Medium;

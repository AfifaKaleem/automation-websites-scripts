const express = require("express");
const bodyParser = require("body-parser");
const Medium = require("./Medium");

const app = express();
const port = 3000;

app.use(bodyParser.json());

let medium = new Medium();

app.post("/api/automation/medium/init", async (req, res) => {
  try {
    if (!medium.browser) { // Check if the browser has already been initialized
      await meetup.init();
      res.send({ message: "medium automation initialized" });
    } else {
      res.send({ message: "medium automation already initialized" });
    }
  } catch (err) {
    res.status(500).json({ error: "Error initiating medium", details: err.message });
  }
});

app.post("/api/automation/medium/login", async (req, res) => {
  const { email, password } = req.body;
  try {
    if (!medium.page) {
      await medium.init();
    }
    await medium.login(email, password);
    res.send({ message: "Logged in to medium" });
  } catch (err) {
    res.status(500).json({ error: "Error logging in to medium", details: err.message });
  }
});

app.post("/api/automation/medium/logout", async (req, res) => {
 
    if (!medium.page) {
      return res.status(400).json({ error: "medium not initialized or not logged in" });
    }
    await medium.logout();
    res.send({ message: "User logged out successfully" });
});

app.post("/api/automation/medium/postwork", async (req, res) => {
  const { title,context } = req.body;
    if (!medium.page) {
      return res.status(400).json({ error: "medium not initialized or not logged in" });
    }
    await medium.post(title,context);
    res.send({ message: "Post published successfully" });
});

app.post("/api/automation/medium/search-hashtag", async (req, res) => {
  const { hashtag } = req.body;
    if (!medium.page) {
      return res.status(400).json({ error: "medium not initialized or not logged in" });
    }
    const hash=await medium.searchHashtag(hashtag);
    res.send({ message: "hashtag founded result" ,hash});
});


/**
 * Endpoint to automate commenting on posts based on hashtag.
 */
app.post("/api/automation/medium/automate-commenting", async (req, res) => {
  const { hashtag } = req.body;
  if (!medium) {
    return res.status(400).json({ message: "Please log in first" });
  }


  if (!hashtag) {
    return res.status(400).json({ message: "Hashtag is required" });
  }


  try {
    await medium.automateCommenting(hashtag);
    res.status(200).json({ message: "Commenting automation completed successfully" });
  } catch (error) {
    console.error("Commenting automation failed:", error);
    res.status(500).json({ message: "Commenting automation failed.", error: error.message });
  }
});

/**
 * Endpoint to generate jokes based on a topic.
 */
app.post("/api/automation/medium/generate-jokes-topic", async (req, res) => {
  const { topic } = req.body;

  if (!topic ) {
    return res.status(400).json({ message: "Topic is required" });
  }

  try {
    const jokes = await medium.generateTopicJokes(topic,);
    res.status(200).json({ jokes });
  } catch (error) {
    console.error("Joke generation failed:", error);
    res.status(500).json({ message: "Joke generation failed.", error: error.message });
  }
});


app.post("/api/automation/medium/generate-jokes-posts", async (req, res) => {
  const { posts } = req.body;

  if (!posts) {
    return res.status(400).json({ message: "Topic is required" });
  }

  try {
    const jokes = await medium.generatePostJokes(posts);
    res.status(200).json({ jokes });
  } catch (error) {
    console.error("Joke generation failed:", error);
    res.status(500).json({ message: "Joke generation failed.", error: error.message });
  }
});
/**
 * Endpoint to save jokes to a file.
 */
app.post("/api/automation/medium/save-jokes-topic",  async (req, res) => {
  const {  topic} = req.body;
  if (!medium) {
    return res.status(400).json({ message: "Please log in first" });
  }


  try {
    await medium.SaveJokeFile(topic);
    res.status(200).json({ message: `Jokes saved for "${topic}".` });
  } catch (error) {
    console.error("Saving jokes failed:", error);
    res.status(500).json({ message: "Failed to save jokes.", error: error.message });
  }
});

app.post("/api/automation/medium/save-jokes-posts",  async (req, res) => {
  const {   posts} = req.body;
  if (!medium) {
    return res.status(400).json({ message: "Please log in first" });
  }


  try {
    await medium.SavePostsJokeFile(posts);
    res.status(200).json({ message: `Jokes saved for "${posts}".` });
  } catch (error) {
    console.error("Saving jokes failed:", error);
    res.status(500).json({ message: "Failed to save jokes.", error: error.message });
  }
});
app.post("/api/automation/medium/close", async (req, res) => {
  try {
    await medium.close();
    res.send({ message: "medium automation closed" });
  } catch (err) {
    res.status(500).json({ error: "Error closing medium", details: err.message });
  }
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});


const express = require("express");
const bodyParser = require("body-parser");
const Blogger = require("./Blogger");

const app = express();
const port = 3000;

app.use(bodyParser.json());

let blogger = new Blogger();

app.post("/api/automation/blogger/init", async (req, res) => {
  try {
    if (!blogger.browser) { // Check if the browser has already been initialized
      await blogger.init();
      res.send({ message: "Blogger automation initialized" });
    } else {
      res.send({ message: "Blogger automation already initialized" });
    }
  } catch (err) {
    res.status(500).json({ error: "Error initiating Blogger", details: err.message });
  }
});

app.post("/api/automation/blogger/login", async (req, res) => {
  const { email, password } = req.body;
  try {
    if (!blogger.page) {
      await blogger.init();
    }
    await blogger.loginBlogger(email, password);
    res.send({ message: "Logged in to Blogger" });
  } catch (err) {
    res.status(500).json({ error: "Error logging in to Blogger", details: err.message });
  }
});

app.post("/api/automation/blogger/logout", async (req, res) => {
 
    if (!blogger.page) {
      return res.status(400).json({ error: "Blogger not initialized or not logged in" });
    }
    await blogger.logoutBlogger();
    res.send({ message: "User logged out successfully" });
});

app.post("/api/automation/blogger/postwork", async (req, res) => {
  const { title,editid,postid,context } = req.body;
    if (!blogger.page) {
      return res.status(400).json({ error: "Blogger not initialized or not logged in" });
    }
    await blogger.postBlogger(title,editid,postid,context);
    res.send({ message: "Post published successfully" });
});

app.post("/api/automation/blogger/close", async (req, res) => {
  try {
    await blogger.close();
    res.send({ message: "Blogger automation closed" });
  } catch (err) {
    res.status(500).json({ error: "Error closing Blogger", details: err.message });
  }
});

// Define the endpoint to search hashtags
app.post('/api/automation/blogger/search', async (req, res) => {
  const { hashtag } = req.body;

  if (!hashtag) {
      return res.status(400).json({ error: "Hashtag is required" });
  }

  try {
      const results = await blogger.searchHashtagOnBlogger(hashtag);
      return res.json(results);
  } catch (error) {
      return res.status(500).json({ error: error.message });
  }
});


/**
 * Endpoint to automate commenting on posts based on hashtag.
 */
app.post("/api/automation/blogger/automate-commenting", async (req, res) => {
  const { hashtag } = req.body;
  if (!blogger) {
    return res.status(400).json({ message: "Please log in first" });
  }


  if (!hashtag) {
    return res.status(400).json({ message: "Hashtag is required" });
  }


  try {
    await blogger.automateCommenting(hashtag);
    res.status(200).json({ message: "Commenting automation completed successfully" });
  } catch (error) {
    console.error("Commenting automation failed:", error);
    res.status(500).json({ message: "Commenting automation failed.", error: error.message });
  }
});

/**
 * Endpoint to generate jokes based on a topic.
 */
app.post("/api/automation/blogger/generate-jokes-topic", async (req, res) => {
  const { topic } = req.body;

  if (!topic) {
    return res.status(400).json({ message: "Topic is required" });
  }

  try {
    const jokes = await blogger.generateTopicJokes(topic);
    res.status(200).json({ jokes });
  } catch (error) {
    console.error("Joke generation failed:", error);
    res.status(500).json({ message: "Joke generation failed.", error: error.message });
  }
});

/**
 * Endpoint to generate jokes based on a topic.
 */
app.post("/api/automation/blogger/generate-jokes-posts", async (req, res) => {
  const { posts } = req.body;

  if ( !posts) {
    return res.status(400).json({ message: "Topic is required" });
  }

  try {
    const jokes = await blogger.generatePostJokes(posts);
    res.status(200).json({ jokes });
  } catch (error) {
    console.error("Joke generation failed:", error);
    res.status(500).json({ message: "Joke generation failed.", error: error.message });
  }
});


/**
 * Endpoint to save jokes to a file.
 */
app.post("/api/automation/blogger/save-jokes-topic",  async (req, res) => {
  const {  topic } = req.body;
  if (!blogger) {
    return res.status(400).json({ message: "Please log in first" });
  }


  try {
    await blogger.SaveJokeFile(topic);
    res.status(200).json({ message: `Jokes saved for "${topic}".` });
  } catch (error) {
    console.error("Saving jokes failed:", error);
    res.status(500).json({ message: "Failed to save jokes.", error: error.message });
  }
});

app.post("/api/automation/blogger/save-jokes-posts",  async (req, res) => {
  const { posts} = req.body;
  if (!blogger) {
    return res.status(400).json({ message: "Please log in first" });
  }


  try {
    await blogger.SavePostsJokeFile(posts);
    res.status(200).json({ message: `Jokes saved for "${posts}".` });
  } catch (error) {
    console.error("Saving jokes failed:", error);
    res.status(500).json({ message: "Failed to save jokes.", error: error.message });
  }
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});


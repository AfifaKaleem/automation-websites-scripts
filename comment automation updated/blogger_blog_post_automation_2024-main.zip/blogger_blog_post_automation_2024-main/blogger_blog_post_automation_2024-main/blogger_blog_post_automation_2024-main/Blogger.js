const puppeteer = require('puppeteer-extra');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');
const fs = require('fs');

// Add stealth plugin and use defaults (all tricks to hide Puppeteer usage)
puppeteer.use(StealthPlugin());
require('dotenv').config();

const path = require('path');
const { OpenAI } = require('openai');
const slugify = require('slugify');

const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY,
});

class Blogger {
  constructor() {
    this.browser = null;
    this.page = null;
    this.cache = {};  // In-memory cache
  }

  async init() {
    try {
      this.browser = await puppeteer.launch({
        headless: false,
        args: [
          '--no-sandbox',
          '--disable-setuid-sandbox',
          '--disable-web-security',
          '--disable-features=IsolateOrigins,site-per-process'
        ]
      });

      // Create a new page in the default browser context
      this.page = await this.browser.newPage();
       // Load cache from file if it exists
      this.loadCache();

      await this.page.setUserAgent(
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.5735.199 Safari/537.36'
      );

      await this.page.setExtraHTTPHeaders({
        'accept-language': 'en-US,en;q=0.9',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-user': '?1',
        'sec-fetch-dest': 'document'
      });

      console.log('Puppeteer browser launched successfully with stealth mode');
    } catch (error) {
      console.error('Error launching browser:', error);
      throw error;
    }
  }

 

// Helper functions to manage caching
loadCache() {
    const cacheFile = path.join(__dirname, 'jokes_cache.json');
    if (fs.existsSync(cacheFile)) {
        try {
            const data = fs.readFileSync(cacheFile, 'utf8');
            this.cache = JSON.parse(data);
        } catch (error) {
            console.error('Error loading cache:', error);
        }
    }
}

saveCache() {
    const cacheFile = path.join(__dirname, 'jokes_cache.json');
    try {
        fs.writeFileSync(cacheFile, JSON.stringify(this.cache, null, 2));
    } catch (error) {
        console.error('Error saving cache:', error);
    }
}


  async loginBlogger(email, password) {
    try {
      // Go to the Blogger login page
      await this.page.goto('https://accounts.google.com/v3/signin/identifier?continue=https%3A%2F%2Fwww.blogger.com%2Fhome&hl=en-US&ifkv=Ab5oB3r97C-1wnfLKmiVzsgc2LjUtp_ZGY3CbQa1c5tL3c33MaRw6S_luCrw8mTia0aZuVISFCC3Kg&ltmpl=blogger&rip=1&sacu=1&service=blogger&flowName=GlifWebSignIn&flowEntry=ServiceLogin&dsh=S1997871822%3A1724160452446085&ddm=0', { waitUntil: 'networkidle2' });
  
      // Enter the email address
      await this.page.waitForSelector('input[type="email"]', { visible: true, timeout: 20000 });
      await this.page.type('input[type="email"]', email, { delay: 100 });
      await this.page.click('#identifierNext');
  
      // Enter the password
      await this.page.waitForSelector('input[type="password"]', { visible: true, timeout: 600000 });
      await this.page.type('input[type="password"]', password, { delay: 100 });
      await this.page.click('#passwordNext');
  
      // Wait for navigation after login
      await this.page.waitForNavigation({ waitUntil: 'networkidle2' });
  
      console.log('Logged in to Blogger');
    } catch (error) {
      console.error('Error logging in to Blogger:', error);
      throw error;
    }
  }
  async postBlogger(title,editid,postid,context) {
   
        // Navigate to Blogger's dashboard (Assuming this is the specific post editor URL)
        await this.page.goto(`https://www.blogger.com/blog/post/edit/${editid}/${postid}`, { waitUntil: 'networkidle2' });
        console.log('Navigated to Blogger dashboard');
  
        // Type the title in the title input field
        await this.page.waitForSelector('input[aria-label="Title"]', { visible: true });
        await this.page.type('input[aria-label="Title"]', title, { delay: 100 });
        console.log('Title filled in');

           // Wait for the iframe to be available and locate it
    const iframeElement = await this.page.waitForSelector('iframe.editable');
    const frame = await iframeElement.contentFrame(); // Switch to the iframe context

    // Fill the content inside the iframe
    await frame.type('body[role="textbox"]', context); // Replace with desired content

        // Click on the Publish button
        await this.page.waitForSelector('div[aria-label="Publish"]', { visible: true });
        await this.page.click('div[aria-label="Publish"]');
        console.log('Clicked on Publish button');
        await this.page.evaluate(() => {
          const button = [...document.querySelectorAll('span')].find(el => el.textContent === 'Confirm');
          if (button) button.click();
        });
        
  
        // Confirm publishing
        console.log('Post published on Blogger');
}

  

  
  async logoutBlogger() {

      await this.page.goto('https://www.blogger.com/', { waitUntil: 'networkidle2' });
      await this.page.click('img[aria-label="Google Account"]');
      await this.page.waitForSelector('text="Sign out"');
      await this.page.click('text="Sign out"');
      await this.page.waitForNavigation({ waitUntil: 'networkidle2' });
      console.log('Logged out of Blogger');
    
  }
  async searchHashtagOnBlogger(hashtag) {
    try {
        await this.page.goto('https://www.blogger.com/', { timeout: 60000 });
        // Wait for the input field and type the hashtag
        await this.page.waitForSelector('input[type="text"]', { timeout: 60000 });
        await this.page.type('input[type="text"]', `#${hashtag}`);
        await this.page.keyboard.press("Enter");

        // Wait for the results to load
        await this.page.waitForSelector('.xmyU9c ', { timeout: 60000 });

        // Extract search results
        const articles = await this.page.evaluate(() => {
            const results = [];
            document.querySelectorAll('.xmyU9c').forEach(item => {
                const titleElement = item.querySelector('div[jsname="d2wxvf"] span.UHwcef');
                const photoElement = item.querySelector('img.odLeEc');
                const blog = item.querySelector('a.FKF6mc.TpQm9d');
                const profile = item.querySelector('a[href^="/profile/"]');
                const user = item.querySelector('div.GLDMfb.UHwcef');
                const des = item.querySelector('span.uZsIBe span.YQgXbc.qtvRHc');
                results.push({
                    title: titleElement ? titleElement.innerText : 'No title',
                    blogUrl: blog ? blog.href : 'No URL',
                    profileUrl: profile ? profile.href : 'No profile',
                    username: user ? user.innerText : 'No username',
                    photoUrl: photoElement ? photoElement.src : 'No image',
                    displayName: user ? user.innerText : 'No display name',
                    description: des ? des.textContent : "No description"
                });
            });
            return results;
        });

        // Extract comments for each article
        for (let article of articles) {
            if (article.blogUrl !== 'No URL') {
                try {
                    await this.page.goto(article.blogUrl, { timeout: 60000 });

                    // Scroll to load all comments
                    while (true) {
                        const previousHeight = await this.page.evaluate(() => document.body.scrollHeight);
                        await this.page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
                        await new Promise(resolve => setTimeout(resolve, 1000)); // Delay
                        const newHeight = await this.page.evaluate(() => document.body.scrollHeight);
                        if (newHeight === previousHeight) break; // Exit loop if no new content is loaded
                    }

                    // Wait for the comments section to load
                    await this.page.waitForSelector('ol#top-ra', { timeout: 60000 });

                    // Extract comments
                    article.comments = await this.page.evaluate(() => {
                        return Array.from(document.querySelectorAll('ol#top-ra > li.comment')).map(comment => {
                            
                            const commentContentElement = comment.querySelector('p.comment-content');
                            const commentText = commentContentElement ? commentContentElement.innerText : 'No content';

                            return {
                                text: commentText
                            };
                        });
                    });
                } catch (err) {
                    console.error(`Error extracting comments for article: ${article.blogUrl}`, err);
                }
            }
        }

        console.log("Search results with comments:", articles);
        return articles;

    } catch (err) {
        console.error("Error searching for hashtags:", err);
    }
}

async generateTopicJokes(topic) {
  try {
    if (this.cache[topic]) {
      console.log('Returning cached jokes for topic:', topic);
      return this.cache[topic].topicJokes;
    }

    const topicPrompt = `Tell me 50 jokes related to "${topic}", each less than 20 words.`;
    const topicResponse = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        { role: "system", content: "You are a helpful assistant." },
        { role: "user", content: topicPrompt },
      ],
    });

    const topicJokes = topicResponse.choices[0].message.content.split("\n").filter(joke => joke.trim());
    this.cache[topic] = this.cache[topic] || {};
    this.cache[topic].topicJokes = topicJokes;
    this.saveCache();

    return topicJokes;
  } catch (error) {
    console.error("Error generating topic jokes:", error);
    return [];
  }
}

async generatePostJokes(hashtag) {
  try {
    const userComments = await this.searchHashtagOnBlogger(hashtag);

    if (!Array.isArray(userComments)) {
      throw new Error("Expected an array of posts but got something else.");
    }

    const postJokes = [];
    const limitedPosts = userComments.slice(0, 20);

    for (const post of limitedPosts) {
      const postContent = `
        title: ${post.title} 
        description: ${post.description}
        Comments: ${
          Array.isArray(post.comments)
            ? post.comments.map(comment => comment.text).join(" ")
            : "No comments available"
        }
      `;
      const postPrompt = `Generate 25 jokes related to the following post content: "${postContent}"`;

      try {
        const postResponse = await openai.chat.completions.create({
          model: "gpt-3.5-turbo",
          messages: [
            { role: "system", content: "You are a humorous assistant." },
            { role: "user", content: postPrompt },
          ],
        });

        const postSpecificJokes = postResponse.choices[0].message.content
          .split("\n")
          .filter(joke => joke.trim());
        postJokes.push({ jokes: postSpecificJokes });
      } catch (error) {
        console.error(`Error generating jokes for post: ${post.title}`, error);
        postJokes.push({ jokes: [] });
      }
    }

    return postJokes;
  } catch (error) {
    console.error("Error generating post jokes:", error);
    return [];
  }
}

shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]]; // Swap elements
  }
  return array;
}
async JokesFile(topic, shuffledTopicJokes) {
try {
    const jokesFilePath = path.join(__dirname, `${slugify(topic)}_topic_jokes.json`);
    const jokesData = {
        topicJokes: shuffledTopicJokes,
    };

    fs.writeFileSync(jokesFilePath, JSON.stringify(jokesData, null, 2));
    console.log(`Topic jokes saved to ${jokesFilePath}`);
} catch (error) {
    console.error("Error saving topic jokes to file:", error);
}
}

async SaveJokeFile(topic) {
try {
    const topicJokes = await this.generateTopicJokes(topic);
    if (!topicJokes || topicJokes.length === 0) {
        console.log("No topic jokes generated.");
        return;
    }

    // Save the generated jokes to cache
    this.cache[topic] = { topicJokes };
    this.saveCache();

    const shuffledTopicJokes = this.shuffleArray(topicJokes); // Shuffle the topic jokes
    await this.JokesFile(topic, shuffledTopicJokes);
} catch (error) {
    console.error("Error in SaveJokeFile:", error.message);
}
}


async SavePostsJokeFile(hashtag,shuffledPostJokes) {
try {
const jokesFilePath = path.join(__dirname, `${hashtag}_posts_jokes.json`);
fs.writeFileSync(jokesFilePath, JSON.stringify(shuffledPostJokes, null, 2));
console.log(`Jokes for hashtag "${hashtag}" saved to ${jokesFilePath}`);
} catch (error) {
console.error("Error saving jokes to file:", error);
}
}

/**
 * Post a comment on a Rumble post.
 * @param {string} blogUrl - The URL of the blog post.
 * @param {string} joke - The joke to post.
 * @param {string} username - The username to tag in the comment.
 */
async postComment(blogUrl, joke, username) {
  try {
      // Preprocess the joke to remove numbers or numbered prefixes
      const cleanJoke = joke.replace(/^\d+\.\s*/, ''); // Remove numbers followed by a period and space
      console.log(`Posting joke: "${cleanJoke}" to ${blogUrl} with @${username}`);

      await this.page.goto(blogUrl, { timeout: 60000 });

      // Wait for the iframe to be available
      await this.page.waitForSelector('iframe.blogger-comment-from-post', { timeout: 60000 });

      // Switch to the iframe
      const iframe = await this.page.$('iframe.blogger-comment-from-post');
      const iframeContent = await iframe.contentFrame();
      await iframeContent.click('text="Enter Comment"');

      // Wait for the comment box inside the iframe to appear
      await iframeContent.waitForSelector('textarea.KHxj8b.tL9Q4c', { timeout: 60000 });

      // Fill the comment with the joke and tag the extracted username
      await iframeContent.fill('textarea.KHxj8b.tL9Q4c', `${cleanJoke} @${username} #beladed`);
      
      // Wait for the publish button to be available and click it
      await iframeContent.waitForSelector('span.RveJvd.snByac', { timeout: 60000 });
      await iframeContent.click('span.RveJvd.snByac');
      
      console.log(`Comment posted successfully on ${blogUrl}: "${cleanJoke}"`);
  } catch (error) {
      console.error(`Failed to post comment on ${blogUrl}:`, error.message);
  }
}




async automateCommenting(hashtag) {
  try {
    // Step 1: Search for posts using the provided hashtag
    const { userComments } = await this.searchHashtagOnBlogger(hashtag);
  

    // Step 2: Generate jokes for the posts
    const postJokes = await this.generatePostJokes(hashtag);
   

    // Step 3: Shuffle the jokes for randomness
    const shuffledPostJokes = this.shuffleArray(postJokes);

    // Step 4: Iterate over posts to post comments
    for (let i = 0; i < userComments; i++) {
      const post = userComments[i];

      // Ensure postUrl exists
      if (!post.blogUrl) {
        console.error(`Error: postUrl is undefined or invalid for post: ${post.blogUrl}`);
        continue;  // Skip this post
      }

      // Step 4: Select one joke from the shuffled list
      const joke = shuffledPostJokes[i]?.jokes[0] || "Here's a funny joke!"; // Choose the first joke after shuffling
      
      // Post the comment to the video
      await this.postComment(post.blogUrl, joke, post.username);

      console.log(`Comment posted: "${joke}" on ${post.blogUrl}`);
    }

    console.log("Automated commenting completed for all search results.");
  } catch (error) {
    console.error("Error during automated commenting:", error.message);
  }
}
  async close() {
    try {
      if (this.browser) {
        await this.browser.close();
        console.log('Browser closed successfully');
      } else {
        throw new Error('Browser not initialized. Call init() first.');
      }
    } catch (error) {
      console.error('Error closing browser:', error);
      throw error;
    }
  }

  async saveCookies() {
    const cookies = await this.page.cookies();
    fs.writeFileSync('./cookies.json', JSON.stringify(cookies));
  }

  async loadCookies() {
    const cookies = JSON.parse(fs.readFileSync('./cookies.json'));
    await this.page.setCookie(...cookies);
  }
}

module.exports = Blogger;

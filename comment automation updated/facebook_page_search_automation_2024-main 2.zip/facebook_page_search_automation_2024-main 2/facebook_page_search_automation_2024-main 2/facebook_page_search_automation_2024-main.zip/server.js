const express = require("express");
const FacebookPageMessage = require("./FacebookPageMessage");
const app = express();
const bodyParser = require("body-parser");
app.use(bodyParser.json());
const port = 3000;

app.use(express.json());

let facebook;
app.post("/api/automation/facebook/login", async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.json({ message: "Email and Password are required" });
  }

  if (!facebook) {
    facebook = new FacebookPageMessage();
    await facebook.init();
  }
  await facebook.login(email, password);
  res.send("Logged in successfully");
});

app.post("/api/automation/facebook/change-page", async (req, res) => {
  const { pageName } = req.body;
  if (!pageName) {
    return res.json({ message: "Page name is required" });
  }

  await facebook.changePage(pageName);
  res.send("Switched to page: " + pageName);
});

app.post("/api/automation/facebook/select-contact", async (req, res) => {
  const { searchName } = req.body;
  if (!searchName) {
    return res.json({ message: "All post details are required" });
  }

  try {
    await facebook.selectContact(searchName);
    res.send("user selected successfully");
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

app.post("/api/automation/facebook/send-message", async (req, res) => {
  const { message } = req.body;
  if (!message) {
    return res.json({ message: "All post details are required" });
  }

  try {
    await facebook.sendMessage(message);
    res.send("Post message successfully");
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

app.get("/api/automation/facebook/logout", async (req, res) => {
  if (!facebook) {
    return res.json({ message: "Please login first" });
  }
  await facebook.close();
  facebook = false;
  res.send("Log out successful");
});


app.post("/api/automation/facebook/search-users", async (req, res) => {
  const { username } = req.body;
  if (!username) {
    return res.json({ message: "Username is required" });
  }

  try {
    const users = await facebook.searchUsersByUsername(username);
    res.json(users);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Search Facebook Pages Route
app.post("/api/automation/facebook/search-pages", async (req, res) => {
  const { pageName } = req.body;
  if (!pageName) {
    return res.json({ message: "Page name is required" });
  }

  try {
    const pages = await facebook.searchFacebookPages(pageName);
    res.json(pages);
  } catch (error) {
    res.status(500).json({ message: "Page search failed: " + error.message });
  }
});

// Search Facebook Groups Route
app.post("/api/automation/facebook/search-groups", async (req, res) => {
  const { groupName } = req.body;
  if (!groupName) {
    return res.json({ message: "Group name is required" });
  }

  try {
    const groups = await facebook.searchFacebookGroups(groupName);
    res.json(groups);
  } catch (error) {
    res.status(500).json({ message: "Group search failed: " + error.message });
  }
});

// New route to search Facebook Live users
app.post("/api/automation/facebook/search-live-users", async (req, res) => {
  const { userName } = req.body;
  if (!userName) {
    return res.json({ message: "Live username is required" });
  }

  try {
    const liveUsers = await facebook.searchFacebookLiveUsers(userName);
    res.json(liveUsers);
  } catch (error) {
    res.status(500).json({ message: "Live user search failed: " + error.message });
  }
});


// New route to search Facebook Posts Users
app.post("/api/automation/facebook/search-posts-users", async (req, res) => {
  const { postKeyword } = req.body;
  if (!postKeyword) {
    return res.json({ message: "Post keyword is required" });
  }

  try {
    const postsUsers = await facebook.searchFacebookPostsUsers(postKeyword);
    res.json(postsUsers);
  } catch (error) {
    res.status(500).json({ message: "Post user search failed: " + error.message });
  }
});

app.post("/api/automation/facebook/search-group-users",async(req,res)=>{
  const{groupId} =req.body;
  if(!groupId){
    return res.json({ message: "GroupId is required" });
  }
  try {
    const groupUsers = await facebook.searchFacebookGroupUsers(groupId);
    res.json(groupUsers);
  } catch (error) {
    res.status(500).json({ message: "Post user search failed: " + error.message });
  }
});

app.post("/api/automation/facebook/search-page-users",async(req,res)=>{
  const{pageName} =req.body;
  if(!pageName){
    return res.json({ message: "pagename is required" });
  }
  try {
    const pageUsers = await facebook.searchFacebookPageUsers(pageName);
    res.json(pageUsers);
  } catch (error) {
    res.status(500).json({ message: "Post user search failed: " + error.message });
  }
});


// Search Facebook Hashtags Route
app.post("/api/automation/facebook/search-hashtags", async (req, res) => {
  const { hashtag } = req.body;
  if (!hashtag) {
    return res.status(400).json({ message: "Hashtag is required" });
  }

  try {
    const posts = await facebook.searchFacebookHashtags(hashtag);
    res.json(posts);
  } catch (error) {
    res.status(500).json({ message: "Hashtag search failed: " + error.message });
  }
});

/**
 * Endpoint to automate commenting on posts based on hashtag.
 */
app.post("/api/automation/facebook/automate-commenting-page", async (req, res) => {
  const { pageName } = req.body;
  if (!facebook) {
    return res.status(400).json({ message: "Please log in first" });
  }


  if (!pageName) {
    return res.status(400).json({ message: "Hashtag is required" });
  }


  try {
    await facebook.automateCommentingPage(pageName);
    res.status(200).json({ message: "Commenting automation completed successfully" });
  } catch (error) {
    console.error("Commenting automation failed:", error);
    res.status(500).json({ message: "Commenting automation failed.", error: error.message });
  }
});


/**
 * Endpoint to automate commenting on posts based on hashtag.
 */
app.post("/api/automation/facebook/automate-commenting-live", async (req, res) => {
  const { userName } = req.body;
  if (!facebook) {
    return res.status(400).json({ message: "Please log in first" });
  }


  if (!userName) {
    return res.status(400).json({ message: "Hashtag is required" });
  }


  try {
    await facebook.automateCommentingLive(userName);
    res.status(200).json({ message: "Commenting automation completed successfully" });
  } catch (error) {
    console.error("Commenting automation failed:", error);
    res.status(500).json({ message: "Commenting automation failed.", error: error.message });
  }
});
/**
 * Endpoint to automate commenting on posts based on hashtag.
 */
app.post("/api/automation/facebook/automate-commenting-group", async (req, res) => {
  const { groupName } = req.body;
  if (!facebook) {
    return res.status(400).json({ message: "Please log in first" });
  }


  if (!groupName) {
    return res.status(400).json({ message: "Hashtag is required" });
  }


  try {
    await facebook.automateCommentingGroup(groupName);
    res.status(200).json({ message: "Commenting automation completed successfully" });
  } catch (error) {
    console.error("Commenting automation failed:", error);
    res.status(500).json({ message: "Commenting automation failed.", error: error.message });
  }
});


/**
 * Endpoint to automate commenting on posts based on hashtag.
 */
app.post("/api/automation/facebook/automate-commenting-post", async (req, res) => {
  const { postKeyword } = req.body;
  if (!facebook) {
    return res.status(400).json({ message: "Please log in first" });
  }


  if (!postKeyword) {
    return res.status(400).json({ message: "Hashtag is required" });
  }


  try {
    await facebook.automateCommentingPost(postKeyword);
    res.status(200).json({ message: "Commenting automation completed successfully" });
  } catch (error) {
    console.error("Commenting automation failed:", error);
    res.status(500).json({ message: "Commenting automation failed.", error: error.message });
  }
});

/**
 * Endpoint to generate jokes based on a topic.
 */
app.post("/api/automation/facebook/generate-jokes-page", async (req, res) => {
  const { topic } = req.body;

  if (!topic ) {
    return res.status(400).json({ message: "Topic is required" });
  }

  try {
    const jokes = await facebook.generateTopicJokes(topic);
    res.status(200).json({ jokes });
  } catch (error) {
    console.error("Joke generation failed:", error);
    res.status(500).json({ message: "Joke generation failed.", error: error.message });
  }
});

app.post("/api/automation/facebook/generate-jokes-page-postbased", async (req, res) => {
  const { posts } = req.body;

  if (!posts) {
    return res.status(400).json({ message: "Topic is required" });
  }

  try {
    const jokes = await facebook.generatePostJokesforPages(posts);
    res.status(200).json({ jokes });
  } catch (error) {
    console.error("Joke generation failed:", error);
    res.status(500).json({ message: "Joke generation failed.", error: error.message });
  }
});


app.post("/api/automation/facebook/generate-jokes-live", async (req, res) => {
  const  {topic} = req.body;

  if (!topic ) {
    return res.status(400).json({ message: "Topic is required" });
  }

  try {
    const jokes = await facebook.generateTopicJokesLive(topic);
    res.status(200).json({ jokes });
  } catch (error) {
    console.error("Joke generation failed:", error);
    res.status(500).json({ message: "Joke generation failed.", error: error.message });
  }
});


app.post("/api/automation/facebook/generate-jokes-live-postbased", async (req, res) => {
  const { posts } = req.body;

  if (!posts ) {
    return res.status(400).json({ message: "Topic is required" });
  }

  try {
    const jokes = await facebook.generatePostJokesforLive(posts);
    res.status(200).json({ jokes });
  } catch (error) {
    console.error("Joke generation failed:", error);
    res.status(500).json({ message: "Joke generation failed.", error: error.message });
  }
});

app.post("/api/automation/facebook/generate-jokes-group", async (req, res) => {
  const { topic} = req.body;

  if (!topic ) {
    return res.status(400).json({ message: "Topic is required" });
  }

  try {
    const jokes = await facebook.generateTopicJokesGroups(topic);
    res.status(200).json({ jokes });
  } catch (error) {
    console.error("Joke generation failed:", error);
    res.status(500).json({ message: "Joke generation failed.", error: error.message });
  }
});

app.post("/api/automation/facebook/generate-jokes-group-postbased", async (req, res) => {
  const { posts} = req.body;

  if (!posts) {
    return res.status(400).json({ message: "Topic is required" });
  }

  try {
    const jokes = await facebook.generatePostJokesforGroup(posts);
    res.status(200).json({ jokes });
  } catch (error) {
    console.error("Joke generation failed:", error);
    res.status(500).json({ message: "Joke generation failed.", error: error.message });
  }
});

app.post("/api/automation/facebook/generate-jokes-post", async (req, res) => {
  const { topic} = req.body;

  if (!topic ) {
    return res.status(400).json({ message: "Topic is required" });
  }

  try {
    const jokes = await facebook.generateTopicJokesPosts(topic);
    res.status(200).json({ jokes });
  } catch (error) {
    console.error("Joke generation failed:", error);
    res.status(500).json({ message: "Joke generation failed.", error: error.message });
  }
});

app.post("/api/automation/facebook/generate-jokes-post-postbased", async (req, res) => {
  const { posts} = req.body;

  if (!posts) {
    return res.status(400).json({ message: "Topic is required" });
  }

  try {
    const jokes = await facebook.generatePostJokesforPosts(posts);
    res.status(200).json({ jokes });
  } catch (error) {
    console.error("Joke generation failed:", error);
    res.status(500).json({ message: "Joke generation failed.", error: error.message });
  }
});
/**
 * Endpoint to save jokes to a file.
 */
app.post("/api/automation/facebook/save-jokes",  async (req, res) => {
  const {  topic } = req.body;
  if (!facebook) {
    return res.status(400).json({ message: "Please log in first" });
  }
  try {
    await facebook.SaveJokeFile(topic);
    res.status(200).json({ message: `Jokes saved for "${topic}".` });
  } catch (error) {
    console.error("Saving jokes failed:", error);
    res.status(500).json({ message: "Failed to save jokes.", error: error.message });
  }
});

app.post("/api/automation/facebook/save-jokes-posts",  async (req, res) => {
  const {  posts } = req.body;
  if (!facebook) {
    return res.status(400).json({ message: "Please log in first" });
  }
  try {
    await facebook.SavePostsJokeFile(posts);
    res.status(200).json({ message: `Jokes saved for "${posts}".` });
  } catch (error) {
    console.error("Saving jokes failed:", error);
    res.status(500).json({ message: "Failed to save jokes.", error: error.message });
  }
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});

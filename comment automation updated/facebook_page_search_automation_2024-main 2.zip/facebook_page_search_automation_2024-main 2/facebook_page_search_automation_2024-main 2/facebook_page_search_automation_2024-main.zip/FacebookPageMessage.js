const { chromium, firefox, webkit } = require("playwright");
const fs = require('fs');
const path = require('path');
const { OpenAI } = require('openai');
const slugify = require('slugify');
require('dotenv').config();

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

class FacebookPageMessage {
  constructor() {
    this.browser = null;
    this.page = null;
    this.cache = {};
  }

  // Helper functions to manage caching
  loadCache() {
    const cacheFile = path.join(__dirname, 'jokes_cache.json');
    if (fs.existsSync(cacheFile)) {
      try {
        const data = fs.readFileSync(cacheFile, 'utf8');
        this.cache = JSON.parse(data);
      } catch (error) {
        console.error('Error loading cache:', error);
      }
    }
  }

  saveCache() {
    const cacheFile = path.join(__dirname, 'jokes_cache.json');
    try {
      fs.writeFileSync(cacheFile, JSON.stringify(this.cache, null, 2));
    } catch (error) {
      console.error('Error saving cache:', error);
    }
  }


  async init(browserType = "chromium") {
    switch (browserType) {
      case "chromium":
        this.browser = await chromium.launch({ headless: false });
        break;
      case "firefox":
        this.browser = await firefox.launch({ headless: false });
        break;
      case "webkit":
        this.browser = await webkit.launch({ headless: false });
        break;
      default:
        throw new Error(`Unsupported browser type: ${browserType}`);
    }

    let context;
    if (browserType === "chromium") {
      context = await this.browser.newContext({
        permissions: ["camera", "microphone"],
      });
    } else {
      context = await this.browser.newContext();
    }

    this.page = await context.newPage();
  }

  async login(email, password) {
    try {
      await this.page.goto("https://www.facebook.com/", {
        timeout: 160000,
      });
      await this.page.fill('input[name="email"]', email);
      await this.page.fill('input[name="pass"]', password);
      await this.page.click('button[name="login"]');
      await this.page.waitForNavigation({ timeout: 180000 });

      // const loginCheck = await this.page.$('div[aria-label="Your profile"]', {
      //   timeout: 180000,
      // });

      // if (!loginCheck) {
      //   throw new Error("Login failed: Incorrect email or password");
      // }
    } catch (error) {
      console.error("Error logging in:", error);
      throw new Error("Error logging in: " + error.message);
    }
  }

  async changePage(pageName) {
    try {
      await this.page.goto(`https://www.facebook.com/${pageName}`, {
        timeout: 160000,
      });
      await this.page.waitForSelector(
        'div[aria-label="Switch Now"][role="button"]',
        { visible: true, timeout: 160000 }
      );
      await this.page.click('div[aria-label="Switch Now"][role="button"]');
      await this.page.waitForNavigation({ timeout: 160000 });
    } catch (error) {
      console.error("Error switching page:", error);
      throw new Error("Error switching page: " + error.message);
    }
  }

  async selectContact(searchName) {
    try {
      await this.page.goto("https://business.facebook.com/latest/inbox/all", {
        timeout: 160000,
      });

      // Wait for the search input field and type the search name
      await this.page.waitForSelector('input[placeholder="Search"]', {
        visible: true,
        timeout: 160000,
      });
      await this.page.fill('input[placeholder="Search"]', searchName);

      await this.page.waitForTimeout(3000);

      await this.page.waitForSelector(`li:has-text("${searchName}")`, {
        visible: true,
        timeout: 160000,
      });

      await this.page.click(`li:has-text("${searchName}")`);

      await this.page.waitForTimeout(3000);

      await this.page.waitForSelector(`text=${searchName}`, {
        timeout: 160000,
      });

      const elements = await this.page.$$(`text=${searchName}`);

      // Ensure there are at least two results
      if (elements.length >= 2) {
        // Click the second result
        await elements[1].click();
      }

      console.log("User selected successfully");
    } catch (error) {
      console.error("Error selecting user:", error);
      throw new Error("Error selecting user: " + error.message);
    }
  }

  async sendMessage(message) {
    try {
      await this.page.waitForSelector(
        'textarea[placeholder="Reply in Messenger…"]',
        {
          visible: true,
          timeout: 160000,
        }
      );
      await this.page.fill(
        'textarea[placeholder="Reply in Messenger…"]',
        message
      );

      // Press 'Enter' to send the message
      await this.page.keyboard.press("Enter");

      console.log("Message sent successfully");
    } catch (error) {
      console.error("Error sending message:", error);
      throw new Error("Error sending message: " + error.message);
    }
  }

  // Search for users by username and extract their profile details
  async searchUsersByUsername(username) {
    // Navigate to Facebook search
    await this.page.goto('https://www.facebook.com/search/people?q=' + username);
    await this.page.waitForSelector('input[placeholder="Search Facebook"]', { timeout: 15000 });

    // Wait for results to load
    await this.page.waitForTimeout(5000);

    // Extract all user information (username and photoUrl)
    const users = await this.page.$$eval(
      'div[role="feed"] div[data-visualcompletion="ignore-dynamic"]',
      (elements) => {
        return elements.map((element) => {
          const displayNameElement = element.querySelector('span');
          const photoUrlElement = element.querySelector('image[height="100%"]'); // Assuming the image is 40px height, adjust selector as needed
          const profileUrlElement = element.querySelector('a'); // Profile link (username or ID in the URL)
          const usernameFromProfileUrl = profileUrlElement ? new URL(profileUrlElement.href).pathname.split('/').filter(Boolean)[0] : 'Unknown';
          const profileUrl = profileUrlElement ? profileUrlElement.href : 'No profile URL';



          // Extract userId from profileUrl if available
          const userIdMatch = profileUrl.match(/\/profile.php\?id=(\d+)/) || profileUrl.match(/\/([a-zA-Z0-9.]+)\?/);
          const userId = userIdMatch ? userIdMatch[1] : 'Unknown';
          return {
            displayname: displayNameElement ? displayNameElement.innerText : 'Unknown',
            photoUrl: photoUrlElement ? photoUrlElement.getAttribute('xlink:href') : 'No photo available',
            profileUrl: profileUrlElement ? profileUrlElement.href : 'No profile URL',
            username: usernameFromProfileUrl || 'Unknown',
            userId: userId,

          };
        });
      }
    );

    console.log('Users found:', users);
    return users;
  }

  async searchFacebookGroupUsers(groupId) {
    try {
      // Navigate to the group's members page
      await this.page.goto(`https://www.facebook.com/groups/${groupId}/members`);

      // Wait for the main content to load
      await this.page.waitForSelector('div[role="list"]', { timeout: 15000 });
      await this.page.waitForTimeout(5000); // Additional wait time to ensure the page is fully loaded

      let previousHeight = await this.page.evaluate(() => document.body.scrollHeight);
      let users = [];

      // Scroll and load more members until the page stops scrolling
      while (true) {
        // Extract member information
        const newUsers = await this.page.$$eval(
          'div.x78zum5.xdt5ytf.x1xmf6yo.x1e56ztr', // Updated selector for the member container
          (elements) => {
            return elements.map((element) => {
              // Extract display name
              const displayNameElement = element.querySelector('a[aria-label]');
              const displayName = displayNameElement ? displayNameElement.getAttribute('aria-label') : 'No display name available';

              // Extract profile URL
              const profileUrlElement = element.querySelector('a');
              const profileUrl = profileUrlElement ? profileUrlElement.href : 'No profile URL';
              const username = profileUrlElement ? new URL(profileUrlElement.href).pathname.split('/').filter(Boolean)[0] : 'Unknown';

              // Extract profile picture URL
              const photoUrlElement = element.querySelector('svg image');
              const photoUrl = photoUrlElement ? photoUrlElement.getAttribute('xlink:href') : 'No photo available';

              return {
                displayName: displayName,
                username: username,
                profileUrl: profileUrl,
                photoUrl: photoUrl,
              };
            });
          }
        );

        // Append new users to the list
        users = users.concat(newUsers);

        // Scroll to load more members
        await this.page.evaluate(() => window.scrollBy(0, document.body.scrollHeight));
        await this.page.waitForTimeout(3000); // Wait for more members to load

        // Check if scrolling has reached the bottom
        let newHeight = await this.page.evaluate(() => document.body.scrollHeight);
        if (newHeight === previousHeight) {
          break; // If height hasn't changed, we're at the bottom of the page
        }
        previousHeight = newHeight;
      }

      console.log('Group users found:', users);
      return users;
    } catch (error) {
      console.error('Error searching for group users:', error);
      throw new Error('Error searching for group users: ' + error.message);
    }
  }



  async searchFacebookPageUsers(pageName) {
    try {
      // Navigate to the page's followers section
      await this.page.goto(`https://www.facebook.com/${pageName}/followers`, {
        waitUntil: 'domcontentloaded', // Use domcontentloaded as a more reliable wait state
      });

      // Wait for the main content to load
      await this.page.waitForSelector('div[role="main"]', { timeout: 15000 });

      // Extract member information
      const users = await this.page.$$eval(
        'div[class*="x1iyjqo2"] ', // Selector for the member container
        (elements) => {
          return elements.map((element) => {
            // Extract display name
            const displayNameElement = element.querySelector('span[dir="auto"]');
            const displayName = displayNameElement ? displayNameElement.textContent : 'No display name available';


            //          // Extract profile URL
            const profileUrlElement = element.querySelector('a');
            const profileUrl = profileUrlElement ? profileUrlElement.href : 'No profile URL';

            // Extract username (if available in the profile URL)
            const username = profileUrlElement ? new URL(profileUrlElement.href).searchParams.get('id') || 'Unknown' : 'Unknown';


            // Extract profile picture URL
            const photoUrlElement = element.querySelector('img');
            const photoUrl = photoUrlElement ? photoUrlElement.src : 'No photo available';

            return {
              displayName: displayName,
              username: username,
              profileUrl: profileUrl,
              photoUrl: photoUrl,
            };
          });
        }
      );

      console.log('Page users found:', users);
      return users;
    } catch (error) {
      console.error('Error searching for page users:', error);
      throw new Error('Error searching for page users: ' + error.message);
    }
  }



  async searchFacebookHashtags(hashtag) {
    try {
      // Navigate to the hashtag page
      await this.page.goto(`https://www.facebook.com/hashtag/${encodeURIComponent(hashtag)}`);
      await this.page.waitForSelector('div[role="main"] ', { timeout: 15000 });
      await this.page.waitForTimeout(5000);

      // Extract post details
      const posts = await this.page.$$eval(
        'div[role="main"] > div>div>div>div>div>div>div>div>div', // Adjust the selector based on actual structure
        (elements) => {
          return elements.map((element) => {
            // Debugging: Log the HTML content of the element
            console.log('Element HTML:', element.innerHTML);

            // Adjust selectors based on actual structure
            const displayNameElement = element.querySelector('div>span');
            const profileUrlElement = element.querySelector('a[href*="/profile.php"]');
            const userPhotoElement = element.querySelector('svg image'); // Adjust based on actual structure

            // Extract data
            const displayName = displayNameElement ? displayNameElement.innerText : 'No name available';
            const profileUrl = profileUrlElement ? profileUrlElement.href : 'No profile link available';
            const username = profileUrlElement ? profileUrlElement.innerText : 'No username available';
            const photoUrl = userPhotoElement ? userPhotoElement.src : 'No photo available';

            return {
              displayName: displayName,
              profileUrl: profileUrl,
              username: username,
              photoUrl: photoUrl,
            };
          });
        }
      );

      console.log('Posts found:', posts);
      return posts;
    } catch (error) {
      console.error("Error searching for hashtags:", error);
      throw new Error("Error searching for hashtags: " + error.message);
    }
  }





  async generateTopicJokes(topic) {
    try {
      if (this.cache[topic]) {
        console.log('Returning cached jokes for topic:', topic);
        return this.cache[topic].topicJokes;
      }
  
      const topicPrompt = `Tell me 50 jokes related to "${topic}", each less than 20 words.`;
      const topicResponse = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [
          { role: "system", content: "You are a helpful assistant." },
          { role: "user", content: topicPrompt },
        ],
      });
  
      const topicJokes = topicResponse.choices[0].message.content.split("\n").filter(joke => joke.trim());
      this.cache[topic] = this.cache[topic] || {};
      this.cache[topic].topicJokes = topicJokes;
      this.saveCache();
  
      return topicJokes;
    } catch (error) {
      console.error("Error generating topic jokes:", error);
      return [];
    }
  }

  async generateTopicJokesLive(topic) {
    try {
      const topicPrompt = `Tell me 50 jokes related to "${topic}", each less than 20 words.`;
      const topicResponse = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [
          { role: "system", content: "You are a helpful assistant." },
          { role: "user", content: topicPrompt },
        ],
      });
  
      const topicJokes = topicResponse.choices[0].message.content.split("\n").filter(joke => joke.trim());
      this.cache[topic] = this.cache[topic] || {};
      this.cache[topic].topicJokes = topicJokes;
      // this.saveCache();
  
      return topicJokes;
    } catch (error) {
      console.error("Error generating topic jokes:", error);
      return [];
    }
  }
  
  async generateTopicJokesPosts(topic) {
    try {
      if (this.cache[topic]) {
        console.log('Returning cached jokes for topic:', topic);
        return this.cache[topic].topicJokes;
      }
  
      const topicPrompt = `Tell me 50 jokes related to "${topic}", each less than 20 words.`;
      const topicResponse = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [
          { role: "system", content: "You are a helpful assistant." },
          { role: "user", content: topicPrompt },
        ],
      });
  
      const topicJokes = topicResponse.choices[0].message.content.split("\n").filter(joke => joke.trim());
      this.cache[topic] = this.cache[topic] || {};
      this.cache[topic].topicJokes = topicJokes;
      this.saveCache();
  
      return topicJokes;
    } catch (error) {
      console.error("Error generating topic jokes:", error);
      return [];
    }
    }
  
  
  async generateTopicJokesGroups(topic) {
    try {
      if (this.cache[topic]) {
        console.log('Returning cached jokes for topic:', topic);
        return this.cache[topic].topicJokes;
      }
  
      const topicPrompt = `Tell me 50 jokes related to "${topic}", each less than 20 words.`;
      const topicResponse = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [
          { role: "system", content: "You are a helpful assistant." },
          { role: "user", content: topicPrompt },
        ],
      });
  
      const topicJokes = topicResponse.choices[0].message.content.split("\n").filter(joke => joke.trim());
      this.cache[topic] = this.cache[topic] || {};
      this.cache[topic].topicJokes = topicJokes;
      this.saveCache();
  
      return topicJokes;
    } catch (error) {
      console.error("Error generating topic jokes:", error);
      return [];
    }
  }

  async generatePostJokesforLive(hashtag) {
    try {
      // Fetch posts based on hashtag
      const { userComments } = await this.searchFacebookLiveUsers(hashtag);
  
      if (!Array.isArray(userComments)) {
        throw new Error("Expected an array of posts but got something else.");
      }
  
      const postJokes = [];
      const limitedPosts = userComments.slice(0, 20); // Limit to the first 20 posts
  
      for (const post of limitedPosts) {
        const postContent = `
          Title: ${post.title} 
          Description: ${post.description}
          Comments: ${post.comments.map(comment => comment.commentText).join(" ")}
        `;
        const postPrompt = `Generate 25 jokes related to the following post content: "${postContent}"`;
  
        try {
          const postResponse = await openai.chat.completions.create({
            model: "gpt-3.5-turbo",
            messages: [
              { role: "system", content: "You are a humorous assistant." },
              { role: "user", content: postPrompt },
            ],
          });
  
          const postSpecificJokes = postResponse.choices[0].message.content
            .split("\n")
            .filter(joke => joke.trim());
          postJokes.push({  jokes: postSpecificJokes });
        } catch (error) {
          console.error(`Error generating jokes for post: ${post.title}`);
          postJokes.push({ jokes: [] });
        }
      }
  
      // Save jokes to a JSON file
      // this.SavePostsJokeFile(hashtag, postJokes);
  
      return postJokes;
    } catch (error) {
      console.error("Error generating post jokes:", error);
      return [];
    }
  }


  async generatePostJokesforPosts(hashtag) {
    try {
      // Fetch posts based on hashtag
      const { userComments } = await this.searchFacebookPostsUsers(hashtag);
  
      if (!Array.isArray(userComments)) {
        throw new Error("Expected an array of posts but got something else.");
      }
  
      const postJokes = [];
      const limitedPosts = userComments.slice(0, 20); // Limit to the first 20 posts
  
      for (const post of limitedPosts) {
        const postContent = `
          Title: ${post.title} 
          Description: ${post.description}
          Comments: ${post.comments.map(comment => comment.commentText).join(" ")}
        `;
        const postPrompt = `Generate 25 jokes related to the following post content: "${postContent}"`;
  
        try {
          const postResponse = await openai.chat.completions.create({
            model: "gpt-3.5-turbo",
            messages: [
              { role: "system", content: "You are a humorous assistant." },
              { role: "user", content: postPrompt },
            ],
          });
  
          const postSpecificJokes = postResponse.choices[0].message.content
            .split("\n")
            .filter(joke => joke.trim());
          postJokes.push({  jokes: postSpecificJokes });
        } catch (error) {
          console.error(`Error generating jokes for post: ${post.title}`);
          postJokes.push({ jokes: [] });
        }
      }
  
      // Save jokes to a JSON file
      // this.SavePostsJokeFile(hashtag, postJokes);
  
      return postJokes;
    } catch (error) {
      console.error("Error generating post jokes:", error);
      return [];
    }
  }
  

  async generatePostJokesforPages(hashtag) {
    try {
      // Fetch posts based on hashtag
      const { userComments } = await this.searchFacebookPages(hashtag);
  
      if (!Array.isArray(userComments)) {
        throw new Error("Expected an array of posts but got something else.");
      }
  
      const postJokes = [];
      const limitedPosts = userComments.slice(0, 20); // Limit to the first 20 posts
  
      for (const post of limitedPosts) {
        const postContent = `
          Title: ${post.title} 
          Description: ${post.description}
          Comments: ${post.comments.map(comment => comment.commentText).join(" ")}
        `;
        const postPrompt = `Generate 25 jokes related to the following post content: "${postContent}"`;
  
        try {
          const postResponse = await openai.chat.completions.create({
            model: "gpt-3.5-turbo",
            messages: [
              { role: "system", content: "You are a humorous assistant." },
              { role: "user", content: postPrompt },
            ],
          });
  
          const postSpecificJokes = postResponse.choices[0].message.content
            .split("\n")
            .filter(joke => joke.trim());
          postJokes.push({  jokes: postSpecificJokes });
        } catch (error) {
          console.error(`Error generating jokes for post: ${post.title}`);
          postJokes.push({ jokes: [] });
        }
      }
  
      // Save jokes to a JSON file
      // this.SavePostsJokeFile(hashtag, postJokes);
  
      return postJokes;
    } catch (error) {
      console.error("Error generating post jokes:", error);
      return [];
    }
  }

  async generatePostJokesforGroup(hashtag) {
    try {
      // Fetch posts based on hashtag
      const { userComments } = await this.searchFacebookGroups(hashtag);
  
      if (!Array.isArray(userComments)) {
        throw new Error("Expected an array of posts but got something else.");
      }
  
      const postJokes = [];
      const limitedPosts = userComments.slice(0, 20); // Limit to the first 20 posts
  
      for (const post of limitedPosts) {
        const postContent = `
          Title: ${post.title} 
          Description: ${post.description}
          Comments: ${post.comments.map(comment => comment.commentText).join(" ")}
        `;
        const postPrompt = `Generate 25 jokes related to the following post content: "${postContent}"`;
  
        try {
          const postResponse = await openai.chat.completions.create({
            model: "gpt-3.5-turbo",
            messages: [
              { role: "system", content: "You are a humorous assistant." },
              { role: "user", content: postPrompt },
            ],
          });
  
          const postSpecificJokes = postResponse.choices[0].message.content
            .split("\n")
            .filter(joke => joke.trim());
          postJokes.push({  jokes: postSpecificJokes });
        } catch (error) {
          console.error(`Error generating jokes for post: ${post.title}`);
          postJokes.push({ jokes: [] });
        }
      }
  
      // Save jokes to a JSON file
      // this.SavePostsJokeFile(hashtag, postJokes);
  
      return postJokes;
    } catch (error) {
      console.error("Error generating post jokes:", error);
      return [];
    }
  }
  shuffleArray(array) {
      for (let i = array.length - 1; i > 0; i--) {
          const j = Math.floor(Math.random() * (i + 1));
          [array[i], array[j]] = [array[j], array[i]]; // Swap elements
      }
      return array;
  }
  async JokesFile(topic, shuffledTopicJokes) {
    try {
        const jokesFilePath = path.join(__dirname, `${slugify(topic)}_topic_jokes.json`);
        const jokesData = {
            topicJokes: shuffledTopicJokes,
        };

        fs.writeFileSync(jokesFilePath, JSON.stringify(jokesData, null, 2));
        console.log(`Topic jokes saved to ${jokesFilePath}`);
    } catch (error) {
        console.error("Error saving topic jokes to file:", error);
    }
}

async SaveJokeFile(topic) {
    try {
        const topicJokes = await this.generateTopicJokes(topic);
        if (!topicJokes || topicJokes.length === 0) {
            console.log("No topic jokes generated.");
            return;
        }

        // Save the generated jokes to cache
        this.cache[topic] = { topicJokes };
        this.saveCache();

        const shuffledTopicJokes = this.shuffleArray(topicJokes); // Shuffle the topic jokes
        await this.JokesFile(topic, shuffledTopicJokes);
    } catch (error) {
        console.error("Error in SaveJokeFile:", error.message);
    }
}


async SavePostsJokeFile(hashtag,shuffledPostJokes) {
  try {
    const jokesFilePath = path.join(__dirname, `${hashtag}_posts_jokes.json`);
    fs.writeFileSync(jokesFilePath, JSON.stringify(shuffledPostJokes, null, 2));
    console.log(`Jokes for hashtag "${hashtag}" saved to ${jokesFilePath}`);
  } catch (error) {
    console.error("Error saving jokes to file:", error);
  }
}



  /**
  * Post a comment on a Rumble post.
  * @param {string} postUrl - The URL of the post.
  * @param {string} joke - The joke to post.
  * @param {string} username - The username to tag in the comment.
  */
  async postComment(profileUrl, joke, username) {
    try {
      await this.page.goto(profileUrl, { timeout: 60000 });
      // Wait for the comment box to be visible
      await this.page.waitForSelector('div[contenteditable="true"]');

      // Focus the comment box and type the comment
      await this.page.focus('div[contenteditable="true"]');
      await this.page.fill('div[contenteditable="true"]', `${joke} @${username} #beladed`);
      // Wait for the Post button to appear
      await this.page.waitForSelector('div[aria-label="Comment"]');

      // Click the Post button
      await this.page.click('div[aria-label="Comment"]');

      console.log(`Comment posted successfully on ${profileUrl}: "${joke}"`);
    } catch (error) {
      console.error(`Failed to post comment on ${profileUrl}:`, error.message);
    }
  }

  async postCommentForPost(postUrl, joke, username) {
    try {
      await this.page.goto(postUrl, { timeout: 60000 });
      // Wait for the comment box to be visible
      await this.page.waitForSelector('div[contenteditable="true"]');

      // Focus the comment box and type the comment
      await this.page.focus('div[contenteditable="true"]');
      await this.page.fill('div[contenteditable="true"]', `${joke} @${username} #beladed`);
      // Wait for the Post button to appear
      await this.page.waitForSelector('div[aria-label="Comment"]');

      // Click the Post button
      await this.page.click('div[aria-label="Comment"]');

      console.log(`Comment posted successfully on ${postUrl}: "${joke}"`);
    } catch (error) {
      console.error(`Failed to post comment on ${postUrl}:`, error.message);
    }
  }


  // Search for Facebook Pages by name and extract their details
  async searchFacebookPages(pageName) {
    try {
      // Navigate to Facebook search for pages
      await this.page.goto(`https://www.facebook.com/search/pages?q=${pageName}`);
      await this.page.waitForSelector('input[placeholder="Search Facebook"]', { timeout: 15000 });

      // Wait for results to load
      await this.page.waitForTimeout(5000);

      // Extract page details such as name, username, profile URL, photo URL, and user ID
      const pages = await this.page.$$eval(
        'div[role="feed"] div[data-visualcompletion="ignore-dynamic"]',
        (elements) => {
          return elements.map((element) => {
            const pageNameElement = element.querySelector('span');
            const profileUrlElement = element.querySelector('a'); // Profile link (Page URL)
            const photoUrlElement = element.querySelector('image[height="100%"]'); // Profile picture (adjust the selector as needed)

            // Extract the page username from the profile URL (e.g., "/pagename")
            const profileUrl = profileUrlElement ? profileUrlElement.href : 'No profile URL';
            const pageUsername = profileUrlElement ? new URL(profileUrlElement.href).pathname.split('/').filter(Boolean)[0] : 'Unknown';

            // Extract pageName and photoUrl
            const pageName = pageNameElement ? pageNameElement.innerText : 'Unknown';
            const photoUrl = photoUrlElement ? photoUrlElement.getAttribute('xlink:href') : 'No photo available';
            const descriptionElement = element.querySelector('span[class*="x1lliihq"]'); // Description (adjust selector if needed)
            const description = descriptionElement ? descriptionElement.innerText : 'No description available';

            return {
              pageName: pageName,
              pageUsername: pageUsername,
              profileUrl: profileUrl,
              photoUrl: photoUrl,
              description:description,
              title:description
              // userId: userId,
            };
          });
        }
      );
      // Extract comments for each video
      const userComments = [];
      for (const user of pages) {
        if (user.profileUrl) {
          console.log(`Navigating to video page: ${user.profileUrl}`);
          await this.page.goto(user.profileUrl);

          // Wait for comments to load (handling potential delays)
          try {
            // Wait for the comments section to load
            await this.page.waitForSelector('div[role="button"][tabindex="0"]', { timeout: 15000 });
            // Click the "See more" button to expand the comment
            await this.page.click('div[role="button"][tabindex="0"]');
            await this.page.waitForSelector('div[dir="auto"]', { timeout: 70000 });
          } catch (e) {
            console.log(`Comments not visible for post: ${user.profileUrl}. Skipping.`);
            continue;
          }

          // Extract the comments
          const comments = await this.page.$$eval('div[dir="auto"]', (commentNodes) => {
            return commentNodes.map(commentNode => {
              const commentText = commentNode.querySelector('div[dir="auto"]')?.innerText.trim() || 'No text';
              return { commentText };
            });
          });

          userComments.push({
            ...user,
            comments
          });

          console.log(`Extracted ${comments.length} comments from video: ${user.profileUrl}`);
        }
      }

      console.log("Comments extraction complete.");
      return { userComments };


    } catch (error) {
      console.error("Error searching for pages:", error);
      throw new Error("Error searching for pages: " + error.message);
    }
  }
  /**
  * Automate commenting on posts based on a hashtag.
  * @param {string} hashtag - The hashtag to search and comment on.
  */
  async automateCommentingPage(pageName) {
    try {
      // Step 1: Search for posts using the provided hashtag
      const { userComments } = await this.searchFacebookPages(pageName);
      
      if (userComments.length === 0) {
        console.log('No posts found with the provided hashtag.');
        return;
      }
  
      // Step 2: Generate jokes for the posts
      const postJokes = await this.generatePostJokesforPages(pageName);
      if (postJokes.length === 0) {
        console.log('No jokes generated for the posts.');
        return;
      }
  
      // Step 3: Shuffle the jokes for randomness
      const shuffledPostJokes = this.shuffleArray(postJokes);
  
      // Step 4: Iterate over posts to post comments
      for (let i = 0; i < userComments.length; i++) {
        const post = userComments[i];
  
        // Ensure videoUrl exists
        if (!post.profileUrl) {
          console.error(`Error: videoUrl is undefined or invalid for post: ${post.title}`);
          continue;  // Skip this post
        }
  
        // Step 4: Select one joke from the shuffled list
        const joke = shuffledPostJokes[i]?.jokes[0] || "Here's a funny joke!"; // Choose the first joke after shuffling
        
        // Post the comment to the video
        await this.postComment(post.profileUrl, joke, post.username);
  
        console.log(`Comment posted: "${joke}" on ${post.profileUrl}`);
      }
  
      console.log("Automated commenting completed for all search results.");
    } catch (error) {
      console.error("Error during automated commenting:", error.message);
    }
  }


  // Method to search for Facebook Groups by name and extract details
  async searchFacebookGroups(groupName) {
    try {
      // Navigate to Facebook search for groups
      await this.page.goto(`https://www.facebook.com/search/groups?q=${groupName}`);
      await this.page.waitForSelector('input[placeholder="Search Facebook"]', { timeout: 60000 });

      // Wait for results to load
      await this.page.waitForTimeout(5000);

      // Extract group details such as name, username, profile URL, photo URL, and user ID
      const groups = await this.page.$$eval(
        'div[role="feed"] div[data-visualcompletion="ignore-dynamic"]',
        (elements) => {
          return elements.map((element) => {
            const groupNameElement = element.querySelector('span');
            const profileUrlElement = element.querySelector('a'); // Group profile link (URL)
            const photoUrlElement = element.querySelector('image[height="100%"]'); // Profile picture (adjust selector as needed)

            // Extract the group username from the profile URL (e.g., "/groupname")
            const profileUrl = profileUrlElement ? profileUrlElement.href : 'No profile URL';
            const groupUsername = profileUrlElement ? new URL(profileUrlElement.href).pathname.split('/').filter(Boolean)[0] : 'Unknown';

            // Extract userId if it's available from the URL (often in the format "/profile.php?id=...")
            // const userIdMatch = profileUrl.match(/\/profile.php\?id=(\d+)/) || profileUrl.match(/\/([a-zA-Z0-9.]+)\?/);
            // const userId = userIdMatch ? userIdMatch[1] : 'Unknown';

            // Extract groupName and photoUrl
            const groupName = groupNameElement ? groupNameElement.innerText : 'Unknown';
            const photoUrl = photoUrlElement ? photoUrlElement.getAttribute('xlink:href') : 'No photo available';
            const descriptionElement = element.querySelector('span[class*="x1lliihq"]'); // Description (adjust selector if needed)
            const description = descriptionElement ? descriptionElement.innerText : 'No description available';

            return {
              groupName: groupName,
              groupUsername: groupUsername,
              profileUrl: profileUrl,
              photoUrl: photoUrl,
              description:description,
              title:description
              // userId: userId,
            };
          });
        }
      );
        // Extract comments for each video
        const userComments = [];
        for (const user of groups) {
          if (user.profileUrl) {
            console.log(`Navigating to video page: ${user.profileUrl}`);
            await this.page.goto(user.profileUrl);
  
            // Wait for comments to load (handling potential delays)
            try {
              // Wait for the comments section to load
              await this.page.waitForSelector('div[role="button"][tabindex="0"]', { timeout: 60000 });
              // Click the "See more" button to expand the comment
              await this.page.click('div[role="button"][tabindex="0"]');
              await this.page.waitForSelector('div[dir="auto"]', { timeout: 70000 });
            } catch (e) {
              console.log(`Comments not visible for post: ${user.profileUrl}. Skipping.`);
              continue;
            }
  
            // Extract the comments
            const comments = await this.page.$$eval('div[dir="auto"]', (commentNodes) => {
              return commentNodes.map(commentNode => {
                const commentText = commentNode.querySelector('div[dir="auto"]')?.innerText.trim() || 'No text';
                return { commentText };
              });
            });
  
            userComments.push({
              ...user,
              comments
            });
  
            console.log(`Extracted ${comments.length} comments from video: ${user.profileUrl}`);
          }
        }
  
        console.log("Comments extraction complete.");
        return { userComments };

      // console.log('Facebook Groups found:', groups);
      // return groups;
    } catch (error) {
      console.error("Error searching for groups:", error);
      throw new Error("Error searching for groups: " + error.message);
    }
  }

  /**
 * Automate commenting on posts based on a hashtag.
 * @param {string} hashtag - The hashtag to search and comment on.
 */
  async automateCommentingGroup(groupName) {
    try {
      // Step 1: Search for posts using the provided hashtag
      const { userComments } = await this.searchFacebookGroups(groupName);
      
      if (userComments.length === 0) {
        console.log('No posts found with the provided hashtag.');
        return;
      }
  
      // Step 2: Generate jokes for the posts
      const postJokes = await this.generatePostJokesforGroup(groupName);
      if (postJokes.length === 0) {
        console.log('No jokes generated for the posts.');
        return;
      }
  
      // Step 3: Shuffle the jokes for randomness
      const shuffledPostJokes = this.shuffleArray(postJokes);
  
      // Step 4: Iterate over posts to post comments
      for (let i = 0; i < userComments.length; i++) {
        const post = userComments[i];
  
        // Ensure videoUrl exists
        if (!post.profileUrl) {
          console.error(`Error: videoUrl is undefined or invalid for post: ${post.title}`);
          continue;  // Skip this post
        }
  
        // Step 4: Select one joke from the shuffled list
        const joke = shuffledPostJokes[i]?.jokes[0] || "Here's a funny joke!"; // Choose the first joke after shuffling
        
        // Post the comment to the video
        await this.postComment(post.profileUrl, joke, post.username);
  
        console.log(`Comment posted: "${joke}" on ${post.profileUrl}`);
      }
  
      console.log("Automated commenting completed for all search results.");
    } catch (error) {
      console.error("Error during automated commenting:", error.message);
    }
  }


  // Function to search Facebook Live users by name and extract details
  async searchFacebookLiveUsers(userName) {
    try {
      // Navigate to the general Facebook search page
      await this.page.goto(`https://www.facebook.com/search/top?q=${encodeURIComponent(userName)}`, { waitUntil: 'networkidle' });
      // Wait for the search input to confirm page load
      await this.page.waitForSelector('input[placeholder="Search Facebook"]', { timeout: 15000 });

      // Allow time for results to load
      await this.page.waitForTimeout(5000);

      // Extract live user details such as group name, group username, profile URL, photo URL, and user ID
      const liveUsers = await this.page.$$eval(
        'div[role="feed"]', // Adjusted selector to target feed
        (elements) => {
          return elements.map((element) => {
            const groupNameElement = element.querySelector('span.html-span'); // Group or live user name
            const profileUrlElement = element.querySelector('a[href*="/profile.php"], a[href*="/"]'); // Profile link (URL)
            const photoUrlElement = element.querySelector('image'); // Profile picture (adjusted selector)

            // Extract the group username from the profile URL (e.g., "/groupname")
            const profileUrl = profileUrlElement ? profileUrlElement.href : 'No profile URL';
            const groupUsername = profileUrlElement ? new URL(profileUrlElement.href).pathname.split('/').filter(Boolean)[0] : 'Unknown';

            // Extract userId from the profile URL if available (commonly "/profile.php?id=..."), otherwise, get the username
            const userIdMatch = profileUrl.match(/\/profile.php\?id=(\d+)/) || profileUrl.match(/\/([a-zA-Z0-9.]+)\?/);
            const userId = userIdMatch ? userIdMatch[1] : 'Unknown';

            // Extract groupName and photoUrl
            const groupName = groupNameElement ? groupNameElement.innerText : 'Unknown';
            const photoUrl = photoUrlElement ? photoUrlElement.getAttribute('xlink:href') : 'No photo available';
            const descriptionElement = element.querySelector('span[class*="x1lliihq"]'); // Description (adjust selector if needed)
            const description = descriptionElement ? descriptionElement.innerText : 'No description available';

            return {
              groupName: groupName,
              groupUsername: groupUsername,
              profileUrl: profileUrl,
              photoUrl: photoUrl,
              userId: userId,
              description:description,
              title:description
            };
          });
        }
      );
      // Extract comments for each video
      const userComments = [];
      for (const user of liveUsers) {
        if (user.profileUrl) {
          console.log(`Navigating to video page: ${user.profileUrl}`);
          await this.page.goto(user.profileUrl);

          // Wait for comments to load (handling potential delays)
          try {
            // Wait for the comments section to load
            await this.page.waitForSelector('div[role="button"][tabindex="0"]', { timeout: 15000 });
            // Click the "See more" button to expand the comment
            await this.page.click('div[role="button"][tabindex="0"]');
            await this.page.waitForSelector('div[dir="auto"]', { timeout: 70000 });
          } catch (e) {
            console.log(`Comments not visible for post: ${user.profileUrl}. Skipping.`);
            continue;
          }

          // Extract the comments
          const comments = await this.page.$$eval('div[dir="auto"]', (commentNodes) => {
            return commentNodes.map(commentNode => {
              const commentText = commentNode.querySelector('div[dir="auto"]')?.innerText.trim() || 'No text';
              return { commentText };
            });
          });

          userComments.push({
            ...user,
            comments
          });

          console.log(`Extracted ${comments.length} comments from video: ${user.profileUrl}`);
        }
      }

      console.log("Comments extraction complete.");
      return { userComments };


      // console.log('Facebook Live users found:', liveUsers);
      // return liveUsers;
    } catch (error) {
      console.error("Error searching for live users:", error);
      throw new Error("Error searching for live users: " + error.message);
    }
  }

  /**
   * Automate commenting on posts based on a hashtag.
   * @param {string} hashtag - The hashtag to search and comment on.
   */
  async automateCommentingLive(userName) {
    try {
      // Step 1: Search for posts using the provided hashtag
      const { userComments } = await this.searchFacebookLiveUsers(userName);
      
      if (userComments.length === 0) {
        console.log('No posts found with the provided hashtag.');
        return;
      }
  
      // Step 2: Generate jokes for the posts
      const postJokes = await this.generatePostJokesforLive(userName);
      if (postJokes.length === 0) {
        console.log('No jokes generated for the posts.');
        return;
      }
  
      // Step 3: Shuffle the jokes for randomness
      const shuffledPostJokes = this.shuffleArray(postJokes);
  
      // Step 4: Iterate over posts to post comments
      for (let i = 0; i < userComments.length; i++) {
        const post = userComments[i];
  
        // Ensure profileUrl exists
        if (!post.profileUrl) {
          console.error(`Error: videoUrl is undefined or invalid for post: ${post.title}`);
          continue;  // Skip this post
        }
  
        // Step 4: Select one joke from the shuffled list
        const joke = shuffledPostJokes[i]?.jokes[0] || "Here's a funny joke!"; // Choose the first joke after shuffling
        
        // Post the comment to the video
        await this.postComment(post.profileUrl, joke, post.username);
  
        console.log(`Comment posted: "${joke}" on ${post.profileUrl}`);
      }
  
      console.log("Automated commenting completed for all search results.");
    } catch (error) {
      console.error("Error during automated commenting:", error.message);
    }
  }

  // Updated method to search Facebook posts and extract comments
async searchFacebookPostsUsers(postKeyword) {
  try {
    // Navigate to Facebook's post search page with the provided keyword
    await this.page.goto(`https://www.facebook.com/search/posts?q=${encodeURIComponent(postKeyword)}`, { waitUntil: 'networkidle' });

    // Wait for the search results to load
    await this.page.waitForSelector('input[placeholder="Search Facebook"]', { timeout: 70000 });

    let posts = [];
    let previousHeight = 0;

    // Infinite scrolling to load all the posts
    while (true) {
      // Extract post details
      const newPosts = await this.page.$$eval(
        'div[role="feed"] > div',
        (elements) => {
          return elements.map((element) => {
            const postNameElement = element.querySelector('span > a > span');
            const profileUrlElement = element.querySelector('a[href*="/profile.php"], a[href*="/"]');
            const photoUrlElement = element.querySelector('image');
            const postUsernameElement = element.querySelector('span > span > a > span');
            const postUrlElement = element.querySelector('a[class*="x1i10hfl"]');
            const titleElement = element.querySelector('div[dir="auto"]');
            const descriptionElement = element.querySelector('div[class*="x11i5rnm"]');

            return {
              postName: postNameElement ? postNameElement.innerText : 'Unknown',
              postUsername: postUsernameElement ? postUsernameElement.innerText : 'Unknown',
              profileUrl: profileUrlElement ? profileUrlElement.href : 'No profile URL',
              photoUrl: photoUrlElement ? photoUrlElement.getAttribute('xlink:href') : 'No photo available',
              postUrl: postUrlElement ? postUrlElement.href : 'No post URL available',
              title: titleElement ? titleElement.innerText : 'No title',
              description: descriptionElement ? descriptionElement.innerText : 'No description'
            };
          });
        }
      );

      // Add the newly fetched posts to the main list
      posts = posts.concat(newPosts);

      // Scroll down to load more results
      await this.page.evaluate(() => {
        window.scrollBy(0, window.innerHeight);
      });

      // Wait for additional content to load
      await this.page.waitForTimeout(3000);

      // Check if we've reached the bottom of the page
      const currentHeight = await this.page.evaluate('document.body.scrollHeight');
      if (currentHeight === previousHeight) {
        break; // No more content to load
      }
      previousHeight = currentHeight;
    }

    // Extract comments for each post
    const userComments = [];
    for (const user of posts) {
      if (user.postUrl) {
        console.log(`Navigating to post page: ${user.postUrl}`);
        await this.page.goto(user.postUrl);

        try {
          // Wait for the comments section to load
          await this.page.waitForSelector('div[role="button"][tabindex="0"]', { timeout: 700000 });
          await this.page.click('div[role="button"][tabindex="0"]');
          await this.page.waitForSelector('div[dir="auto"]', { timeout: 70000 });
        } catch (e) {
          console.log(`Comments not visible for post: ${user.postUrl}. Skipping.`);
          continue;
        }

        // Extract the comments
        const comments = await this.page.$$eval('div[dir="auto"]', (commentNodes) => {
          return commentNodes.map(commentNode => {
            const commentText = commentNode.innerText.trim() || 'No text';
            return { commentText };
          });
        });

        userComments.push({
          ...user,
          comments
        });

        console.log(`Extracted ${comments.length} comments from post: ${user.postUrl}`);
      }
    }

    console.log("Comments extraction complete.");
    return { userComments };
  } catch (error) {
    console.error("Error searching for post users:", error.message);
    throw new Error("Error searching for post users: " + error.message);
  }
}

  /**
    * Automate commenting on posts based on a hashtag.
    * @param {string} hashtag - The hashtag to search and comment on.
    */
  async automateCommentingPost(postKeyword) {
    try {
      // Step 1: Search for posts using the provided hashtag
      const { userComments } = await this.searchFacebookPostsUsers(postKeyword);
      
      if (userComments.length === 0) {
        console.log('No posts found with the provided hashtag.');
        return;
      }
  
      // Step 2: Generate jokes for the posts
      const postJokes = await this.generatePostJokesforPages(postKeyword);
      if (postJokes.length === 0) {
        console.log('No jokes generated for the posts.');
        return;
      }
  
      // Step 3: Shuffle the jokes for randomness
      const shuffledPostJokes = this.shuffleArray(postJokes);
  
      // Step 4: Iterate over posts to post comments
      for (let i = 0; i < userComments.length; i++) {
        const post = userComments[i];
  
        // Ensure videoUrl exists
        if (!post.postUrl) {
          console.error(`Error: videoUrl is undefined or invalid for post: ${post.title}`);
          continue;  // Skip this post
        }
  
        // Step 4: Select one joke from the shuffled list
        const joke = shuffledPostJokes[i]?.jokes[0] || "Here's a funny joke!"; // Choose the first joke after shuffling
        
        // Post the comment to the video
        await this.postCommentForPost(post.postUrl, joke, post.username);
  
        console.log(`Comment posted: "${joke}" on ${post.postUrl}`);
      }
  
      console.log("Automated commenting completed for all search results.");
    } catch (error) {
      console.error("Error during automated commenting:", error.message);
    }
  }

  async close() {
    await this.browser.close();
  }
}

module.exports = FacebookPageMessage;

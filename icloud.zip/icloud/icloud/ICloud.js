const { chromium } = require('playwright');

class iCloud {
    constructor() {
        this.browser = null;
        this.page = null;
    }

    async init() {
        this.browser = await chromium.launch({ headless: false });
        const context = await this.browser.newContext();
        this.page = await context.newPage();
    }

    async customClick(query) {
        return await this.page.evaluate((selector) => {
            const element = document.querySelector(selector);
            if (element) {
                try {
                    const event = new MouseEvent("click", {
                        bubbles: true,
                        cancelable: true,
                        view: window
                    });
                    element.dispatchEvent(event);
                    return true;
                } catch (e) {
                    console.error("Custom click failed:", e);
                    return false;
                }
            }
            return false;
        }, query);
    }
    async customFill(selector, value) {
        return await this.page.evaluate(({ selector, value }) => {
            const element = document.querySelector(selector);
            if (element) {
                element.value = value;
    
                // Trigger necessary events
                element.dispatchEvent(new Event('input', { bubbles: true }));
                element.dispatchEvent(new Event('change', { bubbles: true }));
    
                return true; // Indicate that the fill was successful
            }
            return false; // Indicate failure if element not found
        }, { selector, value });
    }

    async login(email, password) {
        
        try {
            // Navigate to iCloud login page
            await this.page.goto('https://www.icloud.com/');

            // Wait for the "Sign In" button and use customClick
            await this.page.waitForSelector('text=Sign In');
            await this.page.click('text=Sign In');

            // Wait for and fill in the Apple ID
            await this.page.waitForSelector('input[aria-labelledby="apple_id_field_label"]', { timeout: 60000 });
            await this.customFill('input[aria-labelledby="apple_id_field_label"]', email);

            // Press Enter to submit Apple ID
            await this.page.press('input[aria-labelledby="apple_id_field_label"]', 'Enter');

            // Wait for the password field, then fill it in
            await this.page.waitForSelector('input[type="password"]', { timeout: 60000 });
            await this.customFill('input[type="password"]', password);

            // Press Enter to submit the password
            await this.page.press('input[type="password"]', 'Enter');

            // Handle Two-Factor Authentication (2FA) if required
            // Note: Add logic for handling 2FA if needed

            // Wait for Mail app icon to load
            await this.page.waitForNavigation();
            await this.page.waitForSelector('text=Mail', { timeout: 60000 });
            await this.customClick('text=Mail');

            // Wait for Mail to fully load
            await this.page.waitForSelector('.mailbox-list', { timeout: 60000 });
            console.log('Successfully logged in to iCloud Mail!');
        } catch (error) {
            console.error('Failed to log in:', error);
        }
    }


    async enterOTP(otp) {
        if (!this.page) throw new Error('Login required before entering OTP');
        await this.page.waitForSelector('input[type="tel"]');
        await this.page.fill('input[type="tel"]', otp);
        await this.page.click('button[type="submit"]');
        await this.page.waitForLoadState('networkidle');
    }

    async searchHashtagInInbox(hashtag) {
        await this.page.goto('https://www.icloud.com/mail/');
        await this.page.waitForSelector('ui-autocomplete-token-field');
        await this.page.fill('ui-autocomplete-token-field', hashtag);
        await this.page.press('Enter');

        await this.page.waitForSelector('.thread-list-actual');

        const emailDetails = await this.page.evaluate(() => {
            return Array.from(document.querySelectorAll('.thread-list-item')).map(item => {
                const subjectElement = item.querySelector('.thread-subject span');
                const previewElement = item.querySelector('.thread-preview span');
                const timestampElement = item.querySelector('.thread-timestamp');
                const participantsElement = item.querySelector('.thread-participants');

                return {
                    subject: subjectElement ? subjectElement.textContent.trim() : null,
                    title: previewElement ? previewElement.textContent.trim() : null,
                    date: timestampElement ? timestampElement.textContent.trim() : null,
                    emailId: participantsElement ? participantsElement.textContent.trim() : null
                };
            });
        });
        const analytics = this.analyzeInboxEmails(emailDetails);
        return {
            ...emailDetails,
            success: true,
            emails: emailDetails.length > 0 ? emailDetails : [],
            totalInboxEmails: emailDetails.length,
            analytics,
            
        };
    }

    async searchHashtagInSent(hashtag) {
        await this.page.goto('https://www.icloud.com/mail/');
        await this.page.waitForSelector('li[aria-label="Sent"]');
        await this.page.click('li[aria-label="Sent"]');
        await this.page.waitForSelector('ui-autocomplete-token-field');

        await this.page.fill('ui-autocomplete-token-field', hashtag);
        await this.page.press('Enter');
        await this.page.waitForSelector('.thread-list');

        const emailDetails = await this.page.evaluate(() => {
            return Array.from(document.querySelectorAll('.thread-list-item')).map(item => {
                const subjectElement = item.querySelector('.thread-subject span');
                const previewElement = item.querySelector('.thread-preview span');
                const timestampElement = item.querySelector('.thread-timestamp');
                const participantsElement = item.querySelector('.thread-participants');

                return {
                    subject: subjectElement ? subjectElement.textContent.trim() : null,
                    title: previewElement ? previewElement.textContent.trim() : null,
                    date: timestampElement ? timestampElement.textContent.trim() : null,
                    emailId: participantsElement ? participantsElement.textContent.trim() : null
                };
            });
        });

        const analytics = this.analyzeSentEmails(emailDetails);
        return {
            ...emailDetails,
            success: true,
            emails: emailDetails.length > 0 ? emailDetails : [],
            totalSentEmails: emailDetails.length,
            analytics,
            
        };
    }

    analyzeSentEmails(emails) {
        const stats = {
          perDay: 0,
          perWeek: 0,
          perMonth: 0,
          topSenders: {},
          
        };
      
        const now = new Date();
      
        emails.forEach(email => {
          if (email.date) {
            const diffTime = Math.abs(now - email.date);
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      
            if (diffDays <= 1) stats.perDay++;
            if (diffDays <= 7) stats.perWeek++;
            if (diffDays <= 30) stats.perMonth++;
      
            // Count top senders and recipients
            if (email.sender) stats.topSenders[email.sender] = (stats.topSenders[email.sender] || 0) + 1;
          }
        });
      
        // Sort top senders and recipients by frequency
        stats.topSenders = Object.entries(stats.topSenders)
          .sort((a, b) => b[1] - a[1])
          .slice(0, 5); // Top 5 senders
     
        return stats;
      }
      
      analyzeInboxEmails(emails) {
        const stats = {
          perDay: 0,
          perWeek: 0,
          perMonth: 0,
          topRecipients: {},
        };
      
        const now = new Date();
      
        emails.forEach(email => {
          if (email.date) {
            const diffTime = Math.abs(now - email.date);
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      
            if (diffDays <= 1) stats.perDay++;
            if (diffDays <= 7) stats.perWeek++;
            if (diffDays <= 30) stats.perMonth++;
      
           
            if (email.emailid) stats.topRecipients[email.emailid] = (stats.topRecipients[email.emailid] || 0) + 1;
          }
        });
      
      
        stats.topRecipients = Object.entries(stats.topRecipients)
          .sort((a, b) => b[1] - a[1])
          .slice(0, 5); // Top 5 recipients
      
        return stats;
      }
      
    async generateEmail(to, subject, body) {
        try {
            await this.page.goto('https://www.icloud.com/mail/');
            await this.page.waitForSelector('button[aria-label="Compose"]');
            await this.page.click('button[aria-label="Compose"]');

            // Fill in the recipient email
            await this.page.waitForSelector('input[aria-label="To"]');
            await this.customFill('input[aria-label="To"]', to);

            // Fill in the subject
            await this.page.waitForSelector('input[aria-label="Subject"]');
            await this.customFill('input[aria-label="Subject"]', subject);

            // Fill in the email body
            await this.page.waitForSelector('.editable[aria-label="Message Body"]');
            await this.page.type('.editable[aria-label="Message Body"]', body);

            console.log('Email draft created successfully.');
        } catch (error) {
            console.error('Failed to generate email:', error);
        }
    }

    async sendEmail() {
        try {
            await this.page.waitForSelector('button[aria-label="Send"]');
            await this.page.click('button[aria-label="Send"]');
            await this.page.waitForTimeout(3000); // Give time for sending to complete

            console.log('Email sent successfully.');
        } catch (error) {
            console.error('Failed to send email:', error);
        }
    }

    async checkDuplicateEmail(to, subject) {
        try {
            await this.page.goto('https://www.icloud.com/mail/');
            await this.page.waitForSelector('li[aria-label="Sent"]');
            await this.page.click('li[aria-label="Sent"]');

            await this.page.waitForSelector('ui-autocomplete-token-field');
            await this.page.fill('ui-autocomplete-token-field', `${subject}`);
            await this.page.press('Enter');

            await this.page.waitForSelector('.thread-list');

            const duplicate = await this.page.evaluate((to, subject) => {
                const emails = Array.from(document.querySelectorAll('.thread-list-item'));
                return emails.some(email => {
                    const emailSubject = email.querySelector('.thread-subject span')?.textContent.trim();
                    const emailTo = email.querySelector('.thread-participants')?.textContent.trim();
                    return emailTo === to && emailSubject === subject;
                });
            }, to, subject);
            
            if (duplicate) {
                console.log('Duplicate email found.');
                const totalduplicate =duplicate.length
                return totalduplicate
            } else {
                console.log('No duplicate email found.');
                const totalduplicate = 0;
                return totalduplicate
            }

            return duplicate;
        } catch (error) {
            console.error('Error checking for duplicate emails:', error);
            return false;
        }
    }

    async logout() {
        await this.page.click('text="Sign Out"');
        await this.page.click('ui.block large primary icloud-mouse');
        await this.browser.close();
    }
}

module.exports = iCloud;

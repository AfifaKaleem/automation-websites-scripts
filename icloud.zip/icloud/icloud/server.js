// server.js
const express = require('express');
const ICloud = require('./ICloud');
const app = express();
const port = process.env.PORT || 3000; // Use environment variable or default to 3000

app.use(express.json()); // Middleware to parse JSON

// Initialize ICloud instance
const iCloud = new ICloud();

// Init route
app.post('/init', async (req, res) => {
    try {
        await iCloud.init();
        res.status(200).send('Initialization successful');
    } catch (error) {
        console.error("Initialization failed:", error);
        res.status(500).send('Initialization failed');
    }
});

// Login route
app.post('/login', async (req, res) => {
    const { email, password } = req.body;
    try {
        await iCloud.login(email, password);
        res.status(200).send('Login successful');
    } catch (error) {
        console.error("Login failed:", error);
        res.status(500).send('Login failed');
    }
});

// OTP route
app.post('/otp', async (req, res) => {
    const { otp } = req.body;
    if (!otp) {
        return res.status(400).send('OTP is required');
    }
    try {
        await iCloud.enterOTP(otp);
        res.status(200).send('OTP entered successfully');
    } catch (error) {
        console.error("OTP entry failed:", error);
        res.status(500).send('OTP entry failed');
    }
});

// Search hashtags in inbox
app.post('/searchHashtagInInbox', async (req, res) => {
    const { hashtag } = req.body;
    if (!hashtag) {
        return res.status(400).send('Hashtag is required');
    }
    try {
        const results = await iCloud.searchHashtagInInbox(hashtag);
        res.status(200).json(results);
    } catch (error) {
        console.error("Inbox search failed:", error);
        res.status(500).send('Inbox search failed');
    }
});

// Search hashtags in sent mail
app.post('/searchHashtagInSent', async (req, res) => {
    const { hashtag } = req.body;
    if (!hashtag) {
        return res.status(400).send('Hashtag is required');
    }
    try {
        const results = await iCloud.searchHashtagInSent(hashtag);
        res.status(200).json(results);
    } catch (error) {
        console.error("Sent mail search failed:", error);
        res.status(500).send('Sent mail search failed');
    }
});

// Logout route
app.post('/logout', async (req, res) => {
    try {
        await iCloud.logout();
        res.status(200).send('Logout successful');
    } catch (error) {
        console.error("Logout failed:", error);
        res.status(500).send('Logout failed');
    }
});


// Endpoint to send email
app.post('/send-email', async (req, res) => {
    const { to, subject, body } = req.body;

    try {
        // Check for duplicate email
        const isDuplicate = await iCloud.checkDuplicateEmail(to, subject);
        if (isDuplicate) {
            res.status(400).send({ message: 'Duplicate email found. Email not sent.' });
            return;
        }

        // Generate and send email
        await icloud.generateEmail(to, subject, body);
        await icloud.sendEmail();
        res.status(200).send({ message: 'Email sent successfully.' });
    } catch (error) {
        console.error('Send email error:', error);
        res.status(500).send({ message: 'Failed to send email.', error: error.message });
    }
});

app.post('/check-duplicate', async (req, res) => {
    const { to, subject } = req.body;

    try {
        // Assuming iCloud has a method that checks for duplicates in the sent box
        const result = await iCloud.checkDuplicateEmail(to, subject);

        // If duplicate exists, we use the flags to indicate the status
        if (result.success) {
            res.status(200).send({
                isDuplicate: result.canSend ? false : true,  // If canSend is false, it's considered a duplicate
                message: result.message || 'Duplicate not found'
            });
        } else {
            res.status(404).send({
                isDuplicate: false,
                message: result.message || 'Email not found'
            });
        }

    } catch (error) {
        console.error('Check duplicate error:', error);
        res.status(500).send({ message: 'Failed to check for duplicate email.', error: error.message });
    }
});



// Graceful shutdown on exit
process.on('SIGINT', async () => {
    console.log('Shutting down server...');
    try {
        await iCloud.logout();
        console.log('Logged out successfully');
    } catch (error) {
        console.error(`Error during logout: ${error.message}`);
    }
    process.exit(0);
});

// Start the server
app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});

const express = require("express");
const bodyParser = require("body-parser");
const Linkedindirect = require("./Linkedindirect");

const app = express();
const port = 3000;

app.use(bodyParser.json());
require('dotenv').config();
app.use(express.urlencoded({ extended: true })); // For parsing URL-encoded data

let linkedinAutomation;

// Endpoint to initialize LinkedIn automation
app.post("/api/automation/Linkedindirect/init", async (req, res) => {
  const { browserType } = req.body;
  try {
    linkedinAutomation = new Linkedindirect(browserType || 'chromium');
    await linkedinAutomation.init();
    res.send({ message: "Linkedindirect automation initialized" });
  } catch (err) {
    res.status(500).json({ error: "Error initiating Linkedindirect", details: err.message });
  }
});

// Endpoint to log in to LinkedIn
app.post("/api/automation/Linkedindirect/login", async (req, res) => {
  const { email, password } = req.body;
  try {
    if (!linkedinAutomation) {
      return res.status(400).json({ error: "Linkedindirect automation is not initialized. Please call the init endpoint first." });
    }
    await linkedinAutomation.login(email, password);
    res.send({ message: "Logged in to Linkedindirect" });
  } catch (err) {
    res.status(500).json({ error: "Error logging in to Linkedindirect", details: err.message });
  }
});

// Endpoint to log out from LinkedIn
app.post("/api/automation/Linkedindirect/logout", async (req, res) => {
  try {
    if (!linkedinAutomation) {
      return res.status(400).json({ error: "Linkedindirect automation is not initialized. Please call the init endpoint first." });
    }
    await linkedinAutomation.logout();
    res.send({ message: "Logged out of Linkedindirect" });
  } catch (err) {
    res.status(500).json({ error: "Error logging out of Linkedindirect", details: err.message });
  }
});



//Endpoint to search for LinkedIn hashtag users
app.post('/api/automation/Linkedindirect/scrapeCompanyDetails', async (req, res) => {
  const { filePath } = req.body;
  try {
    if (!filePath) {
      return res.status(400).json({ error: 'hashtag is required' });
    }
    if (!linkedinAutomation) {
      return res.status(400).json({ error: "Linkedindirect automation is not initialized. Please call the init endpoint first." });
    }
    const users = await linkedinAutomation.searchCompaniesAndSave(filePath);
    return res.json({ users });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Failed to search for LinkedIn hashtag users' });
  }
});

app.post('/api/automation/Linkedindirect/scrapeCompanyPeople', async (req, res) => {
  const { filePath } = req.body;
  try {
    if (!filePath) {
      return res.status(400).json({ error: 'hashtag is required' });
    }
    if (!linkedinAutomation) {
      return res.status(400).json({ error: "Linkedindirect automation is not initialized. Please call the init endpoint first." });
    }
    const users = await linkedinAutomation.searchCompanyPeopleAndSave(filePath);
    return res.json({ users });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Failed to search for LinkedIn hashtag users' });
  }
});

// Start server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});

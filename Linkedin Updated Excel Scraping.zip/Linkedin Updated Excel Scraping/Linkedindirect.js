

const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
require('dotenv').config();
const { parse } = require("json2csv");
const csv = require('csv-parser');
const Papa = require("papaparse");

class Linkedindirect {
  constructor() {
    this.browser = null;
    this.page = null;
  }

  async init() {
    try {
      this.browser = await chromium.launch({ headless: false });
      const context = await this.browser.newContext();
      this.page = await context.newPage();
      console.log("Chromium browser launched successfully");
    } catch (error) {
      console.error('Error launching browser:', error);
    }
  }

  async login(email, password) {
    try {
      if (!this.page) throw new Error("Browser not initialized. Call init() first.");
      await this.page.goto('https://www.linkedin.com/');
      await this.page.click('a[data-tracking-control-name="guest_homepage-basic_nav-header-signin"]');
      await this.page.fill('input[id="username"]', email);
      await this.page.fill('input[id="password"]', password);
      await this.page.click('button[aria-label="Sign in"]');
      await this.page.waitForNavigation({ waitUntil: "networkidle" });
      console.log("Logged in successfully");
    } catch (error) {
      console.error("Error logging in:", error);
    }
  }

  async readCSV(filePath, columnName = "Company Name") {
    return new Promise((resolve, reject) => {
      const fileContent = fs.readFileSync(filePath, "utf8");
      Papa.parse(fileContent, {
        header: true,
        skipEmptyLines: true,
        complete: (results) => {
          const companies = results.data.map(row => row[columnName]).filter(Boolean);
          resolve(companies);
        },
        error: (err) => reject(err),
      });
    });
  }

  async searchCompaniesAndSave(filePath) {
    try {
      const companies = await this.readCSV(filePath);

      // Read previously saved companies from the CSV file to avoid duplicates
      let existingCompanies = new Set();
      if (fs.existsSync('company.csv')) {
        const existingData = fs.readFileSync('company.csv', 'utf8');
        const parsedData = Papa.parse(existingData, { header: true, skipEmptyLines: true }).data;
        parsedData.forEach(row => existingCompanies.add(row.companyName.toLowerCase()));
      }

      for (let companyName of companies) {
        companyName = companyName.toLowerCase();

        if (existingCompanies.has(companyName)) {
          console.log(`✅ Skipping ${companyName} (Already Searched)`);
          continue;
        }

        console.log(`🔍 Searching About Section for: ${companyName}`);

        // Navigate to company page
        try {
          await this.page.goto(`https://www.linkedin.com/search/results/companies/?keywords=${encodeURIComponent(companyName)}`, { waitUntil: 'load' });
          await this.page.waitForSelector(`div.display-flex >a `, { visible: true });
          await this.page.click(`div.display-flex >a`);
          await this.page.waitForSelector('a.org-page-navigation__item-anchor[href*="/about/"]', { timeout: 10000 });
          await this.page.click('a.org-page-navigation__item-anchor[href*="/about/"]');
          console.log('Clicked on the company link!');
        } catch (error) {
          await this.page.goto(`https://www.linkedin.com/company/${encodeURIComponent(companyName)}/`, { waitUntil: 'load' });
        } finally {
          await this.page.waitForTimeout(2000);
        }

        try {
          await this.page.waitForSelector('h1.org-top-card-summary__title', { timeout: 5000 });
        } catch (error) {
          console.warn(`⚠️ Company page not found for: ${companyName}`);
          continue;
        }

        // Extract company name
        const extractedCompanyName = await this.page.evaluate(() => {
          const element = document.querySelector('h1.org-top-card-summary__title');
          return element ? element.textContent.trim() : 'Unknown Company';
        });

        // Wait for and extract location details
        let locations = { primaryLocation: 'N/A', secondaryLocations: [] };
        try {
          await this.page.waitForSelector('li.org-locations-module__location-card', { timeout: 5000 });
          
          locations = await this.page.evaluate(() => {
            const locationElements = document.querySelectorAll('li.org-locations-module__location-card');
            let primaryLocation = 'N/A';
            let secondaryLocations = [];

            locationElements.forEach((location) => {
              const addressElement = location.querySelector('p.t-14.t-black--light.t-normal.break-words');
              const isPrimary = location.querySelector('span.label-16dp');

              if (addressElement) {
                const address = addressElement.textContent.trim();
                if (isPrimary) {
                  primaryLocation = address;
                } else {
                  secondaryLocations.push(address);
                }
              }
            });

            return { primaryLocation, secondaryLocations };
          });
        } catch (error) {
          console.log("No location module found");
        }

        // Extract company details
        const companyDetails = await this.page.evaluate(() => {
          function getText(selector) {
            const element = document.querySelector(selector);
            return element ? element.textContent.trim() : 'N/A';
          }

          try {
            const website = document.querySelector('dd.mb4.t-black--light.text-body-medium a')?.href.trim() || '';
            const employeeSize = getText('dd.t-black--light.text-body-medium.mb1');

            let industry = '', headquartersText = '', city = '', state = '';
            const headers = document.querySelectorAll('dt.mb1 h3.text-heading-medium');

            headers.forEach((header) => {
              if (header.textContent.trim() === 'Industry') {
                industry = header.closest('dt')?.nextElementSibling?.textContent.trim() || '';
              }
              if (header.textContent.trim() === 'Headquarters') {
                headquartersText = header.closest('dt')?.nextElementSibling?.textContent.trim() || '';
              }
            });

            if (headquartersText.includes(',')) {
              [city, state] = headquartersText.split(',').map(item => item.trim());
            }

            const isOwnedByParentCompany = document.querySelector('.org-top-card-summary-info-list__info-item a') ? 'Yes' : 'No';
          
            return {
              employeeSize,
              website,
              industry,
              headquartersCity: city,
              headquartersState: state,
              isOwnedByParentCompany
            };
          } catch (e) {
            console.error("Error in company details extraction:", e);
            return null;
          }
        });

        // Skip if headquarters city or state is missing
        if (!companyDetails || !companyDetails.headquartersCity || !companyDetails.headquartersState) {
          console.warn(`⚠️ Skipping ${extractedCompanyName} - Missing headquarters information`);
          continue;
        }

        // If no locations found, use headquarters as primary location
        if (locations.primaryLocation === 'N/A') {
          locations.primaryLocation = `${companyDetails.headquartersCity}, ${companyDetails.headquartersState}`;
          locations.secondaryLocations = [locations.primaryLocation];
        }
        // If no secondary location found, use primary location as secondary
        else if (locations.secondaryLocations.length === 0) {
          locations.secondaryLocations = [locations.primaryLocation];
        }

        // Compile final company data
        const companyData = {
          companyName: extractedCompanyName,
          employeeSize: companyDetails.employeeSize,
          websiteURL: companyDetails.website,
          industry: companyDetails.industry,
          headquartersCity: companyDetails.headquartersCity,
          headquartersState: companyDetails.headquartersState,
          primaryLocation: locations.primaryLocation,
          secondaryLocations: locations.secondaryLocations.join(', '),
          isOwnedByParentCompany: companyDetails.isOwnedByParentCompany
        };

        console.log(companyData);
        await this.saveToCSV('companies.csv', companyData);
        existingCompanies.add(companyName);
        return companyData;
      }
    } catch (error) {
      console.error('Error extracting company details:', error);
    }
  }
  async searchCompanyPeopleAndSave(filePath) {
    try {
      const companies = await this.readCSV(filePath);
      const jobTitles = [
        'Scientific Communications Manager',
        'Director of Scientific Communications',
        'Senior Scientific Communications Specialist',
        'Medical Writer',
        'Scientific Communications Associate',
        'Head of Scientific Communications',
        'Scientific Communications Strategist',
        'Scientific Communications Consultant',
        'Associate Director Scientific Communications',
        'Research Scientist',
        'Senior Research Associate',
        'Director of Research',
        'Research Manager',
        'Clinical Research Coordinator',
        'Principal Research Scientist',
        'Research and Development (R&D) Specialist',
        'Research Analyst',
        'Head of Research Operations',
        'Research Project Manager',
        'Medical Affairs Manager',
        'Director of Medical Affairs',
        'Medical Affairs Specialist',
        'Vice President Medical Affairs',
        'Medical Science Liaison (MSL)',
        'Associate Director Medical Affairs',
        'Medical Affairs Operations Lead',
        'Head of Medical Affairs',
        'Senior Medical Affairs Strategist',
        'Publications Manager',
        'Senior Publications Writer',
        'Director of Publications',
        'Medical Publications Specialist',
        'Publications Coordinator',
        'Scientific Publications Lead',
        'Associate Director Publications',
        'Publications Planner',
        'Head of Scientific Publications',
        'Medical Writer - Publications',
      ];

      const peopleFilePath = 'People.csv';
      let allEmployees = [];
      const uniqueEmployees = new Set(); // Stores unique fullName & profileUrl combinations

      for (const company of companies) {
        console.log(`🔍 Searching People Section for: ${company}`);

        // Navigate to company page
        try {

          await this.page.goto(`https://www.linkedin.com/search/results/companies/?keywords=${encodeURIComponent(company)}`, { waitUntil: 'load' });
          await this.page.waitForSelector(`div.display-flex >a `, { visible: true });
          await this.page.click(`div.display-flex >a`);
          await this.page.waitForSelector('a.org-page-navigation__item-anchor[href*="/people/"]', { timeout: 10000 });
          await this.page.click('a.org-page-navigation__item-anchor[href*="/people/"]');
          console.log('Clicked on the company link!');
        } catch (error) {
          await this.page.goto(`https://www.linkedin.com/company/${encodeURIComponent(company)}/`, { waitUntil: 'load' });
        } finally {
          await this.page.waitForTimeout(2000);
        }

        for (const jobTitle of jobTitles) {
          try {
            console.log(`🛠 Searching for: ${jobTitle}`);

            // Wait for the search input field
            await this.page.waitForSelector('textarea#people-search-keywords', { timeout: 5000 });

            // Clear input and enter the job title
            await this.page.fill('textarea#people-search-keywords', '');
            await this.page.fill('textarea#people-search-keywords', jobTitle);
            await this.page.keyboard.press('Enter');

            // Wait for results to load
            await this.page.waitForTimeout(4000);

            // Remove any active filters if available
            const removeFilterButton = await this.page.$('button[aria-label^="Remove"]');
            if (removeFilterButton) {
              await removeFilterButton.click();
            }

            await this.page.waitForSelector('div.scaffold-finite-scroll__content ul li', { timeout: 10000 });

            // Extract employee data
            const employees = await this.page.evaluate((companyName) => {
              return [...document.querySelectorAll('div.scaffold-finite-scroll__content ul li')].map((card) => {
                const nameElement = card.querySelector('.lt-line-clamp--single-line.t-black');
                const jobTitleElement = card.querySelector('.artdeco-entity-lockup__subtitle');
                const profileElement = card.querySelector('div.artdeco-entity-lockup__title > a[aria-label*="View"]');

                // Extract full name (if available) and exclude "LinkedIn Member"
                const fullName = nameElement ? nameElement.innerText.trim() : '';
                if (!fullName || fullName.includes('LinkedIn Member')) return null; // Skip LinkedIn Member profiles

                // Extract profile URL
                const profileUrl = profileElement ? profileElement.href.trim() : '';

                // Extract job title & remove "at Company" or "@ CompanyName"
                let jobTitle = jobTitleElement ? jobTitleElement.textContent.trim() : '';
                jobTitle = jobTitle.replace(/ at .*/, '').replace(/ @ .*/, ''); // Removes "at CompanyName" & "@ CompanyName"

                return { fullName, jobTitle, profileUrl, companyName };
              }).filter(employee => employee !== null); // Remove null entries
            }, company);

            // Remove duplicate entries before saving
            const filteredEmployees = employees.filter(employee => {
              const uniqueKey = `${employee.fullName}_${employee.profileUrl}`;
              if (uniqueEmployees.has(uniqueKey)) {
                return false; // Skip duplicates
              } else {
                uniqueEmployees.add(uniqueKey);
                return true;
              }
            });

            console.log(`✅ Found ${filteredEmployees.length} unique employees for "${jobTitle}"`);

            if (filteredEmployees.length > 0) {
              await this.saveToCSV(peopleFilePath, filteredEmployees);
              allEmployees.push(...filteredEmployees);
            } else {
              console.warn(`⚠️ No unique employees found for "${jobTitle}" at "${company}". Skipping CSV save.`);
            }
          } catch (error) {
            console.error(`❌ Error searching for job title "${jobTitle}" at ${company}:`, error);
          }
        }
      }

      return allEmployees;
    } catch (err) {
      console.error('❌ Error:', err);
    }
  }



  async saveToCSV(fileName, data) {
    const fileExists = fs.existsSync(fileName);
    const csv = parse(data, { header: !fileExists });
    fs.appendFileSync(fileName, csv + '\n', 'utf8');
    console.log(`Saved to ${fileName}`);
  }

  async close() {
    if (this.browser) await this.browser.close();
  }
}
module.exports = Linkedindirect;
